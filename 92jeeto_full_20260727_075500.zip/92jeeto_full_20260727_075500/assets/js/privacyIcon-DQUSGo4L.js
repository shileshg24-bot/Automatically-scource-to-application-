const s="/assets/png/privacyIcon-D7PZJYdK.png";export{s as _};
