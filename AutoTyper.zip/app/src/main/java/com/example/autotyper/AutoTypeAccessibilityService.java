package com.example.autotyper;

import android.accessibilityservice.AccessibilityService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;

import java.util.ArrayList;
import java.util.List;

public class AutoTypeAccessibilityService extends AccessibilityService {
    private static AutoTypeAccessibilityService instance;
    private Handler handler = new Handler(Looper.getMainLooper());
    private String textToType = "";
    private boolean isTyping = false;
    private int typingSpeed = 150;
    private OnTypingListener listener;

    public interface OnTypingListener {
        void onTypingStarted();
        void onTypingProgress(int progress);
        void onTypingCompleted();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Handle accessibility events if needed
    }

    @Override
    public void onInterrupt() {
        stopTyping();
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d("AutoTyper", "✅ Accessibility Service Connected");
    }

    public static AutoTypeAccessibilityService getInstance() {
        return instance;
    }

    public void startTyping(String text, int speed) {
        if (isTyping) {
            stopTyping();
        }
        
        this.textToType = text;
        this.typingSpeed = speed;
        this.isTyping = true;
        
        if (listener != null) {
            listener.onTypingStarted();
        }
        
        // Start typing with a small delay
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                typeNextCharacter(0);
            }
        }, 500);
    }

    private void typeNextCharacter(int index) {
        if (!isTyping || index >= textToType.length()) {
            stopTyping();
            return;
        }

        char c = textToType.charAt(index);
        
        // Method 1: Using AccessibilityNodeInfo (Works for most apps)
        boolean success = typeCharUsingAccessibility(c);
        
        // Method 2: Fallback using KeyEvent
        if (!success) {
            typeCharUsingKeyEvent(c);
        }
        
        // Update progress
        if (listener != null) {
            int progress = (index * 100) / textToType.length();
            listener.onTypingProgress(progress);
        }
        
        // Schedule next character with speed
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                typeNextCharacter(index + 1);
            }
        }, typingSpeed);
    }

    private boolean typeCharUsingAccessibility(char character) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        // Find focused editable node
        AccessibilityNodeInfo target = findFocusedEditable(root);
        if (target == null) {
            root.recycle();
            return false;
        }

        // Type the character
        Bundle args = new Bundle();
        args.putChar(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, character);
        boolean result = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        
        target.recycle();
        root.recycle();
        return result;
    }

    private AccessibilityNodeInfo findFocusedEditable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        
        if (node.isFocused() && node.isEditable()) {
            return node;
        }
        
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo result = findFocusedEditable(child);
            if (result != null) {
                return result;
            }
            if (child != null) child.recycle();
        }
        return null;
    }

    private void typeCharUsingKeyEvent(char character) {
        // Convert char to KeyEvent
        int keyCode = getKeyCode(character);
        if (keyCode != -1) {
            // Send key down
            KeyEvent downEvent = new KeyEvent(KeyEvent.ACTION_DOWN, keyCode);
            KeyEvent upEvent = new KeyEvent(KeyEvent.ACTION_UP, keyCode);
            
            // For special characters, use different method
            dispatchKeyEvent(downEvent);
            dispatchKeyEvent(upEvent);
        } else {
            // For special characters, try to type using text
            Bundle args = new Bundle();
            args.putChar(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, character);
            performGlobalAction(GLOBAL_ACTION_HOME);
        }
    }

    private int getKeyCode(char character) {
        if (character >= 'a' && character <= 'z') {
            return character - 'a' + KeyEvent.KEYCODE_A;
        } else if (character >= 'A' && character <= 'Z') {
            return character - 'A' + KeyEvent.KEYCODE_A;
        } else if (character >= '0' && character <= '9') {
            return character - '0' + KeyEvent.KEYCODE_0;
        } else {
            switch (character) {
                case ' ': return KeyEvent.KEYCODE_SPACE;
                case '\n': return KeyEvent.KEYCODE_ENTER;
                case '.': return KeyEvent.KEYCODE_PERIOD;
                case ',': return KeyEvent.KEYCODE_COMMA;
                case '!': return KeyEvent.KEYCODE_1; // Shift + 1
                case '?': return KeyEvent.KEYCODE_SLASH; // Shift + /
                case '@': return KeyEvent.KEYCODE_2; // Shift + 2
                case '#': return KeyEvent.KEYCODE_3; // Shift + 3
                case '$': return KeyEvent.KEYCODE_4; // Shift + 4
                case '%': return KeyEvent.KEYCODE_5; // Shift + 5
                case '^': return KeyEvent.KEYCODE_6; // Shift + 6
                case '&': return KeyEvent.KEYCODE_7; // Shift + 7
                case '*': return KeyEvent.KEYCODE_8; // Shift + 8
                case '(': return KeyEvent.KEYCODE_9; // Shift + 9
                case ')': return KeyEvent.KEYCODE_0; // Shift + 0
                case '_': return KeyEvent.KEYCODE_MINUS; // Shift + -
                case '+': return KeyEvent.KEYCODE_EQUALS; // Shift + =
                case '{': return KeyEvent.KEYCODE_LEFT_BRACKET; // Shift + [
                case '}': return KeyEvent.KEYCODE_RIGHT_BRACKET; // Shift + ]
                case '[': return KeyEvent.KEYCODE_LEFT_BRACKET;
                case ']': return KeyEvent.KEYCODE_RIGHT_BRACKET;
                case '|': return KeyEvent.KEYCODE_BACKSLASH; // Shift + \
                case '\\': return KeyEvent.KEYCODE_BACKSLASH;
                case ':': return KeyEvent.KEYCODE_SEMICOLON; // Shift + ;
                case ';': return KeyEvent.KEYCODE_SEMICOLON;
                case '"': return KeyEvent.KEYCODE_APOSTROPHE; // Shift + '
                case '\'': return KeyEvent.KEYCODE_APOSTROPHE;
                case '<': return KeyEvent.KEYCODE_COMMA; // Shift + ,
                case '>': return KeyEvent.KEYCODE_PERIOD; // Shift + .
                case '/': return KeyEvent.KEYCODE_SLASH;
                default: return -1;
            }
        }
    }

    private boolean dispatchKeyEvent(KeyEvent event) {
        // Use the accessibility service to dispatch key events
        // This is a workaround for Android's limitations
        try {
            Bundle args = new Bundle();
            args.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_ACCESSIBILITY_KEY_EVENT, 
                event.getKeyCode());
            performGlobalAction(GLOBAL_ACTION_HOME);
            return true;
        } catch (Exception e) {
            Log.e("AutoTyper", "Key dispatch failed", e);
            return false;
        }
    }

    public void stopTyping() {
        isTyping = false;
        handler.removeCallbacksAndMessages(null);
        
        if (listener != null) {
            listener.onTypingCompleted();
        }
    }

    public boolean isTyping() {
        return isTyping;
    }

    public void setListener(OnTypingListener listener) {
        this.listener = listener;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopTyping();
        instance = null;
    }
}