package com.example.autotyper;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private boolean isTextPanelOpen = false;
    private View textPanelView;
    private WindowManager.LayoutParams panelParams;
    private String savedText = "";
    private int typingSpeed = 150;
    private boolean isTyping = false;
    private Handler handler = new Handler();
    private AutoTypeAccessibilityService accessibilityService;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createFloatingButton();
        accessibilityService = AutoTypeAccessibilityService.getInstance();
    }

    private void createFloatingButton() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Inflate floating view
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_button, null);
        
        // Set button parameters
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;
        params.width = 80;
        params.height = 80;

        windowManager.addView(floatingView, params);

        // Drag and click functionality
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private long clickTime = 0;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        clickTime = System.currentTimeMillis();
                        return true;
                        
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                        
                    case MotionEvent.ACTION_UP:
                        long diffTime = System.currentTimeMillis() - clickTime;
                        float diffX = event.getRawX() - initialTouchX;
                        float diffY = event.getRawY() - initialTouchY;
                        
                        if (Math.abs(diffX) < 15 && Math.abs(diffY) < 15 && diffTime < 500) {
                            openTextPanel();
                        }
                        return true;
                }
                return false;
            }
        });

        Button btn = floatingView.findViewById(R.id.floating_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTextPanel();
            }
        });
    }

    private void openTextPanel() {
        if (isTextPanelOpen) return;

        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        textPanelView = inflater.inflate(R.layout.text_panel, null);

        panelParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        
        panelParams.gravity = Gravity.CENTER;
        panelParams.x = 0;
        panelParams.y = 0;
        panelParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9);

        windowManager.addView(textPanelView, panelParams);
        isTextPanelOpen = true;

        // Setup views
        EditText textInput = textPanelView.findViewById(R.id.text_input);
        Button saveBtn = textPanelView.findViewById(R.id.save_btn);
        Button closeBtn = textPanelView.findViewById(R.id.close_btn);
        Button stopTypingBtn = textPanelView.findViewById(R.id.stop_typing_btn);
        SeekBar speedSeekBar = textPanelView.findViewById(R.id.speed_seekbar);
        TextView speedText = textPanelView.findViewById(R.id.speed_text);

        if (!savedText.isEmpty()) {
            textInput.setText(savedText);
        }

        speedSeekBar.setProgress(typingSpeed);
        speedText.setText("Speed: " + typingSpeed + "ms");

        speedSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                typingSpeed = Math.max(50, progress);
                speedText.setText("Speed: " + typingSpeed + "ms");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savedText = textInput.getText().toString();
                if (savedText.isEmpty()) {
                    Toast.makeText(FloatingService.this, "Please enter text!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(FloatingService.this, "✅ Text Saved!\n⌨️ Starting auto typing...", Toast.LENGTH_LONG).show();
                startAutoTyping(savedText, typingSpeed);
                closeTextPanel();
            }
        });

        stopTypingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAutoTyping();
                Toast.makeText(FloatingService.this, "⏹️ Typing Stopped!", Toast.LENGTH_SHORT).show();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeTextPanel();
            }
        });
    }

    private void startAutoTyping(String text, int speed) {
        accessibilityService = AutoTypeAccessibilityService.getInstance();
        if (accessibilityService != null) {
            isTyping = true;
            accessibilityService.startTyping(text, speed);
            Toast.makeText(this, "✍️ Auto typing started...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, 
                "❌ Accessibility Service not enabled!\nPlease enable from settings.", 
                Toast.LENGTH_LONG).show();
        }
    }

    private void stopAutoTyping() {
        isTyping = false;
        if (accessibilityService != null) {
            accessibilityService.stopTyping();
        }
    }

    private void closeTextPanel() {
        if (textPanelView != null && isTextPanelOpen) {
            windowManager.removeView(textPanelView);
            isTextPanelOpen = false;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
        if (textPanelView != null && isTextPanelOpen) {
            windowManager.removeView(textPanelView);
        }
        stopAutoTyping();
    }
}