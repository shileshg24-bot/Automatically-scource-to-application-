package com.example.autotyper;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int OVERLAY_PERMISSION_CODE = 123;
    private static final int ACCESSIBILITY_PERMISSION_CODE = 456;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startBtn = findViewById(R.id.start_btn);
        Button stopBtn = findViewById(R.id.stop_btn);
        Button accessibilityBtn = findViewById(R.id.accessibility_btn);

        // Check if Accessibility is enabled
        checkAccessibilityStatus();

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check overlay permission
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (!Settings.canDrawOverlays(MainActivity.this)) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, OVERLAY_PERMISSION_CODE);
                    } else {
                        startFloatingService();
                    }
                } else {
                    startFloatingService();
                }
            }
        });

        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, FloatingService.class));
                Toast.makeText(MainActivity.this, "⏹️ Service Stopped!", Toast.LENGTH_SHORT).show();
            }
        });

        accessibilityBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivityForResult(intent, ACCESSIBILITY_PERMISSION_CODE);
                Toast.makeText(MainActivity.this, 
                    "♿ Enable 'Auto Typer Pro' from Accessibility Services", 
                    Toast.LENGTH_LONG).show();
            }
        });
    }

    private void checkAccessibilityStatus() {
        boolean isEnabled = isAccessibilityServiceEnabled();
        Button accessibilityBtn = findViewById(R.id.accessibility_btn);
        if (isEnabled) {
            accessibilityBtn.setText("✅ Accessibility Enabled");
            accessibilityBtn.setBackgroundTint(getColor(R.color.green));
        } else {
            accessibilityBtn.setText("⚠️ Enable Accessibility First");
            accessibilityBtn.setBackgroundTint(getColor(R.color.orange));
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        String service = getPackageName() + "/" + AutoTypeAccessibilityService.class.getCanonicalName();
        try {
            String enabledServices = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabledServices != null && enabledServices.contains(service);
        } catch (Exception e) {
            return false;
        }
    }

    private void startFloatingService() {
        if (!isAccessibilityServiceEnabled()) {
            Toast.makeText(this, 
                "⚠️ Please enable Accessibility Service first!", 
                Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivityForResult(intent, ACCESSIBILITY_PERMISSION_CODE);
            return;
        }
        
        startService(new Intent(this, FloatingService.class));
        Toast.makeText(this, "✅ Floating button started!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    startFloatingService();
                } else {
                    Toast.makeText(this, "❌ Overlay permission required!", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == ACCESSIBILITY_PERMISSION_CODE) {
            checkAccessibilityStatus();
            // Try to start again after returning
            if (isAccessibilityServiceEnabled()) {
                startFloatingService();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkAccessibilityStatus();
    }
}