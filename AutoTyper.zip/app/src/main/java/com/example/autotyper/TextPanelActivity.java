package com.example.autotyper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class TextPanelActivity extends Activity {
    private EditText textInput;
    private SeekBar speedSeekBar;
    private TextView speedText;
    private Button saveBtn, closeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_panel);

        textInput = findViewById(R.id.text_input);
        speedSeekBar = findViewById(R.id.speed_seekbar);
        speedText = findViewById(R.id.speed_text);
        saveBtn = findViewById(R.id.save_btn);
        closeBtn = findViewById(R.id.close_btn);

        // Load saved text if any
        String savedText = getIntent().getStringExtra("saved_text");
        if (savedText != null) {
            textInput.setText(savedText);
        }

        int speed = getIntent().getIntExtra("typing_speed", 150);
        speedSeekBar.setProgress(speed);
        speedText.setText("Speed: " + speed + "ms");

        speedSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                speedText.setText("Speed: " + Math.max(50, progress) + "ms");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = textInput.getText().toString();
                if (text.isEmpty()) {
                    Toast.makeText(TextPanelActivity.this, "Please enter text!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent resultIntent = new Intent();
                resultIntent.putExtra("text", text);
                resultIntent.putExtra("speed", speedSeekBar.getProgress());
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}