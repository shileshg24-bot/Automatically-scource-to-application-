package com.shilesh.wingopredictor

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.shilesh.wingopredictor.network.ApiClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    // Native C++ library initialization connection
    init {
        System.loadLibrary("wingopredictor")
    }

    private external fun analyzeTrends(numbers: IntArray): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var predictionText by remember { mutableStateOf("Fetching Live Data...") }
            val coroutineScope = rememberCoroutineScope()

            // Background JSON API polling pipeline execution loop
            LaunchedEffect(Unit) {
                coroutineScope.launch {
                    while (true) {
                        val numbersList = ApiClient.fetchLastTenRounds()
                        if (numbersList.isNotEmpty()) {
                            predictionText = analyzeTrends(numbersList.toIntArray())
                        }
                        delay(10000) // Poll real-time JSON every 10 seconds
                    }
                }
            }

            Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0C10))) {
                
                // 1. DYNAMIC NATIVE WEBVIEW CONTAINER FOR WINGO TARGET SITE
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = WebViewClient()
                            loadUrl("https://91club.com") // Target URL platform landing zone
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // 2. TRANSPARENT HIGH-END REAL-TIME OVERLAY DASHBOARD
                var offsetX by remember { mutableStateOf(20f) }
                var offsetY by remember { mutableStateOf(50f) }

                Card(
                    modifier = Modifier
                        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                        .size(width = 280.dp, height = 110.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                offsetX += dragAmount.x
                                offsetY += dragAmount.y
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = Color(0xDD1A1A1A)),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "WIN-GO ANALYSIS ENGINE", color = Color(0xFF00FFCC), style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "NEXT PREDICTION:", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                        Text(text = predictionText, color = Color(0xFFFF007F), style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }
    }
}
