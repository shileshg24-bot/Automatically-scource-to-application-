package com.shilesh.wingopredictor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

object ApiClient {
    private val client = OkHttpClient()
    private const val TARGET_API_URL = "https://draw.ar-lottery01.com/WinGo/WinGo_30S/GetHistoryIssuePage.json"

    fun fetchLastTenRounds(): List<Int> {
        val numbers = mutableListOf<Int>()
        val request = Request.Builder().url(TARGET_API_URL).build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string() ?: return emptyList()
                
                // Pure Dynamic Manual JSON Array Parser for performance safety
                val jsonObject = JSONObject(bodyString)
                val dataObj = jsonObject.optJSONObject("data") ?: return emptyList()
                val listArray = dataObj.optJSONArray("list") ?: return emptyList()

                for (i in 0 until listArray.length()) {
                    val item = listArray.getJSONObject(i)
                    numbers.add(item.optInt("number", 0))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return numbers
    }
}
