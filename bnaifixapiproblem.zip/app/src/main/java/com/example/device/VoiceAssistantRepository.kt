package com.example.device

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.util.Log
import com.example.accessibility.BNAccessibilityService
import com.example.api.GeminiApiClient
import com.example.api.GeminiContent
import com.example.api.GeminiGenerationConfig
import com.example.api.GeminiPart
import com.example.api.GeminiRequest
import com.example.security.NativeSecurityBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class VoiceCommandResult {
    data class ActionExecuted(val actionName: String, val spokenFeedback: String) : VoiceCommandResult()
    data class AiResponse(val spokenText: String) : VoiceCommandResult()
    data class Error(val message: String) : VoiceCommandResult()
}

/**
 * Handles intent detection, device actions (via Accessibility Service & System APIs),
 * and Gemini AI voice query processing.
 */
class VoiceAssistantRepository(private val context: Context) {

    private val systemInstruction = GeminiContent(
        role = null,
        parts = listOf(
            GeminiPart(
                text = "You are BN AI, an advanced, intelligent, highly capable AI Voice Assistant like Jarvis. " +
                        "Keep your responses concise, direct, helpful, and conversational (1 to 3 sentences maximum), suitable for natural spoken audio output."
            )
        )
    )

    suspend fun processUserCommand(
        input: String,
        conversationHistory: List<Pair<String, String>> = emptyList()
    ): VoiceCommandResult = withContext(Dispatchers.IO) {
        val cleanInput = input.trim().lowercase()

        // 1. Direct local system intent matching for instant zero-latency action
        val directAction = tryLocalDeviceAction(cleanInput)
        if (directAction != null) {
            return@withContext directAction
        }

        // 2. Try Gemini AI for intelligent conversation
        val apiKey = NativeSecurityBridge.getApiKey()
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                // Build payload with limited context window
                val contentsList = mutableListOf<GeminiContent>()
                conversationHistory.takeLast(4).forEach { (user, model) ->
                    contentsList.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = user))))
                    contentsList.add(GeminiContent(role = "model", parts = listOf(GeminiPart(text = model))))
                }
                contentsList.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = input))))

                val request = GeminiRequest(
                    contents = contentsList,
                    generationConfig = GeminiGenerationConfig(
                        temperature = 0.7f,
                        maxOutputTokens = 250
                    ),
                    systemInstruction = systemInstruction
                )

                val response = GeminiApiClient.service.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!replyText.isNullOrBlank()) {
                    return@withContext VoiceCommandResult.AiResponse(replyText.trim())
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gemini API error, falling back to local voice engine", e)
            }
        }

        // 3. Fallback to local conversational intelligence when API key is missing or offline
        val fallbackResponse = getLocalConversationalReply(cleanInput)
        return@withContext VoiceCommandResult.AiResponse(fallbackResponse)
    }

    private fun getLocalConversationalReply(input: String): String {
        return when {
            input.contains("hello") || input.contains("hi") || input.contains("hey") ->
                "Hello! I am BN AI, your personal assistant. How can I assist you today?"
            input.contains("who are you") || input.contains("your name") || input.contains("what are you") ->
                "I am BN AI, an intelligent mobile voice assistant designed to help you control your device and answer your questions."
            input.contains("how are you") ->
                "I am functioning at peak capability! How can I help you today?"
            input.contains("joke") || input.contains("funny") ->
                "Why don't scientists trust atoms? Because they make up everything!"
            input.contains("thank") ->
                "You're very welcome! I'm always here to help."
            input.contains("help") || input.contains("what can you do") ->
                "I can open apps, adjust volume, go home, show recents, check your battery, take screenshots, and chat with you."
            else ->
                "I heard you say: '$input'. I am online and ready to control your device or answer your commands."
        }
    }

    private fun tryLocalDeviceAction(input: String): VoiceCommandResult? {
        // App launching intent
        if (input.startsWith("open ") || input.startsWith("launch ") || input.startsWith("start ")) {
            val appName = input.replace("open ", "").replace("launch ", "").replace("start ", "").trim()
            if (appName.isNotBlank()) {
                val result = BNAccessibilityService.openApp(context, appName)
                return VoiceCommandResult.ActionExecuted("Open App", result)
            }
        }

        // Home screen
        if (input == "go home" || input == "home screen" || input == "open home") {
            val success = BNAccessibilityService.performHome()
            val msg = if (success) "Navigating to home screen" else "Opening home screen"
            if (!success) {
                // Fallback home intent
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
            return VoiceCommandResult.ActionExecuted("Home", msg)
        }

        // Back action
        if (input == "go back" || input == "back") {
            val success = BNAccessibilityService.performBack()
            val msg = if (success) "Going back" else "Please enable Accessibility Service for back control."
            return VoiceCommandResult.ActionExecuted("Back", msg)
        }

        // Recents / Recent apps
        if (input.contains("recent apps") || input.contains("show recents") || input == "recents") {
            val success = BNAccessibilityService.performRecents()
            val msg = if (success) "Showing recent apps" else "Please enable Accessibility Service for recents control."
            return VoiceCommandResult.ActionExecuted("Recents", msg)
        }

        // Volume control
        if (input.contains("volume up") || input.contains("increase volume") || input == "louder") {
            BNAccessibilityService.adjustVolume(context, raise = true)
            return VoiceCommandResult.ActionExecuted("Volume Up", "Increased media volume.")
        }

        if (input.contains("volume down") || input.contains("decrease volume") || input == "quieter") {
            BNAccessibilityService.adjustVolume(context, raise = false)
            return VoiceCommandResult.ActionExecuted("Volume Down", "Decreased media volume.")
        }

        // Time and date
        if (input.contains("what time is it") || input.contains("current time") || input == "time") {
            val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return VoiceCommandResult.AiResponse("The current time is $timeStr.")
        }

        if (input.contains("what day is it") || input.contains("today's date") || input == "date") {
            val dateStr = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
            return VoiceCommandResult.AiResponse("Today is $dateStr.")
        }

        // Battery info
        if (input.contains("battery level") || input.contains("battery status") || input.contains("how much battery")) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val batLevel = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            val reply = if (batLevel >= 0) "Your device battery level is at $batLevel percent." else "Battery information is currently unavailable."
            return VoiceCommandResult.AiResponse(reply)
        }

        // Screenshot
        if (input.contains("take screenshot") || input.contains("screen shot")) {
            val success = BNAccessibilityService.performScreenshot()
            val msg = if (success) "Taking screenshot" else "Please enable Accessibility Service for screenshot capture."
            return VoiceCommandResult.ActionExecuted("Screenshot", msg)
        }

        return null
    }

    companion object {
        private const val TAG = "VoiceAssistantRepository"
    }
}
