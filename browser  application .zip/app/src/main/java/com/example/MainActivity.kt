package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.DownloadEntry
import com.example.data.HistoryEntry
import com.example.ui.BrowserViewModel
import com.example.ui.theme.MyApplicationTheme
import java.io.ByteArrayInputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check and ask internet and storage permissions
        requestDevicePermissions()

        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }

    private fun requestDevicePermissions() {
        val permissions = mutableListOf<String>()
        permissions.add(Manifest.permission.INTERNET)
        permissions.add(Manifest.permission.ACCESS_NETWORK_STATE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val requestNeeded = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (requestNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, requestNeeded.toTypedArray(), 101)
        }
    }
}

@Composable
fun MainAppScreen() {
    val viewModel: BrowserViewModel = viewModel()
    var selectedTab by remember { mutableIntStateOf(0) }

    val incognito by viewModel.incognitoModeEnabled.collectAsStateWithLifecycle()

    // Dynamic brand color pairing based on mode selection (Incognito is space purple, Normal is navy)
    val startColor = if (incognito) Color(0xFF1F1135) else Color(0xFF0F1A30)
    val endColor = if (incognito) Color(0xFF0A0314) else Color(0xFF050B14)
    val accentColor = if (incognito) Color(0xFFBB86FC) else Color(0xFF00E6FF)

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_screen"),
        bottomBar = {
            NavigationBar(
                containerColor = endColor,
                contentColor = Color.White,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Language, contentDescription = "Browser") },
                    label = { Text("Browser", color = Color.White) },
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = endColor,
                        selectedTextColor = accentColor,
                        indicatorColor = accentColor,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Security, contentDescription = "Shield") },
                    label = { Text("Scanner & Downloader", color = Color.White) },
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = endColor,
                        selectedTextColor = accentColor,
                        indicatorColor = accentColor,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", color = Color.White) },
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = endColor,
                        selectedTextColor = accentColor,
                        indicatorColor = accentColor,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(startColor, endColor)))
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> BrowserTab(viewModel, accentColor)
                1 -> ScannerAndDownloaderTab(viewModel, accentColor)
                2 -> SettingsTab(viewModel, accentColor)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserTab(viewModel: BrowserViewModel, accent: Color) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    val url by viewModel.currentUrl.collectAsStateWithLifecycle()
    val isWebLoading by viewModel.isWebLoading.collectAsStateWithLifecycle()
    val loadProgress by viewModel.loadProgress.collectAsStateWithLifecycle()
    val desktopMode by viewModel.desktopModeEnabled.collectAsStateWithLifecycle()
    val adBlock by viewModel.adBlockEnabled.collectAsStateWithLifecycle()
    val popupBlock by viewModel.popupBlockEnabled.collectAsStateWithLifecycle()
    val incognito by viewModel.incognitoModeEnabled.collectAsStateWithLifecycle()
    val addressFocus by viewModel.addressBarFocus.collectAsStateWithLifecycle()
    val suggestions by viewModel.urlSuggestions.collectAsStateWithLifecycle()

    var addressText by remember { mutableStateOf(url) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isMalwareIntercepted by remember { mutableStateOf(false) }
    var blockedUrlAttempted by remember { mutableStateOf("") }

    // Sync input address when current URL changes externally
    LaunchedEffect(url) {
        addressText = url
        isMalwareIntercepted = false
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // TOP ADDRESS BAR & ACTION ACTIONS
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.DarkGray.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Back Nav Button
                    IconButton(
                        onClick = { webViewRef?.goBack() },
                        enabled = webViewRef?.canGoBack() == true
                    ) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = if (webViewRef?.canGoBack() == true) Color.White else Color.Gray
                        )
                    }

                    // Forward Button
                    IconButton(
                        onClick = { webViewRef?.goForward() },
                        enabled = webViewRef?.canGoForward() == true
                    ) {
                        Icon(
                            Icons.Default.ArrowForward,
                            contentDescription = "Forward",
                            tint = if (webViewRef?.canGoForward() == true) Color.White else Color.Gray
                        )
                    }

                    // Refresh Button
                    IconButton(
                        onClick = { if (isWebLoading) webViewRef?.stopLoading() else webViewRef?.reload() }
                    ) {
                        Icon(
                            if (isWebLoading) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = Color.White
                        )
                    }

                    // Address Bar Text Field
                    TextField(
                        value = addressText,
                        onValueChange = {
                            addressText = it
                            viewModel.onAddressChanged(it)
                        },
                        placeholder = { Text("Search or input secure URL", color = Color.Gray, fontSize = 12.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("address_bar_input"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Black.copy(alpha = 0.4f),
                            unfocusedContainerColor = Color.Black.copy(alpha = 0.4f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = accent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(24.dp),
                        trailingIcon = {
                            if (addressText.isNotEmpty()) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Clear",
                                    tint = Color.White,
                                    modifier = Modifier.clickable {
                                        addressText = ""
                                        viewModel.urlSuggestions.value = emptyList()
                                    }
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    // Desktop view toggle button
                    IconButton(
                        onClick = { viewModel.toggleDesktopMode(!desktopMode) }
                    ) {
                        Icon(
                            Icons.Default.Monitor,
                            contentDescription = "Desktop view toggle",
                            tint = if (desktopMode) accent else Color.White
                        )
                    }

                    // Incognito trigger
                    IconButton(
                        onClick = { viewModel.incognitoModeEnabled.value = !incognito }
                    ) {
                        Icon(
                            Icons.Default.VisibilityOff,
                            contentDescription = "Incognito Mode",
                            tint = if (incognito) accent else Color.White
                        )
                    }
                }
            }
        }

        // Live URL Suggestions cards Overlay
        if (suggestions.isNotEmpty() && addressText.isNotBlank()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.DarkGray),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                LazyColumn {
                    items(suggestions) { sugg ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.navigateTo(sugg)
                                    focusManager.clearFocus()
                                    viewModel.urlSuggestions.value = emptyList()
                                }
                                .padding(12.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Query Suggestion", tint = Color.LightGray)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(sugg, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        // Load progress display
        if (isWebLoading) {
            LinearProgressIndicator(
                progress = { loadProgress.toFloat() / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = accent,
                trackColor = Color.DarkGray
            )
        }

        // SCENARIOS DECISION BOX: BLOCK SCREEN VS ACTIVE WEB WINDOW
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (isMalwareIntercepted) {
                MalwareShieldAlertScreen(
                    attemptedUrl = blockedUrlAttempted,
                    onSafeguardExit = {
                        isMalwareIntercepted = false
                        viewModel.currentUrl.value = "https://google.com"
                    },
                    onBypassRisk = {
                        isMalwareIntercepted = false
                        // Allow bypass and load straight URL by circumventing filters once
                        webViewRef?.loadUrl(blockedUrlAttempted)
                    }
                )
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            
                            // Secure Settings configure
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                allowContentAccess = true
                                allowFileAccess = true
                            }

                            webViewClient = object : WebViewClient() {
                                
                                // Intercept core resource loads for high-velocity JNI/Fallback Ad-blocking
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val resourceUrl = request?.url?.toString() ?: ""
                                    if (adBlock && NativeCore.checkAdUrl(resourceUrl)) {
                                        Log.i("AdBlocker", "Intercepted ad network resource file: $resourceUrl")
                                        // Return sterile empty byte array to visual component to block ads
                                        return WebResourceResponse(
                                            "text/plain",
                                            "UTF-8",
                                            ByteArrayInputStream(ByteArray(0))
                                        )
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }

                                // Handle Page Loading and Malware Site block checkers
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val destinationUrl = request?.url?.toString() ?: ""
                                    
                                    // Malware blocking JNI / Fallback verification
                                    if (NativeCore.checkMaliciousUrl(destinationUrl)) {
                                        blockedUrlAttempted = destinationUrl
                                        isMalwareIntercepted = true
                                        return true // Intercept & block navigation
                                    }

                                    // Intercept download intents
                                    if (isDownloadUrlLink(destinationUrl)) {
                                        viewModel.prepareDownloadRequest(destinationUrl)
                                        return true
                                    }

                                    return false
                                }

                                override fun onPageStarted(view: WebView?, urlStr: String?, favicon: android.graphics.Bitmap?) {
                                    super.onPageStarted(view, urlStr, favicon)
                                    viewModel.isWebLoading.value = true
                                    viewModel.loadProgress.value = 0
                                    viewModel.currentUrl.value = urlStr ?: ""
                                }

                                override fun onPageFinished(view: WebView?, urlStr: String?) {
                                    super.onPageFinished(view, urlStr)
                                    viewModel.isWebLoading.value = false
                                    viewModel.loadProgress.value = 100
                                    
                                    val pageTitle = view?.title ?: "Web Page"
                                    viewModel.webPageTitle.value = pageTitle
                                    
                                    // Persist history if not in incognito mode
                                    viewModel.addPageToHistory(pageTitle, urlStr ?: "")
                                    
                                    // Update forward/backward keys
                                    viewModel.canGoBack.value = view?.canGoBack() ?: false
                                    viewModel.canGoForward.value = view?.canGoForward() ?: false
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    super.onProgressChanged(view, newProgress)
                                    viewModel.loadProgress.value = newProgress
                                }

                                // Popup Blocker toggle setting
                                override fun onCreateWindow(
                                    view: WebView?,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: android.os.Message?
                                ): Boolean {
                                    if (popupBlock) {
                                        Log.w("PopupBlocker", "Super Browser intercepted a popup/window request safely.")
                                        Toast.makeText(context, "Popup window blocked securely", Toast.LENGTH_SHORT).show()
                                        return false // Suppress popup loading
                                    }
                                    return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg)
                                }
                            }

                            // Download listener interceptor
                            setDownloadListener { dUrl, _, dContentDisposition, dMimeType, dContentLength ->
                                viewModel.prepareDownloadRequest(dUrl)
                            }

                            loadUrl(url)
                            webViewRef = this
                        }
                    },
                    update = { view ->
                        // Dynamically update user agent depending on desktop mode triggers
                        val currentAgent = view.settings.userAgentString
                        val isCurrentDesktop = currentAgent.contains("Windows NT 10.0")
                        
                        if (desktopMode && !isCurrentDesktop) {
                            view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                            view.settings.useWideViewPort = true
                            view.settings.loadWithOverviewMode = true
                            view.reload()
                        } else if (!desktopMode && isCurrentDesktop) {
                            view.settings.userAgentString = null // Reset back to default
                            view.settings.useWideViewPort = false
                            view.settings.loadWithOverviewMode = false
                            view.reload()
                        }

                        // Sync URL navigation externally
                        if (view.url != url && !url.contains("resolved=youtube_stream")) {
                            view.loadUrl(url)
                        }
                    }
                )
            }
        }
    }

    // DOWNLOAD SIZE & CONFIRMATION Dialog Overlay
    val activeDownloadUrl by viewModel.activeDownloadDialogUrl.collectAsStateWithLifecycle()
    val activeDownloadName by viewModel.activeDownloadDialogName.collectAsStateWithLifecycle()
    val activeDownloadSize by viewModel.activeDownloadDialogSize.collectAsStateWithLifecycle()
    val fetchingDetails by viewModel.isFetchingDownloadDetails.collectAsStateWithLifecycle()

    if (activeDownloadUrl != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissDownloadRequest() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Download, contentDescription = "Download Info", tint = accent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Secure Download Interceptor")
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    if (fetchingDetails) {
                        CircularProgressIndicator(color = accent, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Verifying downloadable stream contents safely on cloud layer...", color = Color.White, fontSize = 13.sp)
                    } else {
                        Text("A secure file stream download request was intercepted. Please confirm source metrics:", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("File: $activeDownloadName", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        val sizeInMb = activeDownloadSize.toDouble() / (1024.0 * 1024.0)
                        val sizeFormatted = String.format("%.2f", sizeInMb)
                        Text("Calculated Size: $sizeFormatted MB", color = accent, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("🛡️ Securing Protocol: File will be automatically scanned for virus signatures upon arrival and removed instantly if malware is identified.", color = Color.Yellow, fontSize = 11.sp, lineHeight = 14.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmManualDownload() },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    enabled = !fetchingDetails
                ) {
                    Text("Confirm Download", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissDownloadRequest() }) {
                    Text("Decline Request", color = Color.White)
                }
            },
            containerColor = Color(0xFF151D30),
            titleContentColor = Color.White,
            textContentColor = Color.LightGray
        )
    }
}

// Check standard file extensions for dynamic intercepting
private fun isDownloadUrlLink(url: String): Boolean {
    val clean = url.lowercase()
    return clean.endsWith(".zip") || clean.endsWith(".pdf") || clean.endsWith(".apk") ||
           clean.endsWith(".exe") || clean.endsWith(".dmg") || clean.endsWith(".mp4") ||
           clean.endsWith(".mp3") || clean.endsWith(".rar") || clean.endsWith(".tgz")
}

@Composable
fun MalwareShieldAlertScreen(
    attemptedUrl: String,
    onSafeguardExit: () -> Unit,
    onBypassRisk: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF420B11)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("malware_alert_pane")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = "Malware Intercepted Icon",
                tint = Color.Red,
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "SECURITY SHIELD: BLOCKED ADVERSE MALWARE SITE",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "Super Browser threat protection intercepted navigation to a site flagged for distributing malware or hosting phishing endpoints.",
                color = Color.LightGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            ) {
                Text(
                    attemptedUrl,
                    color = Color.Red,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(12.dp),
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = onSafeguardExit,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("Go Back Cleanly", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(onClick = onBypassRisk) {
                Text("Bypass Threat & Proceed anyway (Unsafeguarded)", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}


@Composable
fun ScannerAndDownloaderTab(viewModel: BrowserViewModel, accent: Color) {
    var isDownloaderMode by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Toggle Switch Segmented view
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                .padding(4.dp)
        ) {
            Button(
                onClick = { isDownloaderMode = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDownloaderMode) accent else Color.Transparent
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Video Downloader", color = if (isDownloaderMode) Color.Black else Color.White)
            }
            Button(
                onClick = { isDownloaderMode = false },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isDownloaderMode) accent else Color.Transparent
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Mobile Virus Scanner", color = if (!isDownloaderMode) Color.Black else Color.White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isDownloaderMode) {
            SocialDownloaderWindow(viewModel, accent)
        } else {
            VirusScannerWindow(viewModel, accent)
        }
    }
}


@Composable
fun SocialDownloaderWindow(viewModel: BrowserViewModel, accent: Color) {
    val inputUrl by viewModel.socialUrlInput.collectAsStateWithLifecycle()
    val extractedUrl by viewModel.extractedVideoUrl.collectAsStateWithLifecycle()
    val isExtracting by viewModel.isExtractingVideo.collectAsStateWithLifecycle()
    val selectedOption by viewModel.socialDownloadOption.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("High-Speed Social Media Media Downloader", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Paste link from YouTube, Instagram Reels, or TikTok to capture direct storage files.", color = Color.LightGray, fontSize = 12.sp)
            
            Spacer(modifier = Modifier.height(16.dp))

            TextField(
                value = inputUrl,
                onValueChange = { viewModel.socialUrlInput.value = it },
                placeholder = { Text("Paste social media URL here...", color = Color.Gray, fontSize = 13.sp) },
                modifier = Modifier.fillMaxWidth().testTag("social_url_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Black.copy(alpha = 0.5f),
                    unfocusedContainerColor = Color.Black.copy(alpha = 0.5f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = accent
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { viewModel.extractSocialVideoUrlAndMetadata() },
                enabled = inputUrl.isNotBlank() && !isExtracting,
                colors = ButtonDefaults.buttonColors(containerColor = accent),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isExtracting) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(18.dp))
                } else {
                    Text("Analyze & Direct-Extract Link", color = Color.Black)
                }
            }

            // EXTRACTED CARD CONTROLS
            if (extractedUrl != null) {
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = accent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Extracted Stream Media Link Clean!", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Stream Endpoint URL:", color = Color.Gray, fontSize = 11.sp)
                        Text(extractedUrl!!, color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)

                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Choose Desired Format Options:", color = Color.White, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        val formats = listOf("Video (HD) - 1080p [18.2 MB]", "Video (LQ) - 480p [4.5 MB]", "Audio (MP3) - [2.1 MB]")
                        formats.forEach { format ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.socialDownloadOption.value = format }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = selectedOption == format,
                                    onClick = { viewModel.socialDownloadOption.value = format },
                                    colors = RadioButtonDefaults.colors(selectedColor = accent)
                                )
                                Text(format, color = Color.White, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.startSocialStreamDownload() },
                            colors = ButtonDefaults.buttonColors(containerColor = accent),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Download Stream Format to Storage", color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun VirusScannerWindow(viewModel: BrowserViewModel, accent: Color) {
    val isScanning by viewModel.isScannerActive.collectAsStateWithLifecycle()
    val progress by viewModel.scannerProgress.collectAsStateWithLifecycle()
    val currentFile by viewModel.scannerCurrentFile.collectAsStateWithLifecycle()
    val totalScanned by viewModel.scannedFilesCount.collectAsStateWithLifecycle()
    val threatList by viewModel.foundThreatsList.collectAsStateWithLifecycle()
    val isFinished by viewModel.isScanFinished.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.Security,
                contentDescription = null,
                tint = if (isScanning) accent else if (threatList.isEmpty()) Color.Green else Color.Red,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text("Antivirus Threat Signature Scanner", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Runs deep checking inside user-accessible storage blocks recursively.", color = Color.LightGray, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(24.dp))

            if (isScanning) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = accent,
                    trackColor = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Scanned File count: $totalScanned", color = Color.White, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Object: $currentFile", color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            } else {
                Button(
                    onClick = { viewModel.startFullDeviceVirusScan() },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Trigger Deep Threat Protection Scan", color = Color.Black)
                }
            }

            if (isFinished && !isScanning) {
                Spacer(modifier = Modifier.height(16.dp))
                if (threatList.isEmpty()) {
                    Text("✅ Clean! Your storage folders contain zero malware signatures.", color = Color.Green, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                } else {
                    Text("⚠️ SECURITY ALERT! Infected signature matched in external directories.", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LazyColumn(modifier = Modifier.height(200.dp)) {
                        items(threatList) { infectedFile ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF381014)),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(8.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(infectedFile.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(infectedFile.absolutePath, color = Color.LightGray, fontSize = 10.sp, overflow = TextOverflow.Ellipsis, maxLines = 1)
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteThreatFile(infectedFile) }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Remove Threat File", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun SettingsTab(viewModel: BrowserViewModel, accent: Color) {
    val context = LocalContext.current

    val adBlock by viewModel.adBlockEnabled.collectAsStateWithLifecycle()
    val popupBlock by viewModel.popupBlockEnabled.collectAsStateWithLifecycle()
    val dnsServer by viewModel.selectedDns.collectAsStateWithLifecycle()
    val vpnMode by viewModel.selectedVpnMode.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadRecords.collectAsStateWithLifecycle()

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("Privacy & Security Configuration", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // TOGGLE SWITCHES CARD
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Security Level Shield Filters", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Ad-Blocker filtering", color = Color.White, fontSize = 13.sp)
                            Text("Blocks background easylist resources in JNI", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = adBlock,
                            onCheckedChange = { viewModel.toggleAdBlocker(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = accent)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Automatic Popup Blocker", color = Color.White, fontSize = 13.sp)
                            Text("Suppresses window.open requests securely", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = popupBlock,
                            onCheckedChange = { viewModel.togglePopupBlocker(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = accent)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // SANDBOX VPN & SECURE DNS CONFIG
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Secure Sandbox Route Config", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Selected DNS Provider:", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    val dnsOptions = listOf("GOOGLE" to "Google Public DNS (8.8.8.8)", "CLOUDFLARE" to "Cloudflare Encrypted (1.1.1.1)", "ADGUARD" to "AdGuard Security & Ad Block")
                    dnsOptions.forEach { (key, title) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setDnsServer(key) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = dnsServer == key,
                                onClick = { viewModel.setDnsServer(key) },
                                colors = RadioButtonDefaults.colors(selectedColor = accent)
                            )
                            Text(title, color = Color.White, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Routing Tunnel Scheme:", color = Color.LightGray, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))

                    val vpnModes = listOf(
                        "NO_VPN" to "No Sandbox Route (Default Direct)",
                        "DNS_ONLY" to "Secure DNS Queries only",
                        "VPN_DNS" to "VPN Tunnel + Custom DNS routing"
                    )
                    vpnModes.forEach { (key, title) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setVpnMode(key) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = vpnMode == key,
                                onClick = { viewModel.setVpnMode(key) },
                                colors = RadioButtonDefaults.colors(selectedColor = accent)
                            )
                            Text(title, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // SYSTEM UTILS
        item {
            Button(
                onClick = {
                    viewModel.clearBrowsingHistory()
                    Toast.makeText(context, "Browsing history cleared securely!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Enforce Dynamic Cookie / History Reset", color = Color.White)
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // INTERCEPTED DOWNLOADS FEED
        item {
            Text("Secure Downloads Records History Feed", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (downloads.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    Text("No downloaded files registered yet.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(16.dp), textAlign = TextAlign.Center)
                }
            }
        } else {
            items(downloads) { record ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(record.fileName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            
                            val sizeInMb = record.totalSize.toDouble() / (1024.0 * 1024.0)
                            val progressInMb = record.downloadedSize.toDouble() / (1024.0 * 1024.0)
                            
                            if (record.status == "DOWNLOADING") {
                                Text(
                                    String.format("Downloading: %.2f / %.2f MB", progressInMb, sizeInMb),
                                    color = accent,
                                    fontSize = 11.sp
                                )
                            } else if (record.status == "MALWARE_DELETED") {
                                Text("🛑 MALWARE BLOCKED & AUTOMATICALLY DELETED!", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            } else {
                                Text("Status: ${record.status}", color = if (record.status == "COMPLETED") Color.Green else Color.LightGray, fontSize = 11.sp)
                            }
                        }

                        IconButton(
                            onClick = { viewModel.deleteDownloadRecordFromList(record.id) }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Purge entry list", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
