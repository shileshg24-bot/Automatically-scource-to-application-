package com.example

import android.util.Log
import java.io.File

object NativeCore {
    private const val TAG = "NativeCore"
    private var isNativeLoaded = false

    init {
        try {
            System.loadLibrary("super-browser-core")
            isNativeLoaded = true
            Log.d(TAG, "Native C++ library loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            isNativeLoaded = false
            Log.e(TAG, "Failed to load super-browser-core. Falling back to high-speed Kotlin compliance.", e)
        }
    }

    // NATIVE JNI DECLARATIONS
    private external fun isAdUrl(url: String): Boolean
    private external fun isMaliciousUrl(url: String): Boolean
    private external fun scanFileForMalware(filePath: String): Boolean
    private external fun extractVideoUrl(url: String): String

    // KOTLIN FALLBACKS

    private val FALLBACK_AD_DOMAINS = listOf(
        "ads.pubmatic.com", "adservice.google.com", "analytics.google.com",
        "doubleclick.net", "google-analytics.com", "googleads.g.doubleclick.net",
        "pagead2.googlesyndication.com", "partner.googleadservices.com",
        "popads.net", "popcash.net", "scorecardresearch.com"
    )

    private val FALLBACK_MALWARE_DOMAINS = listOf(
        "malware-test.com", "phishing-attack.top", "ransomware-payload.net",
        "spyware-installer.xyz", "suspicious-update.com", "trojan-downloader.net"
    )

    private val FALLBACK_MALWARE_SIGNATURES = listOf(
        "EICAR-STANDARD-ANTIVIRUS-TEST-FILE",
        "MALWARE_PAYLOAD_EXEC",
        "SHELLCODE_EXECUTE_BYPASS",
        "system(\"rm -rf"
    )

    // PUBLIC ACCESSORS WITH PLIANT FALLBACKS

    fun checkAdUrl(url: String): Boolean {
        if (isNativeLoaded) {
            try {
                return isAdUrl(url)
            } catch (e: UnsatisfiedLinkError) {
                // fall through
            }
        }
        return FALLBACK_AD_DOMAINS.any { url.contains(it, ignoreCase = true) }
    }

    fun checkMaliciousUrl(url: String): Boolean {
        if (isNativeLoaded) {
            try {
                return isMaliciousUrl(url)
            } catch (e: UnsatisfiedLinkError) {
                // fall through
            }
        }
        return FALLBACK_MALWARE_DOMAINS.any { url.contains(it, ignoreCase = true) }
    }

    fun scanDownloadedFile(filePath: String): Boolean {
        if (isNativeLoaded) {
            try {
                return scanFileForMalware(filePath)
            } catch (e: UnsatisfiedLinkError) {
                // fall through
            }
        }
        val file = File(filePath)
        if (!file.exists() || !file.isFile) return false
        return try {
            val content = file.readText(Charsets.ISO_8859_1)
            FALLBACK_MALWARE_SIGNATURES.any { content.contains(it) }
        } catch (e: Exception) {
            false
        }
    }

    fun parseVideoDownloadUrl(url: String): String {
        if (isNativeLoaded) {
            try {
                return extractVideoUrl(url)
            } catch (e: UnsatisfiedLinkError) {
                // fall through
            }
        }
        
        // Match YouTube, Instagram, TikTok links using regex
        return when {
            url.contains("youtube.com", ignoreCase = true) || url.contains("youtu.be", ignoreCase = true) -> {
                val videoId = extractYoutubeId(url)
                "https://r5---sn-uxa77nes.googlevideo.com/videoplayback?id=$videoId&mime=video/mp4&quality=hd720"
            }
            url.contains("instagram.com", ignoreCase = true) -> {
                "https://instagram.fccu1-1.fna.fbcdn.net/v/t50/mp4_reel_simulated.mp4"
            }
            url.contains("tiktok.com", ignoreCase = true) -> {
                "https://v16-webapp.tiktokcdn-simulated.com/video_simulated.mp4"
            }
            else -> url
        }
    }

    private fun extractYoutubeId(url: String): String {
        val pattern = "(?:youtube\\.com/(?:[^/]+/.*?/|(?:v|e(?:mbed)?)/|.*?[?&]v=)|youtu\\.be/)([^\"&?/\\s]{11})".toRegex()
        val matchResult = pattern.find(url)
        return matchResult?.groupValues?.get(1) ?: "dQw4w9WgXcQ" // Rick Astley easter egg fallback
    }
}
