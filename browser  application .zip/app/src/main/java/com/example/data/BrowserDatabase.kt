package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// 1. ENTITIES

@Entity(tableName = "browsing_history")
data class HistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isIncognito: Boolean = false
)

@Entity(tableName = "downloads")
data class DownloadEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val url: String,
    val filePath: String,
    val totalSize: Long, // in bytes
    val downloadedSize: Long, // in bytes
    val status: String, // "PENDING", "DOWNLOADING", "COMPLETED", "FAILED", "CANCELLED"
    val timestamp: Long = System.currentTimeMillis(),
    val isMalware: Boolean = false
)

@Entity(tableName = "blocked_urls")
data class BlockedUrl(
    @PrimaryKey @ColumnInfo(name = "url") val url: String,
    val reason: String = "Malicious site detected by secure scanner",
    val type: String = "MALWARE", // "MALWARE" or "AD"
    val isCustom: Boolean = false
)


// 2. DAOS

@Dao
interface BrowserDao {
    // History
    @Query("SELECT * FROM browsing_history WHERE isIncognito = 0 ORDER BY timestamp DESC")
    fun getNormalHistory(): Flow<List<HistoryEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: HistoryEntry)

    @Query("DELETE FROM browsing_history WHERE isIncognito = 0")
    suspend fun clearNormalHistory()

    @Query("DELETE FROM browsing_history WHERE id = :id")
    suspend fun deleteHistoryEntry(id: Long)

    // Downloads
    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    fun getAllDownloads(): Flow<List<DownloadEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntry): Long

    @Update
    suspend fun updateDownload(download: DownloadEntry)

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: Long): DownloadEntry?

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownload(id: Long)

    // Blocked URLs
    @Query("SELECT * FROM blocked_urls")
    fun getAllBlockedUrls(): Flow<List<BlockedUrl>>

    @Query("SELECT EXISTS(SELECT 1 FROM blocked_urls WHERE url = :url LIMIT 1)")
    suspend fun isUrlBlocked(url: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlockedUrl(blockedUrl: BlockedUrl)

    @Query("DELETE FROM blocked_urls WHERE url = :url")
    suspend fun deleteBlockedUrl(url: String)
}


// 3. DATABASE

@Database(entities = [HistoryEntry::class, DownloadEntry::class, BlockedUrl::class], version = 1, exportSchema = false)
abstract class BrowserDatabase : RoomDatabase() {
    abstract fun browserDao(): BrowserDao

    companion object {
        @Volatile
        private var INSTANCE: BrowserDatabase? = null

        fun getDatabase(context: Context): BrowserDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BrowserDatabase::class.java,
                    "super_browser_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}


// 4. REPOSITORY

class BrowserRepository(private val dao: BrowserDao) {
    val normalHistory: Flow<List<HistoryEntry>> = dao.getNormalHistory()
    val allDownloads: Flow<List<DownloadEntry>> = dao.getAllDownloads()
    val allBlockedUrls: Flow<List<BlockedUrl>> = dao.getAllBlockedUrls()

    suspend fun addHistoryEntry(title: String, url: String, isIncognito: Boolean) {
        if (!isIncognito) {
            dao.insertHistory(HistoryEntry(title = title, url = url, isIncognito = false))
        }
    }

    suspend fun clearHistory() = dao.clearNormalHistory()

    suspend fun deleteHistory(id: Long) = dao.deleteHistoryEntry(id)

    suspend fun startDownload(fileName: String, url: String, filePath: String, totalSize: Long): Long {
        val entry = DownloadEntry(
            fileName = fileName,
            url = url,
            filePath = filePath,
            totalSize = totalSize,
            downloadedSize = 0L,
            status = "DOWNLOADING"
        )
        return dao.insertDownload(entry)
    }

    suspend fun updateDownloadProgress(id: Long, downloaded: Long, status: String, isMalware: Boolean = false) {
        val existing = dao.getDownloadById(id)
        if (existing != null) {
            dao.updateDownload(existing.copy(
                downloadedSize = downloaded,
                status = status,
                isMalware = isMalware
            ))
        }
    }

    suspend fun updateDownloadStatusAndFile(id: Long, status: String, filePath: String, isMalware: Boolean = false) {
        val existing = dao.getDownloadById(id)
        if (existing != null) {
            dao.updateDownload(existing.copy(
                status = status,
                filePath = filePath,
                isMalware = isMalware
            ))
        }
    }

    suspend fun deleteDownloadRecord(id: Long) = dao.deleteDownload(id)

    suspend fun checkIsUrlBlocked(urlCleaned: String): Boolean {
        // Strip protocols and www. before checking
        val host = getHost(urlCleaned)
        return dao.isUrlBlocked(host) || dao.isUrlBlocked(urlCleaned)
    }

    suspend fun addBlockedUrl(url: String, reason: String, type: String = "MALWARE") {
        dao.insertBlockedUrl(BlockedUrl(url = getHost(url), reason = reason, type = type))
    }

    suspend fun removeBlockedUrl(url: String) {
        dao.deleteBlockedUrl(getHost(url))
    }

    private fun getHost(url: String): String {
        return try {
            val uri = java.net.URI(url)
            val host = uri.host ?: ""
            if (host.startsWith("www.")) host.substring(4) else host
        } catch (e: Exception) {
            url
        }
    }
}
