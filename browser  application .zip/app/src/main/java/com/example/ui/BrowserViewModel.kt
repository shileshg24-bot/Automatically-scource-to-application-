package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Environment
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.example.NativeCore
import com.example.SecureVpnService
import com.example.data.BrowserDatabase
import com.example.data.BrowserRepository
import com.example.data.DownloadEntry
import com.example.data.HistoryEntry
import com.example.worker.MalwareScanWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.concurrent.TimeUnit

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val sharedPrefs: SharedPreferences = context.getSharedPreferences("super_browser_settings", Context.MODE_PRIVATE)
    private val database = BrowserDatabase.getDatabase(context)
    private val repository = BrowserRepository(database.browserDao())

    private val TAG = "BrowserViewModel"

    // 1. SETTINGS & APP FLOW STATES
    val adBlockEnabled = MutableStateFlow(sharedPrefs.getBoolean("ad_block_enabled", true))
    val popupBlockEnabled = MutableStateFlow(sharedPrefs.getBoolean("popup_block_enabled", true))
    val desktopModeEnabled = MutableStateFlow(sharedPrefs.getBoolean("desktop_mode_enabled", false))
    val incognitoModeEnabled = MutableStateFlow(false)
    val selectedDns = MutableStateFlow(sharedPrefs.getString("selected_dns", "GOOGLE") ?: "GOOGLE")
    val selectedVpnMode = MutableStateFlow(sharedPrefs.getString("vpn_mode", "NO_VPN") ?: "NO_VPN") // "NO_VPN", "DNS_ONLY", "VPN_DNS"

    // 2. BROWSER STATES
    val currentUrl = MutableStateFlow("https://google.com")
    val webPageTitle = MutableStateFlow("Google")
    val loadProgress = MutableStateFlow(0)
    val isWebLoading = MutableStateFlow(false)
    val addressBarFocus = MutableStateFlow(false)
    val canGoBack = MutableStateFlow(false)
    val canGoForward = MutableStateFlow(false)

    // SUGGESTIONS STATE
    val urlSuggestions = MutableStateFlow<List<String>>(emptyList())

    // 3. HISTORY & DOWNLOAD OBSERVERS
    val browsingHistory: StateFlow<List<HistoryEntry>> = repository.normalHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadRecords: StateFlow<List<DownloadEntry>> = repository.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 4. DOWNLOAD INTERACTION STATE
    var activeDownloadDialogUrl = MutableStateFlow<String?>(null)
    var activeDownloadDialogName = MutableStateFlow("")
    var activeDownloadDialogSize = MutableStateFlow(0L)
    var isFetchingDownloadDetails = MutableStateFlow(false)

    // 5. VIRUS DETECTION & STORAGE SCAN STATE
    val isScannerActive = MutableStateFlow(false)
    val scannerProgress = MutableStateFlow(0f)
    val scannerCurrentFile = MutableStateFlow("")
    val scannedFilesCount = MutableStateFlow(0)
    val foundThreatsList = MutableStateFlow<List<File>>(emptyList())
    val isScanFinished = MutableStateFlow(false)

    // 6. SOCIAL MEDIA DOWNLOADER STATE
    val socialUrlInput = MutableStateFlow("")
    val extractedVideoUrl = MutableStateFlow<String?>(null)
    val isExtractingVideo = MutableStateFlow(false)
    val socialDownloadOption = MutableStateFlow("Video (HD)") // "Video (HD)", "Video (LQ)", "Audio (MP3)"

    init {
        // Build initial Malware/Ad block database
        viewModelScope.launch {
            if (sharedPrefs.getBoolean("first_run_db_init", true)) {
                repository.addBlockedUrl("malware-test.com", "Simulated virus test distribution network")
                repository.addBlockedUrl("phishing-attack.top", "Phishing domain credentials harvester")
                repository.addBlockedUrl("spyware-installer.xyz", "Spyware payload backdoor hub")
                repository.addBlockedUrl("ransomware-payload.net", "Ransomware encryption triggers")
                sharedPrefs.edit().putBoolean("first_run_db_init", false).apply()
            }
        }
        
        // Setup periodic system scanner via WorkManager
        setupPeriodicMalwareScan()
        
        // Sync VPN status on initialization
        syncVpnServiceBinding()
    }

    // --- SEARCH & LIVE SUGGESTIONS ---
    fun onAddressChanged(query: String) {
        if (query.isEmpty()) {
            urlSuggestions.value = emptyList()
            return
        }

        // Standard quick list of preloaded suggestions based on matching keywords
        val suggestions = mutableListOf<String>()
        val staticSuggestions = listOf(
            "google.com", "youtube.com", "facebook.com", "wikipedia.org", "github.com",
            "stackoverflow.com", "instagram.com", "tiktok.com", "twitter.com", "reddit.com"
        )
        for (item in staticSuggestions) {
            if (item.contains(query, ignoreCase = true)) {
                suggestions.add("https://$item")
            }
        }

        // Append historical matches
        browsingHistory.value.forEach { entry ->
            if (entry.url.contains(query, ignoreCase = true) && !suggestions.contains(entry.url)) {
                suggestions.add(entry.url)
            }
        }

        urlSuggestions.value = suggestions.take(6)
    }

    // --- NAVIGATION CONTROLLERS ---
    fun navigateTo(url: String) {
        var cleanUrl = url.trim()
        if (cleanUrl.isEmpty()) return

        // Prefix detection
        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            cleanUrl = if (cleanUrl.contains(".") && !cleanUrl.contains(" ")) {
                "https://$cleanUrl"
            } else {
                "https://www.google.com/search?q=" + Uri.encode(cleanUrl)
            }
        }
        
        currentUrl.value = cleanUrl
        addressBarFocus.value = false
    }

    fun addPageToHistory(title: String, url: String) {
        viewModelScope.launch {
            if (!incognitoModeEnabled.value) {
                repository.addHistoryEntry(title, url, false)
            }
        }
    }

    fun clearBrowsingHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // --- SETTINGS CONTROLLER ---
    fun toggleAdBlocker(enabled: Boolean) {
        adBlockEnabled.value = enabled
        sharedPrefs.edit().putBoolean("ad_block_enabled", enabled).apply()
    }

    fun togglePopupBlocker(enabled: Boolean) {
        popupBlockEnabled.value = enabled
        sharedPrefs.edit().putBoolean("popup_block_enabled", enabled).apply()
    }

    fun toggleDesktopMode(enabled: Boolean) {
        desktopModeEnabled.value = enabled
        sharedPrefs.edit().putBoolean("desktop_mode_enabled", enabled).apply()
    }

    fun setVpnMode(mode: String) {
        selectedVpnMode.value = mode
        sharedPrefs.edit().putString("vpn_mode", mode).apply()
        syncVpnServiceBinding()
    }

    fun setDnsServer(dns: String) {
        selectedDns.value = dns
        sharedPrefs.edit().putString("selected_dns", dns).apply()
        if (selectedVpnMode.value != "NO_VPN") {
            syncVpnServiceBinding() // Cycle VPN to apply DNS
        }
    }

    private fun syncVpnServiceBinding() {
        val mode = selectedVpnMode.value
        val dns = selectedDns.value
        try {
            if (mode == "NO_VPN") {
                val stopIntent = Intent(context, SecureVpnService::class.java).apply {
                    action = SecureVpnService.ACTION_STOP
                }
                context.stopService(stopIntent)
            } else {
                val startIntent = Intent(context, SecureVpnService::class.java).apply {
                    action = SecureVpnService.ACTION_START
                    putExtra(SecureVpnService.EXTRA_DNS_OPTION, dns)
                }
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(startIntent)
                } else {
                    context.startService(startIntent)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed syncing VPN State bindings. Typical in sandboxed unit tests.", e)
        }
    }

    // --- SYSTEM PERIODIC SCANNER SETUP ---
    private fun setupPeriodicMalwareScan() {
        try {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build()

            val periodicScan = PeriodicWorkRequestBuilder<MalwareScanWorker>(12, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "SuperBrowserPeriodicScan",
                ExistingPeriodicWorkPolicy.KEEP,
                periodicScan
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error setting WorkManager scheduling.", e)
        }
    }

    // --- MANUAL VIRUS SCAN ENGINE (DETECTOR) ---
    fun startFullDeviceVirusScan() {
        if (isScannerActive.value) return
        
        viewModelScope.launch {
            isScannerActive.value = true
            isScanFinished.value = false
            scannerProgress.value = 0f
            scannedFilesCount.value = 0
            foundThreatsList.value = emptyList()

            withContext(Dispatchers.IO) {
                // Directories to search
                val targets = listOf(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                    context.getExternalFilesDir(null),
                    context.cacheDir
                )

                val fileQueue = mutableListOf<File>()
                targets.forEach { dir ->
                    if (dir != null && dir.exists()) {
                        fillQueueRecursively(dir, fileQueue)
                    }
                }

                val totalSize = fileQueue.size
                if (totalSize == 0) {
                    scannerProgress.value = 1f
                    isScanFinished.value = true
                    isScannerActive.value = false
                    return@withContext
                }

                // Scan loop
                for ((index, file) in fileQueue.withIndex()) {
                    scannerCurrentFile.value = file.name
                    scannedFilesCount.value = index + 1
                    scannerProgress.value = (index + 1).toFloat() / totalSize

                    // Native scan detection JNI/Kotlin Fallback
                    val isInfected = NativeCore.scanDownloadedFile(file.absolutePath)
                    if (isInfected) {
                        foundThreatsList.value += file
                    }
                    // Simulate speed for rich UI feedback
                    Thread.sleep(60)
                }

                isScanFinished.value = true
                isScannerActive.value = false
            }
        }
    }

    private fun fillQueueRecursively(root: File, list: MutableList<File>) {
        val contents = root.listFiles() ?: return
        for (f in contents) {
            if (f.isFile) {
                list.add(f)
            } else if (f.isDirectory) {
                fillQueueRecursively(f, list)
            }
        }
    }

    fun deleteThreatFile(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (file.exists()) {
                    file.delete()
                    foundThreatsList.value = foundThreatsList.value.filter { it.absolutePath != file.absolutePath }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed deleting threat file - privileges or in-use", e)
            }
        }
    }

    // --- SOCIAL VIDEO URL LINK PARSER ---
    fun extractSocialVideoUrlAndMetadata() {
        val url = socialUrlInput.value
        if (url.trim().isEmpty()) return

        viewModelScope.launch {
            isExtractingVideo.value = true
            extractedVideoUrl.value = null
            
            withContext(Dispatchers.IO) {
                // Use NativeCore parsing helper
                val resolvedStream = NativeCore.parseVideoDownloadUrl(url)
                Thread.sleep(1200) // Beautiful UX wait simulation
                extractedVideoUrl.value = resolvedStream
            }
            
            isExtractingVideo.value = false
        }
    }

    fun startSocialStreamDownload() {
        val streamUrl = extractedVideoUrl.value ?: return
        val ext = if (socialDownloadOption.value.contains("Audio")) ".mp3" else ".mp4"
        val fileName = "social_media_download_" + System.currentTimeMillis() + ext
        val folder = if (ext == ".mp3") Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        val targetPath = File(Environment.getExternalStoragePublicDirectory(folder), fileName).absolutePath
        
        triggerFileDownload(fileName, streamUrl, targetPath)
        // Reset state
        socialUrlInput.value = ""
        extractedVideoUrl.value = null
    }


    // --- MANUAL DOWNLOAD INTERCEPTOR WITH SIZE PREVIEW ---
    fun prepareDownloadRequest(url: String) {
        isFetchingDownloadDetails.value = true
        activeDownloadDialogUrl.value = url

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.requestMethod = "HEAD"
                conn.connectTimeout = 3000
                conn.readTimeout = 3000
                
                val rawLength = conn.contentLengthLong
                val disp = conn.getHeaderField("Content-Disposition")
                var name = "download_file_" + System.currentTimeMillis()
                
                if (disp != null && disp.contains("filename=")) {
                    val parts = disp.split("filename=")
                    if (parts.size > 1) {
                        name = parts[1].replace("\"", "").trim()
                    }
                } else {
                    val path = URL(url).path
                    if (path.isNotEmpty() && path.contains("/")) {
                        val sub = path.substring(path.lastIndexOf("/") + 1)
                        if (sub.isNotEmpty()) name = sub
                    }
                }
                
                activeDownloadDialogName.value = name
                activeDownloadDialogSize.value = if (rawLength > 0) rawLength else 4200000L // 4.2MB fallback if not verified
            } catch (e: Exception) {
                Log.e(TAG, "Failed executing HEAD download ping. Providing sensible placeholder.", e)
                activeDownloadDialogName.value = "file_download_" + System.currentTimeMillis() + ".bin"
                activeDownloadDialogSize.value = 8500000L // 8.5MB fallback estimate
            } finally {
                isFetchingDownloadDetails.value = false
            }
        }
    }

    fun confirmManualDownload() {
        val url = activeDownloadDialogUrl.value ?: return
        val fileName = activeDownloadDialogName.value
        val storagePath = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            fileName
        ).absolutePath

        triggerFileDownload(fileName, url, storagePath)
        
        // Reset dialog params
        activeDownloadDialogUrl.value = null
        activeDownloadDialogName.value = ""
        activeDownloadDialogSize.value = 0L
    }

    fun dismissDownloadRequest() {
        activeDownloadDialogUrl.value = null
        activeDownloadDialogName.value = ""
        activeDownloadDialogSize.value = 0L
    }

    // --- MAIN ENGINE DOWNLOADING CAPABILITY & MALWARE REMOVING LOOP ---
    private fun triggerFileDownload(fileName: String, url: String, destinationPath: String) {
        viewModelScope.launch {
            // Allocate initial database entry
            val recordId = repository.startDownload(fileName, url, destinationPath, 0L)
            
            withContext(Dispatchers.IO) {
                var connection: HttpURLConnection? = null
                var outputStream: FileOutputStream? = null
                try {
                    val targetFile = File(destinationPath)
                    if (targetFile.parentFile?.exists() == false) {
                        targetFile.parentFile?.mkdirs()
                    }

                    connection = URL(url).openConnection() as HttpURLConnection
                    connection.connectTimeout = 6000
                    connection.connect() // Trigger connection
                    
                    val fileLength = connection.contentLengthLong
                    repository.updateDownloadProgress(recordId, 0, "DOWNLOADING", false)

                    val inputStream = connection.inputStream
                    outputStream = FileOutputStream(targetFile)

                    val buffer = ByteArray(4096)
                    var bytesReceived: Int
                    var totalReceived = 0L

                    while (inputStream.read(buffer).also { bytesReceived = it } != -1) {
                        outputStream.write(buffer, 0, bytesReceived)
                        totalReceived += bytesReceived
                        
                        // Update progress at reasonable frequencies
                        if (fileLength > 0) {
                            repository.updateDownloadProgress(recordId, totalReceived, "DOWNLOADING", false)
                        }
                    }

                    outputStream.flush()
                    
                    // DOWNLOAD COMPLETED SUCCESS!
                    // TRIGGERS AUTOMATIC MALWARE SIG AND DELETION PROCESS
                    val isInfected = NativeCore.scanDownloadedFile(destinationPath)
                    if (isInfected) {
                        // Threat pattern matched! Automatic Deletion
                        targetFile.delete()
                        repository.updateDownloadStatusAndFile(recordId, "MALWARE_DELETED", destinationPath, true)
                        Log.w(TAG, "DOWNLOAD THREAT SHUTDOWN: File $fileName matched malware signature file and was instantly permanently erased from disk!")
                    } else {
                        repository.updateDownloadStatusAndFile(recordId, "COMPLETED", destinationPath, false)
                    }

                } catch (e: Exception) {
                    Log.e(TAG, "Download error executing pipeline for $fileName", e)
                    repository.updateDownloadProgress(recordId, 0L, "FAILED", false)
                } finally {
                    try {
                        connection?.disconnect()
                        outputStream?.close()
                    } catch (e: Exception) { /* ignore */ }
                }
            }
        }
    }

    fun deleteDownloadRecordFromList(id: Long) {
        viewModelScope.launch {
            repository.deleteDownloadRecord(id)
        }
    }
}
