const s="/assets/png/gameStatsSteps-BqKu2Uz3.png";export{s as _};
