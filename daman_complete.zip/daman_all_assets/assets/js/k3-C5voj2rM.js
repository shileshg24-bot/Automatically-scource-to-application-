import{r as e}from"./main.vue_vue_type_style_index_0_scoped_d3b4a951_lang-TJsXcrb-.js";function o(t){return e.post("/Lottery/K3Bet",t)}export{o as g};
