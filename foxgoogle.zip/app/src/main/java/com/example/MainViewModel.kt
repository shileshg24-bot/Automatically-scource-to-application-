package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.accessibility.BNAccessibilityService
import com.example.api.GeminiAIClient
import com.example.device.VoiceAssistantRepository
import com.example.device.VoiceCommandResult
import com.example.service.BNVoiceForegroundService
import com.example.ui.components.ChatMessage
import com.example.ui.components.MessageSender
import com.example.ui.components.VoiceState
import com.example.voice.SpeechToTextManager
import com.example.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = VoiceAssistantRepository(application)
    private val geminiClient = GeminiAIClient()
    
    // Voice managers
    val speechToTextManager = SpeechToTextManager(application)
    val textToSpeechManager = TextToSpeechManager(application)

    // UI States
    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled: StateFlow<Boolean> = _isAccessibilityEnabled.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _isContinuousListening = MutableStateFlow(false)
    val isContinuousListening: StateFlow<Boolean> = _isContinuousListening.asStateFlow()

    private var isProcessingVoice = false

    init {
        // Setup speech-to-text callback - PURE GEMINI, NO GOOGLE ASSISTANT
        speechToTextManager.onResultCallback = { spokenText ->
            if (spokenText.isNotBlank() && !isProcessingVoice) {
                isProcessingVoice = true
                handleUserSpokenText(spokenText)
            }
        }

        speechToTextManager.onErrorCallback = { error ->
            Log.w("MainViewModel", "Speech error: $error")
            if (_isContinuousListening.value && !textToSpeechManager.isSpeaking.value) {
                viewModelScope.launch {
                    delay(500)
                    if (_isContinuousListening.value && !textToSpeechManager.isSpeaking.value) {
                        speechToTextManager.startListening()
                    }
                }
            }
        }

        // Monitor speech recognition state
        viewModelScope.launch {
            speechToTextManager.isListening.collect { listening ->
                if (listening) {
                    _voiceState.value = VoiceState.LISTENING
                } else if (_voiceState.value == VoiceState.LISTENING) {
                    if (!textToSpeechManager.isSpeaking.value) {
                        _voiceState.value = VoiceState.IDLE
                    }
                }
            }
        }

        // Monitor TTS state
        viewModelScope.launch {
            textToSpeechManager.isSpeaking.collect { speaking ->
                if (speaking) {
                    _voiceState.value = VoiceState.SPEAKING
                } else if (_voiceState.value == VoiceState.SPEAKING) {
                    _voiceState.value = VoiceState.IDLE
                    isProcessingVoice = false
                    if (_isContinuousListening.value) {
                        speechToTextManager.startListening()
                    }
                }
            }
        }

        checkAccessibilityStatus()
    }

    fun startVoiceAssistant() {
        // Start with BN AI greeting - PURE BNAI
        val initialGreeting = "Namaste! Main BN AI hoon. Aapka personal assistant."
        addMessage(MessageSender.BN_AI, initialGreeting)
        _isContinuousListening.value = true
        BNVoiceForegroundService.startService(getApplication())
        textToSpeechManager.speak(initialGreeting)
        // Start listening after greeting
        viewModelScope.launch {
            delay(1500)
            if (_isContinuousListening.value) {
                speechToTextManager.startListening()
            }
        }
    }

    fun checkAccessibilityStatus() {
        _isAccessibilityEnabled.value = BNAccessibilityService.isEnabled(getApplication())
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("MainViewModel", "Could not open accessibility settings", e)
        }
    }

    // BN Circle tap handler - PURE BN AI
    fun onTapBnCircle() {
        textToSpeechManager.stop()
        speechToTextManager.stopListening()
        isProcessingVoice = false
        
        val initialGreeting = "BN AI yahan hai! Kya aap kuch poochna chahenge?"
        addMessage(MessageSender.BN_AI, initialGreeting)
        _isContinuousListening.value = true
        BNVoiceForegroundService.startService(getApplication())
        textToSpeechManager.speak(initialGreeting)
        
        viewModelScope.launch {
            delay(1200)
            if (_isContinuousListening.value) {
                speechToTextManager.startListening()
            }
        }
    }

    fun toggleListening() {
        if (speechToTextManager.isListening.value) {
            speechToTextManager.stopListening()
            _isContinuousListening.value = false
            _voiceState.value = VoiceState.IDLE
            isProcessingVoice = false
        } else {
            textToSpeechManager.stop()
            _isContinuousListening.value = true
            speechToTextManager.startListening()
            BNVoiceForegroundService.startService(getApplication())
        }
    }

    fun updateInputText(text: String) {
        _inputText.value = text
    }

    fun sendTextMessage(text: String) {
        if (text.isBlank()) return
        _inputText.value = ""
        handleUserSpokenText(text)
    }

    private fun handleUserSpokenText(userText: String) {
        addMessage(MessageSender.USER, userText)
        _voiceState.value = VoiceState.THINKING
        _isContinuousListening.value = true
        BNVoiceForegroundService.startService(getApplication())

        viewModelScope.launch {
            val history = _messages.value.map {
                val sender = if (it.sender == MessageSender.USER) "user" else "model"
                Pair(sender, it.text)
            }

            when (val result = repository.processUserCommand(userText, history)) {
                is VoiceCommandResult.ActionExecuted -> {
                    addMessage(MessageSender.SYSTEM, result.spokenFeedback)
                    textToSpeechManager.speak(result.spokenFeedback)
                }
                is VoiceCommandResult.AiResponse -> {
                    addMessage(MessageSender.BN_AI, result.spokenText)
                    textToSpeechManager.speak(result.spokenText)
                }
                is VoiceCommandResult.Error -> {
                    addMessage(MessageSender.BN_AI, result.message)
                    textToSpeechManager.speak("Maaf kijiye, ${result.message}")
                }
            }
        }
    }

    private fun addMessage(sender: MessageSender, text: String) {
        val newList = _messages.value.toMutableList()
        newList.add(ChatMessage(sender = sender, text = text))
        _messages.value = newList
    }

    fun cleanup() {
        speechToTextManager.destroy()
        textToSpeechManager.destroy()
        BNVoiceForegroundService.stopService(getApplication())
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}