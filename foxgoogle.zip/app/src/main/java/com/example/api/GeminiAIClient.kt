package com.example.api

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Pure Gemini AI Client - No Google Assistant interference
 * Handles Gemini API calls directly
 */
class GeminiAIClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val API_KEY = "AQ.Ab8RN6JgYyC3w_TRgCAeazSgA_ZTkuWqs6hgEwGOZTACOQjGjQ"
    private val API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$API_KEY"

    suspend fun generateResponse(userMessage: String, history: List<Pair<String, String>> = emptyList()): String {
        return try {
            val json = buildGeminiRequest(userMessage, history)
            val request = Request.Builder()
                .url(API_URL)
                .post(json.toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()
            
            if (response.isSuccessful && responseBody != null) {
                parseGeminiResponse(responseBody)
            } else {
                Log.e("GeminiClient", "API Error: ${response.code} - $responseBody")
                "Maaf kijiye, main abhi response nahi de pa raha."
            }
        } catch (e: IOException) {
            Log.e("GeminiClient", "Network Error", e)
            "Network error hai. Kya aap internet check kar sakte hain?"
        } catch (e: Exception) {
            Log.e("GeminiClient", "Error", e)
            "Kuch error aaya hai. Phir se try karein."
        }
    }

    private fun buildGeminiRequest(message: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        
        // Add history
        history.takeLast(4).forEach { (user, model) ->
            val userContent = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", user)))
            }
            contents.put(userContent)
            
            val modelContent = JSONObject().apply {
                put("role", "model")
                put("parts", JSONArray().put(JSONObject().put("text", model)))
            }
            contents.put(modelContent)
        }
        
        // Add current message
        val currentContent = JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", message)))
        }
        contents.put(currentContent)

        val systemInstruction = JSONObject().apply {
            put("parts", JSONArray().put(JSONObject().put(
                "text", "You are BN AI. Respond in Hinglish or English. Be helpful. 1-3 sentences max. Never repeat what user said."
            )))
        }

        val generationConfig = JSONObject().apply {
            put("temperature", 0.85)
            put("maxOutputTokens", 250)
            put("topP", 0.9)
        }

        return JSONObject().apply {
            put("contents", contents)
            put("systemInstruction", systemInstruction)
            put("generationConfig", generationConfig)
        }.toString()
    }

    private fun parseGeminiResponse(json: String): String {
        val obj = JSONObject(json)
        
        // Check for error
        if (obj.has("error")) {
            val error = obj.getJSONObject("error")
            val message = error.optString("message", "Unknown error")
            Log.e("GeminiClient", "API Error: $message")
            return "Error: $message"
        }
        
        val candidates = obj.getJSONArray("candidates")
        if (candidates.length() > 0) {
            val candidate = candidates.getJSONObject(0)
            val content = candidate.getJSONObject("content")
            val parts = content.getJSONArray("parts")
            if (parts.length() > 0) {
                return parts.getJSONObject(0).optString("text", "").trim()
            }
        }
        return ""
    }
}