package com.example.device

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import android.util.Log
import com.example.accessibility.BNAccessibilityService
import com.example.api.GeminiApiClient
import com.example.api.GeminiContent
import com.example.api.GeminiGenerationConfig
import com.example.api.GeminiPart
import com.example.api.GeminiRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class VoiceCommandResult {
    data class ActionExecuted(val actionName: String, val spokenFeedback: String) : VoiceCommandResult()
    data class AiResponse(val spokenText: String) : VoiceCommandResult()
    data class Error(val message: String) : VoiceCommandResult()
}

/**
 * BN AI Voice Assistant Repository - Pure Gemini Implementation
 * No Google Assistant interference
 */
class VoiceAssistantRepository(private val context: Context) {

    private val systemInstruction = GeminiContent(
        role = null,
        parts = listOf(
            GeminiPart(
                text = "You are BN AI, a powerful, intelligent voice assistant like Jarvis. " +
                        "CRITICAL RULES: " +
                        "1. NEVER repeat what user said. " +
                        "2. Respond naturally in Hinglish or English. " +
                        "3. Be helpful, concise (1-3 sentences). " +
                        "4. If user asks for device actions, guide them. " +
                        "5. Always be polite and professional."
            )
        )
    )

    suspend fun processUserCommand(
        input: String,
        conversationHistory: List<Pair<String, String>> = emptyList()
    ): VoiceCommandResult = withContext(Dispatchers.IO) {
        val cleanInput = input.trim().lowercase()

        // 1. Check local device actions first
        val directAction = tryLocalDeviceAction(cleanInput, input)
        if (directAction != null) {
            return@withContext directAction
        }

        // 2. Use Gemini AI - YOUR API KEY FROM curl
        val apiKey = "AQ.Ab8RN6JgYyC3w_TRgCAeazSgA_ZTkuWqs6hgEwGOZTACOQjGjQ"
        
        try {
            val contentsList = mutableListOf<GeminiContent>()
            conversationHistory.takeLast(6).forEach { (user, model) ->
                contentsList.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = user))))
                contentsList.add(GeminiContent(role = "model", parts = listOf(GeminiPart(text = model))))
            }
            contentsList.add(GeminiContent(role = "user", parts = listOf(GeminiPart(text = input))))

            val request = GeminiRequest(
                contents = contentsList,
                generationConfig = GeminiGenerationConfig(
                    temperature = 0.85f,
                    maxOutputTokens = 250
                ),
                systemInstruction = systemInstruction
            )

            val response = GeminiApiClient.service.generateContent(apiKey, request)
            
            // Check for error
            if (response.error != null) {
                Log.e("VoiceAssistantRepo", "Gemini API Error: ${response.error.message}")
                return@withContext VoiceCommandResult.Error("Gemini API error: ${response.error.message}")
            }
            
            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

            if (!replyText.isNullOrBlank()) {
                return@withContext VoiceCommandResult.AiResponse(replyText.trim())
            } else {
                return@withContext VoiceCommandResult.Error("No response from Gemini AI")
            }
        } catch (e: Exception) {
            Log.e("VoiceAssistantRepo", "Gemini API exception", e)
            // Fallback responses
            val fallback = getLocalFallbackResponse(cleanInput)
            return@withContext VoiceCommandResult.AiResponse(fallback)
        }
    }

    private fun getLocalFallbackResponse(input: String): String {
        return when {
            input.contains("kaise ho") || input.contains("how are you") ->
                "Main bilkul theek hoon! Aap kaise ho?"
            input.contains("hello") || input.contains("hi") || input.contains("hey") ->
                "Namaste! Main BN AI hoon, aapki seva mein."
            input.contains("who are you") || input.contains("tum kaun ho") ->
                "Main BN AI hoon - aapka personal voice assistant."
            input.contains("joke") || input.contains("chutkula") ->
                "Ek joke: Teacher ne poochha - 'Beta, tumhe kya pasand hai?' Student bola - 'Mobile!' Teacher - 'Kyun?' Student - 'Kyunki usme mein baat kar sakta hoon, gaana sun sakta hoon, aur jab bore ho jaaun toh switch off kar doon!'"
            input.contains("thank") || input.contains("shukriya") ->
                "Aapka swagat hai! Kya aur help chahiye?"
            else ->
                "Main samajh gaya. Kya aap kuch aur poochna chahenge?"
        }
    }

    private fun tryLocalDeviceAction(cleanInput: String, rawInput: String): VoiceCommandResult? {
        // --- YouTube Search ---
        if (cleanInput.contains("youtube") || cleanInput.startsWith("play ")) {
            val query = cleanInput
                .replace("on youtube", "")
                .replace("youtube par", "")
                .replace("youtube", "")
                .replace("play", "")
                .trim()
            
            if (query.isNotBlank()) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$query")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    return VoiceCommandResult.ActionExecuted("YouTube", "Searching '$query' on YouTube.")
                } catch (e: Exception) {
                    Log.e("VoiceAssistantRepo", "YouTube search failed", e)
                }
            }
        }

        // --- Open App ---
        if (cleanInput.startsWith("open ") || cleanInput.startsWith("launch ") || cleanInput.startsWith("kholo ")) {
            val appName = rawInput
                .replace(Regex("(?i)^(open|launch|kholo)\\s+"), "")
                .replace("app", "")
                .trim()
            
            if (appName.isNotBlank()) {
                val result = BNAccessibilityService.openApp(context, appName)
                return VoiceCommandResult.ActionExecuted("Open App", result)
            }
        }

        // --- Torch Control ---
        if (cleanInput.contains("torch on") || cleanInput.contains("light on") || cleanInput.contains("flash on")) {
            setTorchState(true)
            return VoiceCommandResult.ActionExecuted("Torch", "Torch ON kar diya.")
        }
        if (cleanInput.contains("torch off") || cleanInput.contains("light off") || cleanInput.contains("flash off")) {
            setTorchState(false)
            return VoiceCommandResult.ActionExecuted("Torch", "Torch OFF kar diya.")
        }

        // --- Navigation ---
        if (cleanInput == "home" || cleanInput == "go home") {
            val success = BNAccessibilityService.performHome()
            if (!success) {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
            return VoiceCommandResult.ActionExecuted("Home", "Home screen par le chal raha hoon.")
        }

        if (cleanInput == "back" || cleanInput == "go back") {
            val success = BNAccessibilityService.performBack()
            return VoiceCommandResult.ActionExecuted("Back", if (success) "Peeche ja raha hoon." else "Accessibility enable karein.")
        }

        // --- Volume ---
        if (cleanInput.contains("volume up") || cleanInput.contains("awaz badhao")) {
            BNAccessibilityService.adjustVolume(context, raise = true)
            return VoiceCommandResult.ActionExecuted("Volume Up", "Awaz badha di.")
        }
        if (cleanInput.contains("volume down") || cleanInput.contains("awaz kam karo")) {
            BNAccessibilityService.adjustVolume(context, raise = false)
            return VoiceCommandResult.ActionExecuted("Volume Down", "Awaz kam kar di.")
        }

        // --- Time & Date ---
        if (cleanInput.contains("time") || cleanInput.contains("samay")) {
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            return VoiceCommandResult.AiResponse("Samay: $timeStr hai.")
        }
        if (cleanInput.contains("date") || cleanInput.contains("tareekh")) {
            val dateStr = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            return VoiceCommandResult.AiResponse("Aaj $dateStr hai.")
        }

        // --- Battery ---
        if (cleanInput.contains("battery") || cleanInput.contains("batt")) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val batLevel = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            val reply = if (batLevel >= 0) "Battery $batLevel% hai." else "Battery info nahi mil pa raha."
            return VoiceCommandResult.AiResponse(reply)
        }

        // --- Screenshot ---
        if (cleanInput.contains("screenshot") || cleanInput.contains("screen shot")) {
            val success = BNAccessibilityService.performScreenshot()
            return VoiceCommandResult.ActionExecuted("Screenshot", if (success) "Screenshot le raha hoon." else "Accessibility enable karein.")
        }

        return null
    }

    private fun setTorchState(enabled: Boolean) {
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enabled)
            }
        } catch (e: Exception) {
            Log.e("VoiceAssistantRepo", "Torch error", e)
        }
    }
}