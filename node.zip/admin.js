const database = require('./database');
const Keyboards = require('./keybeod');

class Admin {
    constructor(bot) {
        this.bot = bot;
    }

    async handleAdminCommand(msg) {
        const chatId = msg.chat.id;
        const text = msg.text;
        const userId = msg.from.id;

        switch(text) {
            case '👑 Admin Panel':
                await this.showAdminPanel(chatId);
                break;
            case '👥 View All Users':
                await this.viewAllUsers(chatId);
                break;
            case '🚫 Ban User':
                await this.promptBanUser(chatId);
                break;
            case '✅ Unban User':
                await this.promptUnbanUser(chatId);
                break;
            case '📢 Broadcast':
                await this.promptBroadcast(chatId);
                break;
            case '🔙 Back to Main Menu':
                await this.bot.sendMessage(chatId, 'Back to main menu', Keyboards.mainMenu());
                break;
            default:
                // Handle ban/unban with user ID
                if (text.startsWith('ban_')) {
                    const userIdToBan = text.split('_')[1];
                    await this.processBan(chatId, userIdToBan);
                } else if (text.startsWith('unban_')) {
                    const userIdToUnban = text.split('_')[1];
                    await this.processUnban(chatId, userIdToUnban);
                }
        }
    }

    async showAdminPanel(chatId) {
        await this.bot.sendMessage(
            chatId,
            '👑 *Admin Panel*\n\nSelect an option:',
            {
                parse_mode: 'Markdown',
                ...Keyboards.adminPanel()
            }
        );
    }

    async viewAllUsers(chatId) {
        const users = await database.getAllUsers();
        
        if (users.length === 0) {
            await this.bot.sendMessage(chatId, 'No users found.');
            return;
        }

        let message = '👥 *All Users*\n\n';
        users.forEach((user, index) => {
            const status = user.is_banned ? '🚫 Banned' : '✅ Active';
            message += `${index + 1}. User: ${user.first_name || 'Unknown'}\n`;
            message += `   ID: ${user.user_id}\n`;
            message += `   Username: @${user.username || 'N/A'}\n`;
            message += `   Status: ${status}\n`;
            message += `   Joined: ${new Date(user.created_at).toLocaleString()}\n\n`;
        });

        // Add ban/unban buttons
        const inlineKeyboard = {
            reply_markup: {
                inline_keyboard: users.map(user => [
                    {
                        text: `${user.is_banned ? '✅ Unban' : '🚫 Ban'} ${user.first_name || user.user_id}`,
                        callback_data: `${user.is_banned ? 'unban' : 'ban'}_${user.user_id}`
                    }
                ])
            }
        };

        await this.bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown',
            ...inlineKeyboard
        });
    }

    async promptBanUser(chatId) {
        await this.bot.sendMessage(
            chatId,
            '🚫 *Ban User*\n\nPlease enter the User ID to ban:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    force_reply: true
                }
            }
        );
    }

    async promptUnbanUser(chatId) {
        await this.bot.sendMessage(
            chatId,
            '✅ *Unban User*\n\nPlease enter the User ID to unban:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    force_reply: true
                }
            }
        );
    }

    async processBan(chatId, userId) {
        try {
            await database.banUser(parseInt(userId));
            await this.bot.sendMessage(
                chatId,
                `✅ User ${userId} has been banned successfully.`
            );
            await this.showAdminPanel(chatId);
        } catch (error) {
            await this.bot.sendMessage(
                chatId,
                `❌ Failed to ban user: ${error.message}`
            );
        }
    }

    async processUnban(chatId, userId) {
        try {
            await database.unbanUser(parseInt(userId));
            await this.bot.sendMessage(
                chatId,
                `✅ User ${userId} has been unban successfully.`
            );
            await this.showAdminPanel(chatId);
        } catch (error) {
            await this.bot.sendMessage(
                chatId,
                `❌ Failed to unban user: ${error.message}`
            );
        }
    }

    async promptBroadcast(chatId) {
        await this.bot.sendMessage(
            chatId,
            '📢 *Broadcast Message*\n\nPlease send the message you want to broadcast to all users.',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    force_reply: true
                }
            }
        );
    }

    async processBroadcast(chatId, message) {
        try {
            const users = await database.getAllUsers();
            let successCount = 0;
            let failCount = 0;

            for (const user of users) {
                try {
                    await this.bot.sendMessage(user.user_id, message, {
                        parse_mode: 'HTML'
                    });
                    successCount++;
                    await this.delay(100); // Rate limiting
                } catch (error) {
                    failCount++;
                }
            }

            await this.bot.sendMessage(
                chatId,
                `📢 *Broadcast Complete*\n\n✅ Success: ${successCount}\n❌ Failed: ${failCount}`,
                {
                    parse_mode: 'Markdown'
                }
            );
            await this.showAdminPanel(chatId);
        } catch (error) {
            await this.bot.sendMessage(
                chatId,
                `❌ Broadcast failed: ${error.message}`
            );
        }
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    isAdmin(userId) {
        const { ADMIN_ID } = require('./config');
        return userId === ADMIN_ID;
    }
}

module.exports = Admin;