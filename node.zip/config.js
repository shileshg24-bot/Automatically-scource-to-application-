require('dotenv').config();

module.exports = {
    BOT_TOKEN: process.env.BOT_TOKEN,
    ADMIN_ID: parseInt(process.env.ADMIN_ID),
    SESSION_DIR: './sessions',
    DB_PATH: './database.sqlite'
};