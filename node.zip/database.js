const sqlite3 = require('sqlite3').verbose();
const { DB_PATH } = require('./config');
const fs = require('fs-extra');

class Database {
    constructor() {
        this.db = null;
        this.init();
    }

    init() {
        // Ensure directory exists
        fs.ensureDirSync('./');
        
        this.db = new sqlite3.Database(DB_PATH);
        this.createTables();
    }

    createTables() {
        this.db.run(`
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                is_banned BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
    }

    // User methods
    saveUser(userId, username, firstName, lastName) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `INSERT OR REPLACE INTO users (user_id, username, first_name, last_name) 
                 VALUES (?, ?, ?, ?)`,
                [userId, username, firstName, lastName],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    getUser(userId) {
        return new Promise((resolve, reject) => {
            this.db.get(
                `SELECT * FROM users WHERE user_id = ?`,
                [userId],
                (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                }
            );
        });
    }

    getAllUsers() {
        return new Promise((resolve, reject) => {
            this.db.all(
                `SELECT * FROM users ORDER BY created_at DESC`,
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    }

    banUser(userId) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE users SET is_banned = 1 WHERE user_id = ?`,
                [userId],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }

    unbanUser(userId) {
        return new Promise((resolve, reject) => {
            this.db.run(
                `UPDATE users SET is_banned = 0 WHERE user_id = ?`,
                [userId],
                (err) => {
                    if (err) reject(err);
                    else resolve();
                }
            );
        });
    }
}

module.exports = new Database();