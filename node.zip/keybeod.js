class Keyboards {
    static mainMenu() {
        return {
            reply_markup: {
                keyboard: [
                    [
                        { text: '𝒄𝒓𝒆𝒂𝒕𝒆 𝒔𝒆𝒔𝒔𝒊𝒐𝒏' },
                        { text: '𝒓𝒆𝒂𝒅 𝑶𝑻𝑷' }
                    ],
                    [
                        { text: '👑 Admin Panel' }
                    ]
                ],
                resize_keyboard: true,
                one_time_keyboard: false
            }
        };
    }

    static adminPanel() {
        return {
            reply_markup: {
                keyboard: [
                    [
                        { text: '👥 View All Users' },
                        { text: '🚫 Ban User' }
                    ],
                    [
                        { text: '✅ Unban User' },
                        { text: '📢 Broadcast' }
                    ],
                    [
                        { text: '🔙 Back to Main Menu' }
                    ]
                ],
                resize_keyboard: true,
                one_time_keyboard: false
            }
        };
    }

    static cancelButton() {
        return {
            reply_markup: {
                keyboard: [
                    [
                        { text: '❌ Cancel' }
                    ]
                ],
                resize_keyboard: true,
                one_time_keyboard: true
            }
        };
    }

    static inlineOTPCheck(userId, number) {
        return {
            reply_markup: {
                inline_keyboard: [
                    [
                        {
                            text: '👇 Check OTP',
                            callback_data: `check_otp_${userId}_${number}`
                        }
                    ]
                ]
            }
        };
    }
}

module.exports = Keyboards;