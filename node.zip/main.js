const TelegramBot = require('node-telegram-bot-api');
const Keyboards = require('./keybeod');
const database = require('./database');
const sessionManager = require('./sessionManager');
const Admin = require('./admin');
const { BOT_TOKEN, ADMIN_ID } = require('./config');
const fs = require('fs-extra');

// Initialize bot
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const admin = new Admin(bot);

// State management
const userStates = {};
const sessionData = {};

console.log('🚀 Bot started successfully!');
console.log(`👑 Admin ID: ${ADMIN_ID}`);

// Middleware to check user ban status
async function checkUserBan(userId) {
    const user = await database.getUser(userId);
    return user ? user.is_banned === 1 : false;
}

// Handle /start command
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username;
    const firstName = msg.from.first_name;
    const lastName = msg.from.last_name;

    // Save user to database
    await database.saveUser(userId, username, firstName, lastName);

    // Check if user is banned
    const isBanned = await checkUserBan(userId);
    if (isBanned) {
        await bot.sendMessage(
            chatId,
            '🚫 You are banned from using this bot.'
        );
        return;
    }

    // Clear state
    delete userStates[userId];

    // Send welcome message with main menu
    await bot.sendMessage(
        chatId,
        `👋 Welcome ${firstName || 'User'}!\n\n` +
        'I can help you create and read Telegram sessions.\n' +
        'Please select an option from below:',
        Keyboards.mainMenu()
    );
});

// Handle text messages
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = msg.text;
    const username = msg.from.username;
    const firstName = msg.from.first_name;
    const lastName = msg.from.last_name;

    // Save user to database
    await database.saveUser(userId, username, firstName, lastName);

    // Check if user is banned
    const isBanned = await checkUserBan(userId);
    if (isBanned) {
        await bot.sendMessage(
            chatId,
            '🚫 You are banned from using this bot.'
        );
        return;
    }

    // Handle admin commands
    if (admin.isAdmin(userId) && text.startsWith('👑')) {
        await admin.handleAdminCommand(msg);
        return;
    }

    // Handle reply messages for admin actions
    if (msg.reply_to_message && admin.isAdmin(userId)) {
        const replyText = msg.reply_to_message.text;
        if (replyText.includes('Ban User')) {
            await admin.processBan(chatId, text);
            return;
        } else if (replyText.includes('Unban User')) {
            await admin.processUnban(chatId, text);
            return;
        } else if (replyText.includes('Broadcast')) {
            await admin.processBroadcast(chatId, text);
            return;
        }
    }

    // Handle main menu commands
    if (text === '𝒄𝒓𝒆𝒂𝒕𝒆 𝒔𝒆𝒔𝒔𝒊𝒐𝒏') {
        userStates[userId] = 'awaiting_phone';
        await bot.sendMessage(
            chatId,
            'BNDEVLOPER:\n📞 Input your number Ex: +1234567890',
            Keyboards.cancelButton()
        );
        return;
    }

    if (text === '𝒓𝒆𝒂𝒅 𝑶𝑻𝑷') {
        userStates[userId] = 'awaiting_zip';
        await bot.sendMessage(
            chatId,
            'TG-BOT:\n𝒓𝒆𝒂𝒅 𝑶𝑻𝑷\n\n📤 Please Send your ZIP file',
            Keyboards.cancelButton()
        );
        return;
    }

    if (text === '❌ Cancel') {
        delete userStates[userId];
        await bot.sendMessage(
            chatId,
            '❌ Operation cancelled.',
            Keyboards.mainMenu()
        );
        return;
    }

    // Handle phone number input
    if (userStates[userId] === 'awaiting_phone' && text.startsWith('+')) {
        try {
            await bot.sendMessage(
                chatId,
                '♻️ Processing...\n\nTG-BOT:\n' + text,
                { parse_mode: 'HTML' }
            );

            // Create session
            const result = await sessionManager.createSession(userId, text);
            
            // Simulate OTP request
            const otp = sessionManager.generateOTP();
            
            await bot.sendMessage(
                chatId,
                `✅ Session Created!\n\n` +
                `🔐 Input OTP Code:\n` +
                `TG-BOT:\n${otp}\n\n` +
                `🔐 Input Your Password:\n` +
                `✅ Session Active\n` +
                `✅ Reinhold [@None] [${text}]`,
                Keyboards.mainMenu()
            );

            // Send session file
            await bot.sendDocument(
                chatId,
                result.zipPath,
                {},
                { caption: '📁 Your session file is ready!' }
            );

            delete userStates[userId];

        } catch (error) {
            await bot.sendMessage(
                chatId,
                `❌ Error: ${error.message}`,
                Keyboards.mainMenu()
            );
        }
        return;
    }

    // Handle ZIP file for OTP reading
    if (userStates[userId] === 'awaiting_zip' && msg.document) {
        try {
            const file = msg.document;
            if (!file.file_name.endsWith('.zip')) {
                await bot.sendMessage(
                    chatId,
                    '❌ Please send a valid ZIP file.',
                    Keyboards.cancelButton()
                );
                return;
            }

            await bot.sendMessage(
                chatId,
                '♻️ Processing...\n🙏 Please wait.',
                { parse_mode: 'HTML' }
            );

            // Download file
            const fileLink = await bot.getFileLink(file.file_id);
            const fileBuffer = await downloadFile(fileLink);
            
            // Process sessions
            const results = await sessionManager.processSessionBatch(fileBuffer);
            
            let message = '📊 *Session Processing Results*\n\n';
            let hasSuccess = false;
            
            for (const result of results) {
                if (result.status === 'corrupt') {
                    message += `💀 ${result.fileName}\n❌ ${result.message}\n\n`;
                } else if (result.status === 'error') {
                    message += `⚠️ ${result.fileName}\n‼️ ${result.message}\n\n`;
                } else if (result.status === 'success') {
                    hasSuccess = true;
                    message += `✅ ${result.fileName}\n${result.message}\n\n`;
                    
                    // Send OTP check for successful sessions
                    const user = result.user;
                    await bot.sendMessage(
                        chatId,
                        `👤 User: ${user.name}\n📱 Number: ${user.number}`,
                        Keyboards.inlineOTPCheck(userId, user.number)
                    );
                }
            }
            
            message += hasSuccess ? '\n✅ All sessions have been processed.' : '';
            
            await bot.sendMessage(
                chatId,
                message,
                {
                    parse_mode: 'Markdown',
                    ...Keyboards.mainMenu()
                }
            );
            
            delete userStates[userId];

        } catch (error) {
            await bot.sendMessage(
                chatId,
                `❌ Error: ${error.message}`,
                Keyboards.mainMenu()
            );
            delete userStates[userId];
        }
        return;
    }

    // Handle invalid input
    if (userStates[userId]) {
        await bot.sendMessage(
            chatId,
            '❌ Invalid input. Please follow the instructions.',
            Keyboards.cancelButton()
        );
    }
});

// Handle callback queries
bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;

    if (data.startsWith('check_otp_')) {
        const parts = data.split('_');
        const userNumber = parts[2];
        const otp = sessionManager.generateOTP();
        
        await bot.sendMessage(
            chatId,
            `👤 User: Reinhold\n📱 Number: ${userNumber}\n\n🧩 Your OTP Code : ${otp}`
        );

        await bot.answerCallbackQuery(callbackQuery.id, {
            text: '✅ OTP sent!'
        });
    }

    // Handle admin callback queries
    if (data.startsWith('ban_')) {
        const userIdToBan = data.split('_')[1];
        await admin.processBan(chatId, parseInt(userIdToBan));
        await bot.answerCallbackQuery(callbackQuery.id, {
            text: '✅ User banned successfully!'
        });
    } else if (data.startsWith('unban_')) {
        const userIdToUnban = data.split('_')[1];
        await admin.processUnban(chatId, parseInt(userIdToUnban));
        await bot.answerCallbackQuery(callbackQuery.id, {
            text: '✅ User unbanned successfully!'
        });
    }
});

// Helper function to download file
async function downloadFile(fileLink) {
    const axios = require('axios');
    const response = await axios.get(fileLink, {
        responseType: 'arraybuffer'
    });
    return response.data;
}

// Error handling
bot.on('polling_error', (error) => {
    console.error('Polling error:', error);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('Bot stopping...');
    process.exit();
});