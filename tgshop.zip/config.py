# ============================================
# CONFIGURATION
# ============================================

API_ID = 33046011
API_HASH = '6bd46e302f0be57a76f567cb53e19c20'
BOT_TOKEN = '8375462995:AAF5oHfc4ChOE38bTLkuDiorjSlXwzkMOTI'
ADMIN_ID = 8344477162

# Database file
DATA_FILE = 'data.json'

# ============================================
# PAYMENT GATEWAY CONFIG (LGPayment)
# ============================================

PAYMENT_CONFIG = {
    "app_id": "YD4660",
    "key": "d1gbarH6xKQWI8AEM806LFb5Mc10eON7",
    "api_url": "https://www.lg-pay.com/api",
    "trade_type": "INRUPI",
    "notify_url": "https://17clubgame.us.cc/api/payment/callback",
    "return_url": "https://17clubgame.us.cc/api/payment/return"
}