import json
import os
from datetime import datetime
from config import DATA_FILE

# ============================================
# DATABASE INITIALIZATION
# ============================================

def init_db():
    if not os.path.exists(DATA_FILE):
        default_data = {
            "users": {},
            "orders": [],
            "buy_history": {},
            "settings": {
                "paid_store_link": "https://t.me/your_channel",
                "selling_proof_link": "https://t.me/your_proof_channel",
                "min_amount": 10,
                "max_amount": 5000,
                "upi_id": "your_upi@upi",
                "support_link": "https://t.me/your_support"
            },
            "keys": [],
            "categories": [],
            "payments": [],
            "pending_payments": [],
            "manual_payment": {
                "upi_id": "your_upi@upi",
                "qr_image": "",
                "instructions": "Pay via UPI and send screenshot"
            }
        }
        with open(DATA_FILE, 'w') as f:
            json.dump(default_data, f, indent=4)
    else:
        try:
            with open(DATA_FILE, 'r') as f:
                json.load(f)
        except json.JSONDecodeError:
            print("⚠️ data.json corrupted! Recreating...")
            default_data = {
                "users": {},
                "orders": [],
                "buy_history": {},
                "settings": {
                    "paid_store_link": "https://t.me/your_channel",
                    "selling_proof_link": "https://t.me/your_proof_channel",
                    "min_amount": 10,
                    "max_amount": 5000,
                    "upi_id": "your_upi@upi",
                    "support_link": "https://t.me/your_support"
                },
                "keys": [],
                "categories": [],
                "payments": [],
                "pending_payments": [],
                "manual_payment": {
                    "upi_id": "your_upi@upi",
                    "qr_image": "",
                    "instructions": "Pay via UPI and send screenshot"
                }
            }
            with open(DATA_FILE, 'w') as f:
                json.dump(default_data, f, indent=4)


def load_data():
    try:
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        init_db()
        with open(DATA_FILE, 'r') as f:
            return json.load(f)


def save_data(data):
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, 'r') as f:
                json.load(f)
        except json.JSONDecodeError:
            print("⚠️ Not saving - data.json is corrupted")
            return
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)


# ============================================
# USER FUNCTIONS
# ============================================

def get_user(user_id):
    data = load_data()
    return data['users'].get(str(user_id))


def add_user(user_id, name):
    data = load_data()
    user_id_str = str(user_id)
    if user_id_str not in data['users']:
        data['users'][user_id_str] = {
            "balance": 0,
            "joined": str(datetime.now()),
            "name": name
        }
        data['buy_history'][user_id_str] = []
        save_data(data)
        return True
    return False


def get_all_users():
    data = load_data()
    return data['users']


def get_balance(user_id):
    data = load_data()
    return data['users'].get(str(user_id), {}).get('balance', 0)


def add_balance(user_id, amount):
    data = load_data()
    user_id_str = str(user_id)
    if user_id_str in data['users']:
        data['users'][user_id_str]['balance'] += amount
        save_data(data)
        return True
    return False


def deduct_balance(user_id, amount):
    data = load_data()
    user_id_str = str(user_id)
    if user_id_str in data['users']:
        if data['users'][user_id_str]['balance'] >= amount:
            data['users'][user_id_str]['balance'] -= amount
            save_data(data)
            return True
    return False


# ============================================
# ORDER / HISTORY FUNCTIONS
# ============================================

def add_order(user_id, product, amount, status="Pending", key=None, hours=None, file_link=None):
    data = load_data()
    order = {
        "product": product,
        "amount": amount,
        "date": datetime.now().strftime("%d-%m-%Y %H:%M"),
        "status": status
    }
    if key:
        order['key'] = key
    if hours:
        order['hours'] = hours
    if file_link:
        order['file_link'] = file_link
    
    data['buy_history'].setdefault(str(user_id), []).append(order)
    save_data(data)
    return True


def get_history(user_id):
    data = load_data()
    return data['buy_history'].get(str(user_id), [])


def get_all_orders():
    data = load_data()
    all_orders = []
    for uid, orders in data['buy_history'].items():
        for order in orders:
            all_orders.append({"uid": uid, **order})
    return all_orders


def get_total_orders():
    data = load_data()
    total = 0
    for uid in data['buy_history']:
        total += len(data['buy_history'][uid])
    return total


# ============================================
# PAYMENT FUNCTIONS
# ============================================

def add_payment(user_id, order_id, amount, status="pending", method="MANUAL"):
    data = load_data()
    if 'payments' not in data:
        data['payments'] = []
    
    data['payments'].append({
        "user_id": str(user_id),
        "order_id": order_id,
        "amount": amount,
        "method": method,
        "status": status,
        "date": str(datetime.now())
    })
    save_data(data)
    return True


def update_payment_status(order_id, status):
    data = load_data()
    if 'payments' not in data:
        return False
    
    for payment in data['payments']:
        if payment['order_id'] == order_id:
            payment['status'] = status
            save_data(data)
            return True
    return False


def get_payment(order_id):
    data = load_data()
    if 'payments' not in data:
        return None
    
    for payment in data['payments']:
        if payment['order_id'] == order_id:
            return payment
    return None


# ============================================
# MANUAL PAYMENT FUNCTIONS
# ============================================

def get_manual_payment():
    """Get manual payment settings"""
    data = load_data()
    if 'manual_payment' not in data:
        data['manual_payment'] = {
            "upi_id": "your_upi@upi",
            "qr_image": "",
            "instructions": "Pay via UPI and send screenshot"
        }
        save_data(data)
    return data['manual_payment']


def update_manual_payment(upi_id, qr_image, instructions):
    """Update manual payment settings"""
    data = load_data()
    data['manual_payment'] = {
        "upi_id": upi_id,
        "qr_image": qr_image,
        "instructions": instructions
    }
    save_data(data)
    return True


def get_pending_payments():
    """Get all pending payments"""
    data = load_data()
    return data.get('pending_payments', [])


def add_pending_payment(user_id, amount, order_id):
    """Add pending payment"""
    data = load_data()
    if 'pending_payments' not in data:
        data['pending_payments'] = []
    
    data['pending_payments'].append({
        "user_id": str(user_id),
        "amount": amount,
        "order_id": order_id,
        "status": "pending",
        "date": str(datetime.now())
    })
    save_data(data)
    return True


def approve_payment(order_id):
    """Approve payment"""
    data = load_data()
    if 'pending_payments' not in data:
        return False
    
    for payment in data['pending_payments']:
        if payment['order_id'] == order_id:
            payment['status'] = 'approved'
            save_data(data)
            return True
    return False


# ============================================
# KEY FUNCTIONS
# ============================================

def get_all_keys():
    """Get all available keys"""
    data = load_data()
    return data['keys']


def add_key_to_db(key, price, hours):
    """Add new key with price and hours"""
    data = load_data()
    data['keys'].append({
        "key": key,
        "price": price,
        "hours": hours
    })
    save_data(data)
    return True


def remove_key_from_db(index):
    """Remove key by index and return it"""
    data = load_data()
    if 0 <= index < len(data['keys']):
        key_data = data['keys'].pop(index)
        save_data(data)
        return key_data
    return None


def get_keys_count():
    """Get total number of available keys"""
    data = load_data()
    return len(data['keys'])


# ============================================
# CATEGORY FUNCTIONS
# ============================================

def get_all_categories():
    data = load_data()
    return data.get('categories', [])


def add_category(name, icon="📦"):
    data = load_data()
    if 'categories' not in data:
        data['categories'] = []
    
    for cat in data['categories']:
        if cat['name'].lower() == name.lower():
            return False
    
    data['categories'].append({
        "name": name.upper(),
        "icon": icon,
        "products": [],
        "created": str(datetime.now())
    })
    save_data(data)
    return True


def remove_category(index):
    data = load_data()
    if 'categories' not in data:
        return None
    if 0 <= index < len(data['categories']):
        cat = data['categories'].pop(index)
        save_data(data)
        return cat
    return None


def get_category_products(category_index):
    data = load_data()
    if 'categories' not in data:
        return []
    if 0 <= category_index < len(data['categories']):
        return data['categories'][category_index].get('products', [])
    return []


def add_product_to_category(category_index, name, price, file_link, file_type, stock="Unlimited", icon="📦"):
    data = load_data()
    if 'categories' not in data:
        return False
    if 0 <= category_index < len(data['categories']):
        if stock.upper() == 'U':
            stock = 'Unlimited'
        
        data['categories'][category_index]['products'].append({
            "name": name,
            "price": price,
            "file_link": file_link,
            "file_type": file_type,
            "stock": stock,
            "icon": icon,
            "sold": 0,
            "added_date": str(datetime.now())
        })
        save_data(data)
        return True
    return False


def remove_product_from_category(category_index, product_index):
    data = load_data()
    if 'categories' not in data:
        return None
    if 0 <= category_index < len(data['categories']):
        products = data['categories'][category_index].get('products', [])
        if 0 <= product_index < len(products):
            product = products.pop(product_index)
            save_data(data)
            return product
    return None


def get_category_count():
    """Get total number of categories"""
    data = load_data()
    return len(data.get('categories', []))


# ============================================
# PRODUCT FUNCTIONS (Legacy)
# ============================================

def get_all_products():
    data = load_data()
    all_products = []
    for cat in data.get('categories', []):
        for product in cat.get('products', []):
            product['category'] = cat.get('name', 'Unknown')
            all_products.append(product)
    return all_products


def buy_product(user_id, index):
    products = get_all_products()
    if index >= len(products):
        return {"error": "Product not found"}
    
    product = products[index]
    
    data = load_data()
    for cat_idx, cat in enumerate(data.get('categories', [])):
        for prod_idx, p in enumerate(cat.get('products', [])):
            if (p['name'] == product['name'] and 
                p['price'] == product['price'] and
                p['file_link'] == product['file_link']):
                return buy_product_from_category(user_id, cat_idx, prod_idx)
    
    return {"error": "Product not found in any category"}


def buy_product_from_category(user_id, category_index, product_index):
    try:
        data = load_data()
        
        if 'categories' not in data:
            return {"error": "No categories found"}
        
        if category_index >= len(data['categories']):
            return {"error": "Category not found"}
        
        products = data['categories'][category_index].get('products', [])
        if product_index >= len(products):
            return {"error": "Product not found"}
        
        product = products[product_index]
        
        stock_value = product.get('stock', 'Unlimited')
        if stock_value != "Unlimited":
            try:
                stock = int(stock_value)
                if stock <= 0:
                    return {"error": "Out of stock!"}
            except (ValueError, TypeError):
                return {"error": "Invalid stock value"}
        
        if stock_value != "Unlimited":
            try:
                current_stock = int(stock_value)
                product['stock'] = str(current_stock - 1)
            except (ValueError, TypeError):
                return {"error": "Stock deduct failed"}
        
        product['sold'] = product.get('sold', 0) + 1
        save_data(data)
        
        return {
            "name": product.get('name', 'N/A'),
            "price": product.get('price', 0),
            "file_link": product.get('file_link', '#'),
            "file_type": product.get('file_type', 'file'),
            "stock": product.get('stock', 'Unlimited'),
            "icon": product.get('icon', '📦'),
            "sold": product.get('sold', 0)
        }
        
    except Exception as e:
        print(f"❌ buy_product_from_category error: {e}")
        return {"error": str(e)}


# ============================================
# APK FUNCTIONS (Legacy)
# ============================================

def get_all_apks():
    return get_all_products()


def add_apk_to_db(name, version, size, price, download_link):
    categories = get_all_categories()
    cat_index = -1
    for i, cat in enumerate(categories):
        if cat['name'] == 'APPS':
            cat_index = i
            break
    
    if cat_index == -1:
        add_category('APPS', '📱')
        cat_index = len(get_all_categories()) - 1
    
    return add_product_to_category(cat_index, f"{name} v{version} ({size})", price, download_link, 'apk', 'Unlimited', '📱')


def remove_apk_from_db(index):
    return remove_product_from_category(0, index)


def get_apks_count():
    return len(get_all_products())


# ============================================
# SETTINGS FUNCTIONS
# ============================================

def update_setting(setting_name, value):
    data = load_data()
    data['settings'][setting_name] = value
    save_data(data)
    return True


def get_stats():
    data = load_data()
    total_cat_products = 0
    for cat in data.get('categories', []):
        total_cat_products += len(cat.get('products', []))
    
    return {
        "total_users": len(data['users']),
        "total_keys": len(data['keys']),
        "total_categories": len(data.get('categories', [])),
        "total_products": total_cat_products,
        "total_orders": get_total_orders(),
        "min_amount": data['settings'].get('min_amount', 10),
        "max_amount": data['settings'].get('max_amount', 5000),
        "pending_payments": len(data.get('pending_payments', []))
    }


# ============================================
# RESET / CLEAR FUNCTIONS
# ============================================

def reset_user_balance(user_id):
    data = load_data()
    user_id_str = str(user_id)
    if user_id_str in data['users']:
        data['users'][user_id_str]['balance'] = 0
        save_data(data)
        return True
    return False


def clear_user_history(user_id):
    data = load_data()
    user_id_str = str(user_id)
    if user_id_str in data['buy_history']:
        data['buy_history'][user_id_str] = []
        save_data(data)
        return True
    return False


def reset_all_keys():
    data = load_data()
    data['keys'] = []
    save_data(data)
    return True