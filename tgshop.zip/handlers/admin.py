from telethon import events
from telethon.tl.types import KeyboardButtonCallback
from config import ADMIN_ID
from database import (
    load_data, save_data, get_all_keys, add_key_to_db, remove_key_from_db,
    get_all_categories, add_category, remove_category, get_category_products,
    add_product_to_category, remove_product_from_category,
    get_all_users, add_balance, get_all_orders, get_stats, get_keys_count,
    get_category_count
)
from handlers.menu import get_admin_menu
from datetime import datetime

# ============================================
# ADMIN PANEL
# ============================================

async def admin_panel_handler(event):
    if event.sender_id != ADMIN_ID:
        await event.answer("❌ Sirf admin ke liye!", alert=True)
        return
    await event.edit("🔐 **Admin Panel**\n\nKya karna hai?", buttons=get_admin_menu())


async def admin_stats_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    stats = get_stats()
    msg = f"""📊 **Stats**

👥 Users: {stats['total_users']}
🔑 Keys: {stats['total_keys']}
📂 Categories: {stats['total_categories']}
📦 Products: {stats['total_products']}
📦 Orders: {stats['total_orders']}
💰 Min: ₹{stats['min_amount']}
💰 Max: ₹{stats['max_amount']}"""
    await event.edit(msg, buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def admin_orders_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    orders = get_all_orders()
    if not orders:
        await event.edit("📦 Koi order nahi!", buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])
        return
    
    msg = "📦 **All Orders (Last 10)**\n\n"
    for i, order in enumerate(orders[-10:], 1):
        msg += f"""{i}. 👤 {order['uid']}
📦 {order.get('product', 'N/A')}
💰 ₹{order.get('amount', 0)}
📅 {order.get('date', 'N/A')}
✅ {order.get('status', 'Pending')}
━━━━━━━━━━━━━━━━\n"""
    await event.edit(msg, buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def admin_history_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    stats = get_stats()
    await event.edit(f"📜 **All History**\n\n👥 Users: {stats['total_users']}\n📦 Orders: {stats['total_orders']}", 
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


# ============================================
# ADMIN KEYS
# ============================================

async def admin_add_key_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit(
        "🔑 **Add New Key**\n\n"
        "Format: `/addkey <key> <price> <hours>`\n\n"
        "Example: `/addkey ABC123-XYZ 100 1`",
        buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]]
    )


async def add_key_command(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split()
    if len(parts) != 4:
        await event.reply("❌ Format: `/addkey <key> <price> <hours>`")
        return
    
    key = parts[1]
    try:
        price = int(parts[2])
        hours = int(parts[3])
    except ValueError:
        await event.reply("❌ Price and Hours must be numbers!")
        return
    
    add_key_to_db(key, price, hours)
    await event.reply(f"✅ Key added!\n🔑 `{key}`\n💰 ₹{price}\n⏱️ {hours}h")


async def admin_view_keys_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    keys = get_all_keys()
    if not keys:
        await event.edit("📦 **All Keys**\n\n❌ Koi key nahi hai!", 
                        buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])
        return
    
    msg = "📦 **All Keys**\n━━━━━━━━━━━━━━━━━━━━━\n"
    for i, k in enumerate(keys):
        msg += f"{i+1}. 🔑 `{k['key']}` | ₹{k['price']} | {k['hours']}h\n"
    msg += "\n🗑️ Delete: `/delkey <number>`"
    await event.edit(msg, buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def delete_key_command(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split()
    if len(parts) != 2:
        await event.reply("❌ Format: `/delkey <number>`")
        return
    
    try:
        index = int(parts[1]) - 1
    except ValueError:
        await event.reply("❌ Enter a valid number!")
        return
    
    removed = remove_key_from_db(index)
    if removed:
        await event.reply(f"✅ Key deleted: `{removed['key']}`")
    else:
        await event.reply("❌ Key not found!")


# ============================================
# ADMIN CATEGORIES (Custom Buttons)
# ============================================

async def admin_add_category_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit(
        "📂 **Add New Category/Button**\n\n"
        "Format: `/addcategory <name>`\n\n"
        "Example: `/addcategory MOD`\n"
        "Example: `/addcategory APPS`\n"
        "Example: `/addcategory GAMES`\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        "📌 Category button user menu mein dikhega!\n"
        "📌 Phir us category mein products add kar sakte ho.",
        buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]]
    )


async def add_category_command(event):
    if event.sender_id != ADMIN_ID:
        return
    
    parts = event.text.split(maxsplit=1)
    if len(parts) != 2:
        await event.reply(
            "❌ Format: `/addcategory <name>`\n\n"
            "Example: `/addcategory MOD`"
        )
        return
    
    name = parts[1].upper()
    
    if add_category(name):
        await event.reply(f"✅ **Category Added!**\n\n📂 {name}\n\n📌 User menu mein dikhegi!")
    else:
        await event.reply(f"❌ Category `{name}` already exists!")


async def admin_view_categories_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    
    categories = get_all_categories()
    
    if not categories:
        await event.edit(
            "📂 **Categories**\n\n❌ Koi category nahi hai!\n\n"
            "Add: `/addcategory <name>`",
            buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]]
        )
        return
    
    msg = "📂 **All Categories**\n━━━━━━━━━━━━━━━━━━━━━\n"
    for i, cat in enumerate(categories):
        name = cat.get('name', 'N/A')
        icon = cat.get('icon', '📦')
        product_count = len(cat.get('products', []))
        msg += f"{i+1}. {icon} {name}  |  📦 {product_count} products\n"
    
    msg += "\n━━━━━━━━━━━━━━━━━━━━━\n"
    msg += "🗑️ Delete: `/delcategory <number>`\n"
    msg += "📦 Add Product: `/addproducttocat <cat_number> <name> <price> <link> <type> <stock>`\n"
    msg += "📦 View Products: `/viewcatproducts <cat_number>`"
    
    await event.edit(msg, buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def delete_category_command(event):
    if event.sender_id != ADMIN_ID:
        return
    
    parts = event.text.split()
    if len(parts) != 2:
        await event.reply("❌ Format: `/delcategory <number>`")
        return
    
    try:
        index = int(parts[1]) - 1
    except ValueError:
        await event.reply("❌ Enter a valid number!")
        return
    
    removed = remove_category(index)
    if removed:
        await event.reply(f"✅ Category deleted: {removed['name']}")
    else:
        await event.reply("❌ Category not found!")


async def add_product_to_category_command(event):
    if event.sender_id != ADMIN_ID:
        return
    
    parts = event.text.split(maxsplit=6)
    if len(parts) != 7:
        await event.reply(
            "❌ Format: `/addproducttocat <cat_number> <name> <price> <file_link> <file_type> <stock>`\n\n"
            "Example: `/addproducttocat 1 MyApp 100 https://link.com/app.apk apk Unlimited`\n"
            "Example: `/addproducttocat 1 ModGame 50 https://link.com/mod.zip zip 10`"
        )
        return
    
    try:
        cat_index = int(parts[1]) - 1
    except ValueError:
        await event.reply("❌ Category number must be a number!")
        return
    
    name = parts[2]
    try:
        price = int(parts[3])
    except ValueError:
        await event.reply("❌ Price must be a number!")
        return
    file_link = parts[4]
    file_type = parts[5]
    stock = parts[6]
    
    if price <= 0:
        await event.reply("❌ Price must be greater than 0!")
        return
    
    icons = {"apk": "📱", "zip": "📦", "mod": "🔧", "file": "📄"}
    icon = icons.get(file_type.lower(), "📦")
    
    if add_product_to_category(cat_index, name, price, file_link, file_type, stock, icon):
        await event.reply(f"✅ **Product Added!**\n\n📦 {name}\n💰 ₹{price}\n📁 {file_type}\n📦 Stock: {stock}")
    else:
        await event.reply("❌ Category not found!")


async def view_category_products_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    
    parts = event.text.split()
    if len(parts) != 2:
        await event.reply("❌ Format: `/viewcatproducts <cat_number>`")
        return
    
    try:
        cat_index = int(parts[1]) - 1
    except ValueError:
        await event.reply("❌ Enter a valid number!")
        return
    
    products = get_category_products(cat_index)
    
    if not products:
        await event.reply("📦 No products in this category!")
        return
    
    msg = f"📦 **Products in Category #{cat_index+1}**\n━━━━━━━━━━━━━━━━━━━━━\n"
    for i, p in enumerate(products):
        msg += f"{i+1}. {p.get('icon', '📦')} {p['name']} | ₹{p['price']} | {p['file_type']} | Stock: {p['stock']} | Sold: {p.get('sold', 0)}\n"
    msg += "\n🗑️ Delete: `/delproductfromcat <cat_number> <product_number>`"
    
    await event.reply(msg)


async def delete_product_from_category_command(event):
    if event.sender_id != ADMIN_ID:
        return
    
    parts = event.text.split()
    if len(parts) != 3:
        await event.reply("❌ Format: `/delproductfromcat <cat_number> <product_number>`")
        return
    
    try:
        cat_index = int(parts[1]) - 1
        prod_index = int(parts[2]) - 1
    except ValueError:
        await event.reply("❌ Enter valid numbers!")
        return
    
    removed = remove_product_from_category(cat_index, prod_index)
    if removed:
        await event.reply(f"✅ Product deleted: {removed['name']}")
    else:
        await event.reply("❌ Product not found!")


# ============================================
# ADMIN WALLET
# ============================================

async def admin_wallet_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("💰 **Wallet Manage**\n\nFormat: `/addbalance <user_id> <amount>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def add_balance_admin(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split()
    if len(parts) != 3:
        await event.reply("❌ Format: `/addbalance <user_id> <amount>`")
        return
    
    uid = parts[1]
    try:
        amt = int(parts[2])
    except ValueError:
        await event.reply("❌ Amount must be a number!")
        return
    
    if add_balance(uid, amt):
        await event.reply(f"✅ ₹{amt} added to {uid}!")
    else:
        await event.reply("❌ User not found!")


# ============================================
# ADMIN SETTINGS
# ============================================

async def admin_store_link_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("📎 **Set Store Link:**\n`/setstore <link>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def set_store(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split(maxsplit=1)
    if len(parts) < 2:
        await event.reply("❌ Format: `/setstore <link>`")
        return
    data = load_data()
    data['settings']['paid_store_link'] = parts[1]
    save_data(data)
    await event.reply("✅ Store link updated!")


async def admin_proof_link_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("📎 **Set Proof Link:**\n`/setproof <link>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def set_proof(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split(maxsplit=1)
    if len(parts) < 2:
        await event.reply("❌ Format: `/setproof <link>`")
        return
    data = load_data()
    data['settings']['selling_proof_link'] = parts[1]
    save_data(data)
    await event.reply("✅ Proof link updated!")


async def admin_support_link_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("📎 **Set Support Link:**\n`/setsupport <link>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def set_support(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split(maxsplit=1)
    if len(parts) < 2:
        await event.reply("❌ Format: `/setsupport <link>`")
        return
    link = parts[1]
    if link.startswith("@"):
        link = "https://t.me/" + link[1:]
    if not link.startswith("http"):
        link = "https://" + link
    
    data = load_data()
    data['settings']['support_link'] = link
    save_data(data)
    await event.reply(f"✅ Support link updated!")


async def admin_minmax_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("💰 **Set Min/Max:**\n`/setminmax <min> <max>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def set_minmax(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split()
    if len(parts) != 3:
        await event.reply("❌ Format: `/setminmax <min> <max>`")
        return
    data = load_data()
    data['settings']['min_amount'] = int(parts[1])
    data['settings']['max_amount'] = int(parts[2])
    save_data(data)
    await event.reply(f"✅ Min: ₹{parts[1]} | Max: ₹{parts[2]}")


# ============================================
# ADMIN BROADCAST
# ============================================

async def admin_broadcast_handler(event):
    if event.sender_id != ADMIN_ID:
        return
    await event.edit("📢 **Broadcast**\n\nFormat: `/broadcast <message>`",
                    buttons=[[KeyboardButtonCallback("🔙 Back", b"admin_panel")]])


async def broadcast(event):
    if event.sender_id != ADMIN_ID:
        return
    parts = event.text.split(maxsplit=1)
    if len(parts) < 2:
        await event.reply("❌ Format: `/broadcast <message>`")
        return
    
    data = load_data()
    count = 0
    for uid in data['users']:
        try:
            await event.client.send_message(int(uid), f"📢 **Announcement**\n\n{parts[1]}")
            count += 1
        except:
            pass
    await event.reply(f"✅ Broadcast sent to {count} users!")


# ============================================
# REGISTER ALL ADMIN HANDLERS
# ============================================

def register_admin(client):
    # Admin Panel
    client.add_event_handler(admin_panel_handler, events.CallbackQuery(data=b"admin_panel"))
    client.add_event_handler(admin_stats_handler, events.CallbackQuery(data=b"admin_stats"))
    client.add_event_handler(admin_orders_handler, events.CallbackQuery(data=b"admin_orders"))
    client.add_event_handler(admin_history_handler, events.CallbackQuery(data=b"admin_history"))
    
    # Keys
    client.add_event_handler(admin_add_key_handler, events.CallbackQuery(data=b"admin_add_key"))
    client.add_event_handler(admin_view_keys_handler, events.CallbackQuery(data=b"admin_view_keys"))
    client.add_event_handler(add_key_command, events.NewMessage(pattern='/addkey'))
    client.add_event_handler(delete_key_command, events.NewMessage(pattern='/delkey'))
    
    # Categories
    client.add_event_handler(admin_add_category_handler, events.CallbackQuery(data=b"admin_add_category"))
    client.add_event_handler(admin_view_categories_handler, events.CallbackQuery(data=b"admin_view_categories"))
    client.add_event_handler(add_category_command, events.NewMessage(pattern='/addcategory'))
    client.add_event_handler(delete_category_command, events.NewMessage(pattern='/delcategory'))
    client.add_event_handler(add_product_to_category_command, events.NewMessage(pattern='/addproducttocat'))
    client.add_event_handler(view_category_products_handler, events.NewMessage(pattern='/viewcatproducts'))
    client.add_event_handler(delete_product_from_category_command, events.NewMessage(pattern='/delproductfromcat'))
    
    # Wallet
    client.add_event_handler(admin_wallet_handler, events.CallbackQuery(data=b"admin_wallet"))
    client.add_event_handler(add_balance_admin, events.NewMessage(pattern='/addbalance'))
    
    # Settings
    client.add_event_handler(admin_store_link_handler, events.CallbackQuery(data=b"admin_store_link"))
    client.add_event_handler(admin_proof_link_handler, events.CallbackQuery(data=b"admin_proof_link"))
    client.add_event_handler(admin_support_link_handler, events.CallbackQuery(data=b"admin_support_link"))
    client.add_event_handler(admin_minmax_handler, events.CallbackQuery(data=b"admin_minmax"))
    client.add_event_handler(set_store, events.NewMessage(pattern='/setstore'))
    client.add_event_handler(set_proof, events.NewMessage(pattern='/setproof'))
    client.add_event_handler(set_support, events.NewMessage(pattern='/setsupport'))
    client.add_event_handler(set_minmax, events.NewMessage(pattern='/setminmax'))
    
    # Broadcast
    client.add_event_handler(admin_broadcast_handler, events.CallbackQuery(data=b"admin_broadcast"))
    client.add_event_handler(broadcast, events.NewMessage(pattern='/broadcast'))