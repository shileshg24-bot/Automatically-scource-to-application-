from telethon import events
from telethon.tl.types import KeyboardButtonCallback, KeyboardButtonUrl, InputMediaPhoto
from database import (
    load_data, add_order, add_balance, get_balance, 
    get_manual_payment, add_pending_payment, approve_payment
)
from handlers.start import start_handler
from config import ADMIN_ID
import requests
import io
import time
import os
import random
import tempfile

temp_amount = {}

# ============================================
# ADD BALANCE HANDLER
# ============================================

async def add_balance_handler(event):
    """Show amount selection"""
    user_id = event.sender_id
    data = load_data()
    min_amt = data['settings'].get('min_amount', 10)
    max_amt = data['settings'].get('max_amount', 5000)
    
    temp_amount[user_id] = 0
    
    msg = f"""💰 **ADD FUNDS**
━━━━━━━━━━━━━━━━━━━━━

💵 Min: ₹{min_amt} | Max: ₹{max_amt}

👇 Amount: ₹0

📌 Enter amount below:"""
    
    buttons = [
        [KeyboardButtonCallback("1", b"num_1"), KeyboardButtonCallback("2", b"num_2"), KeyboardButtonCallback("3", b"num_3")],
        [KeyboardButtonCallback("4", b"num_4"), KeyboardButtonCallback("5", b"num_5"), KeyboardButtonCallback("6", b"num_6")],
        [KeyboardButtonCallback("7", b"num_7"), KeyboardButtonCallback("8", b"num_8"), KeyboardButtonCallback("9", b"num_9")],
        [KeyboardButtonCallback("✅ Confirm", b"num_confirm"), KeyboardButtonCallback("0", b"num_0"), KeyboardButtonCallback("🗑️ Delete", b"num_delete")],
        [KeyboardButtonCallback("🔙 Back", b"num_back")],
    ]
    await event.edit(msg, buttons=buttons)


async def number_handler(event):
    """Handle number input"""
    user_id = event.sender_id
    action = event.data.decode().split('_')[1]
    data = load_data()
    min_amt = data['settings'].get('min_amount', 10)
    max_amt = data['settings'].get('max_amount', 5000)
    
    current = temp_amount.get(user_id, 0)
    
    if action == 'confirm':
        if current < min_amt:
            await event.answer(f"❌ Minimum ₹{min_amt} hai!", alert=True)
            return
        if current > max_amt:
            await event.answer(f"❌ Maximum ₹{max_amt} hai!", alert=True)
            return
        # Show payment details
        await show_payment_details(event, user_id, current)
        return
    
    if action == 'delete':
        new_amount = int(current / 10) if current >= 10 else 0
    elif action == 'back':
        await start_handler(event)
        return
    else:
        new_amount = current * 10 + int(action)
    
    temp_amount[user_id] = new_amount
    
    msg = f"""💰 **ADD FUNDS**
━━━━━━━━━━━━━━━━━━━━━

💵 Min: ₹{min_amt} | Max: ₹{max_amt}

👇 Amount: ₹{new_amount}"""
    
    buttons = [
        [KeyboardButtonCallback("1", b"num_1"), KeyboardButtonCallback("2", b"num_2"), KeyboardButtonCallback("3", b"num_3")],
        [KeyboardButtonCallback("4", b"num_4"), KeyboardButtonCallback("5", b"num_5"), KeyboardButtonCallback("6", b"num_6")],
        [KeyboardButtonCallback("7", b"num_7"), KeyboardButtonCallback("8", b"num_8"), KeyboardButtonCallback("9", b"num_9")],
        [KeyboardButtonCallback("✅ Confirm", b"num_confirm"), KeyboardButtonCallback("0", b"num_0"), KeyboardButtonCallback("🗑️ Delete", b"num_delete")],
        [KeyboardButtonCallback("🔙 Back", b"num_back")],
    ]
    await event.edit(msg, buttons=buttons)


async def show_payment_details(event, user_id, amount):
    """Show payment details - QR + Message ek saath"""
    
    # Get settings
    data = load_data()
    manual = data.get('manual_payment', {})
    settings = data.get('settings', {})
    
    upi_id = manual.get('upi_id') or settings.get('upi_id', 'your_upi@upi')
    qr_code_url = manual.get('qr_image') or settings.get('qr_code_url', '')
    payment_description = manual.get('instructions') or settings.get('payment_description', 'Pay via UPI and send screenshot')
    
    order_id = f"QR{int(time.time())}{random.randint(100, 999)}"
    
    temp_amount[f"{user_id}_amount"] = amount
    temp_amount[f"{user_id}_order"] = order_id
    
    # 🔥 Loading message
    await event.edit("⏳ **Generating Payment...**")
    
    # 🔥 Prepare message
    msg = f"""💳 **Payment Details**
━━━━━━━━━━━━━━━━━━━━━

💰 **Amount:** ₹{amount}
🆔 **Order ID:** `{order_id}`

📤 **UPI ID:** `{upi_id}`

📌 **Instructions:**
{payment_description}

━━━━━━━━━━━━━━━━━━━━━
✅ Pay using above UPI ID

⏳ After payment, click "Payment Done" button!"""
    
    buttons = [
        [KeyboardButtonCallback("✅ Payment Done", f"paydone_{order_id}_{amount}".encode())],
        [KeyboardButtonCallback("🔙 Back", b"add_balance")]
    ]
    
    # 🔥 Get QR image with proper filename
    qr_image_data, qr_filename = get_qr_image_with_filename(qr_code_url)
    
    # 🔥 Send QR + Message EK SAATH
    if qr_image_data and len(qr_image_data) > 100:
        # 🔥 METHOD 1: Create temp file with proper extension
        try:
            # Create temp file with proper name
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
                tmp_file.write(qr_image_data)
                tmp_path = tmp_file.name
            
            # Send as photo with proper filename
            await event.client.send_file(
                event.chat_id,
                tmp_path,
                caption=msg,
                force_document=False,  # Photo
                buttons=buttons
            )
            
            # Clean up temp file
            try:
                os.unlink(tmp_path)
            except:
                pass
            
            print(f"✅ QR sent successfully with filename: {qr_filename}")
            
        except Exception as e:
            print(f"❌ Temp file method failed: {e}")
            
            # 🔥 METHOD 2: Use BytesIO with proper file name
            try:
                file_io = io.BytesIO(qr_image_data)
                file_io.name = qr_filename  # 🔥 CRITICAL: Set filename
                file_io.seek(0)
                
                await event.client.send_file(
                    event.chat_id,
                    file_io,
                    caption=msg,
                    force_document=False,
                    buttons=buttons
                )
                print(f"✅ QR sent via BytesIO with name: {qr_filename}")
            except Exception as e2:
                print(f"❌ BytesIO method failed: {e2}")
                
                # 🔥 METHOD 3: Send as document (always works)
                try:
                    file_io = io.BytesIO(qr_image_data)
                    file_io.name = qr_filename
                    file_io.seek(0)
                    
                    await event.client.send_file(
                        event.chat_id,
                        file_io,
                        caption=msg,
                        force_document=True,  # Document
                        buttons=buttons
                    )
                    print(f"✅ QR sent as document with name: {qr_filename}")
                except Exception as e3:
                    print(f"❌ All methods failed: {e3}")
                    await event.edit(msg, buttons=buttons)
        
        # Delete loading message
        await event.delete()
        
    else:
        # 🔥 Agar QR nahi hai toh sirf message bhejo
        await event.edit(msg, buttons=buttons)


def get_qr_image_with_filename(qr_code_url):
    """Get QR image with proper filename"""
    qr_image_data = None
    qr_filename = "qr_code.png"  # Default
    
    if not qr_code_url:
        return None, qr_filename
    
    try:
        # 🔥 Check if it's a file path
        if os.path.exists(qr_code_url):
            with open(qr_code_url, 'rb') as f:
                qr_image_data = f.read()
            # Get filename with extension
            qr_filename = os.path.basename(qr_code_url)
            # Ensure proper extension
            if not any(qr_filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']):
                qr_filename = "qr_code.png"
            print(f"✅ QR loaded from file: {qr_filename}")
            return qr_image_data, qr_filename
        
        # 🔥 Check in uploads folder
        upload_path = os.path.join('uploads', os.path.basename(qr_code_url))
        if os.path.exists(upload_path):
            with open(upload_path, 'rb') as f:
                qr_image_data = f.read()
            qr_filename = os.path.basename(upload_path)
            if not any(qr_filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']):
                qr_filename = "qr_code.png"
            print(f"✅ QR loaded from uploads: {qr_filename}")
            return qr_image_data, qr_filename
        
        # 🔥 Download from URL
        if qr_code_url.startswith('http'):
            response = requests.get(qr_code_url, timeout=15)
            if response.status_code == 200:
                qr_image_data = response.content
                # Extract filename from URL
                url_filename = qr_code_url.split('/')[-1]
                if url_filename and any(url_filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']):
                    qr_filename = url_filename
                else:
                    qr_filename = "qr_code.png"
                print(f"✅ QR downloaded from URL: {qr_filename}")
                return qr_image_data, qr_filename
        
        # 🔥 Try with base URL
        test_urls = [
            f"https://17clubgame.us.cc/{qr_code_url}",
            f"https://17clubgame.us.cc/uploads/{qr_code_url}",
            f"https://17clubgame.us.cc/{qr_code_url.lstrip('/')}"
        ]
        for test_url in test_urls:
            try:
                response = requests.get(test_url, timeout=10)
                if response.status_code == 200 and len(response.content) > 100:
                    qr_image_data = response.content
                    qr_filename = "qr_code.png"
                    print(f"✅ QR downloaded from: {test_url}")
                    return qr_image_data, qr_filename
            except:
                continue
                
    except Exception as e:
        print(f"❌ QR Error: {e}")
    
    return qr_image_data, qr_filename


async def pay_done_handler(event):
    """Handle payment done"""
    user_id = event.sender_id
    data = event.data.decode()
    parts = data.split('_')
    order_id = parts[1]
    amount = int(parts[2])
    
    add_pending_payment(user_id, amount, order_id)
    
    msg = f"""✅ **Payment Request Submitted!**

💰 **Amount:** ₹{amount}
🆔 **Order ID:** `{order_id}`
📅 **Time:** {time.strftime('%d-%m-%Y %H:%M')}

━━━━━━━━━━━━━━━━━━━━━
⏳ **Waiting for admin approval...**

📌 Admin will verify and add balance soon.

⏱️ Response: 15-30 Minutes"""

    buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
    await event.edit(msg, buttons=buttons)
    
    admin_msg = f"""📢 **New Payment Request!**

━━━━━━━━━━━━━━━━━━━━━
👤 **User:** `{user_id}`
💰 **Amount:** ₹{amount}
🆔 **Order ID:** `{order_id}`
📅 **Time:** {time.strftime('%d-%m-%Y %H:%M')}
━━━━━━━━━━━━━━━━━━━━━

📌 **Click below to approve:**
/approve_{order_id}_{user_id}_{amount}"""

    try:
        await event.client.send_message(ADMIN_ID, admin_msg)
    except:
        pass


async def approve_payment_handler(event):
    """Handle admin approval"""
    user_id = event.sender_id
    
    if user_id != ADMIN_ID:
        await event.answer("❌ Sirf admin approve kar sakta hai!", alert=True)
        return
    
    data = event.data.decode()
    parts = data.split('_')
    order_id = parts[1]
    user_id = int(parts[2])
    amount = int(parts[3])
    
    if add_balance(user_id, amount):
        add_order(user_id, f"Balance Add (QR Payment)", amount, "Completed")
        approve_payment(order_id)
        
        try:
            user_msg = f"""✅ **Payment Approved!** 💰

━━━━━━━━━━━━━━━━━━━━━
💵 **Amount:** ₹{amount}
🆔 **Order ID:** `{order_id}`
📅 **Date:** {time.strftime('%d-%m-%Y %H:%M')}
━━━━━━━━━━━━━━━━━━━━━

💰 **New Balance:** ₹{get_balance(user_id)}

📌 Your balance has been added successfully! 🎉"""
            
            await event.client.send_message(user_id, user_msg)
        except:
            pass
        
        await event.edit(f"✅ Approved! ₹{amount} added to user {user_id}")
    else:
        await event.edit(f"❌ Failed to add balance!")


def register_balance(client):
    client.add_event_handler(add_balance_handler, events.CallbackQuery(data=b"add_balance"))
    client.add_event_handler(number_handler, events.CallbackQuery(data=lambda d: d.startswith(b"num_")))
    client.add_event_handler(pay_done_handler, events.CallbackQuery(data=lambda d: d.startswith(b"paydone_")))
    client.add_event_handler(approve_payment_handler, events.CallbackQuery(data=lambda d: d.startswith(b"approve_")))