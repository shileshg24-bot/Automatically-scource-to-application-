from telethon import events
from telethon.tl.types import KeyboardButtonCallback, KeyboardButtonUrl
from database import (
    get_category_products, get_balance, deduct_balance, add_balance,
    add_order, buy_product_from_category
)
from config import ADMIN_ID
from datetime import datetime
import os

# ============================================
# USER SIDE - Category View
# ============================================

async def category_handler(event):
    """Show products in selected category"""
    user_id = event.sender_id
    data = event.data.decode()
    category_index = int(data.split('_')[1])
    
    products = get_category_products(category_index)
    
    if not products:
        msg = "📂 **Category**\n\n❌ Koi product available nahi hai!\nJald hi aayengi."
        buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
        await event.edit(msg, buttons=buttons)
        return
    
    msg = f"📂 **Category Products**\n━━━━━━━━━━━━━━━━━━━━━\n\n"
    msg += "SELECT YOUR PRODUCT AND BUY NOW 👇\n"
    
    buttons = []
    for i, product in enumerate(products):
        name = product.get('name', 'N/A')
        price = product.get('price', 0)
        icon = product.get('icon', '📦')
        stock = product.get('stock', 'Unlimited')
        
        stock_display = '∞' if stock == 'Unlimited' else stock
        # 🔥 $ → ₹
        button_text = f"{icon} {name}  |  💰 ₹{price}  |  📦 {stock_display}"
        buttons.append([KeyboardButtonCallback(button_text, f"catbuy_{category_index}_{i}".encode())])
    
    buttons.append([KeyboardButtonCallback("🔙 Back", b"back_main")])
    await event.edit(msg, buttons=buttons)


# ============================================
# BUY HANDLER - Direct File Send + External Link
# ============================================

async def category_buy_handler(event):
    """Buy product from category"""
    user_id = event.sender_id
    data = event.data.decode()
    parts = data.split('_')
    category_index = int(parts[1])
    product_index = int(parts[2])
    
    # Get product first
    products = get_category_products(category_index)
    if product_index >= len(products):
        await event.answer("❌ Product available nahi hai!", alert=True)
        return
    
    product_data = products[product_index]
    name = product_data.get('name', 'N/A')
    price = product_data.get('price', 0)
    stock = product_data.get('stock', 'Unlimited')
    file_link = product_data.get('file_link', '#')
    file_type = product_data.get('file_type', 'file')
    
    # Check stock
    if stock != "Unlimited":
        try:
            if int(stock) <= 0:
                await event.answer("❌ Out of stock!", alert=True)
                return
        except:
            pass
    
    # Check balance
    balance = get_balance(user_id)
    if balance < price:
        # 🔥 $ → ₹
        await event.answer(f"❌ Balance kam hai! Need ₹{price}, You have ₹{balance}", alert=True)
        return
    
    # Deduct balance
    if not deduct_balance(user_id, price):
        await event.answer("❌ Balance deduct failed!", alert=True)
        return
    
    # Buy product
    purchased = buy_product_from_category(user_id, category_index, product_index)
    
    if purchased and isinstance(purchased, dict) and 'error' not in purchased:
        
        # Get file link
        purchased_file_link = purchased.get('file_link', file_link)
        
        # Add order
        add_order(user_id, f"Product: {name}", price, "Completed", file_link=purchased_file_link)
        
        # Check if it's a local file
        is_local_file = purchased_file_link.startswith('/api/download/') or purchased_file_link.startswith('/download/')
        
        if is_local_file:
            # LOCAL FILE - Direct send via Telegram
            filename = purchased_file_link.split('/')[-1]
            filepath = os.path.join('uploads', filename)
            
            if os.path.exists(filepath):
                # 🔥 $ → ₹
                msg = f"""✅ **Purchase Successful!**

📦 **Name:** {name}
💰 **Price:** ₹{price}
📁 **Type:** {file_type.upper()}

📥 **Your file is being sent...**"""
                
                await event.edit(msg)
                
                # Send file directly
                await event.client.send_file(
                    user_id,
                    filepath,
                    caption=f"📦 {name}\n💰 ₹{price}",
                    force_document=True
                )
                
                # 🔥 $ → ₹
                success_msg = f"""✅ **File Sent Successfully!**

📦 **Name:** {name}
💰 **Price:** ₹{price}

📌 **File received above!** Download and enjoy! 🎮

📞 Support: Click Back then Support"""
                
                buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
                await event.edit(success_msg, buttons=buttons)
                
            else:
                # File not found
                await event.answer("❌ File not found on server!", alert=True)
                add_balance(user_id, price)
        else:
            # EXTERNAL LINK - Show "Click Here to Open Link" button
            # 🔥 $ → ₹
            msg = f"""✅ **Purchase Successful!**

📦 **Name:** {name}
💰 **Price:** ₹{price}
📁 **Type:** {file_type.upper()}

━━━━━━━━━━━━━━━━━━━━━
🔗 **Click below to open link:**"""

            buttons = [
                [KeyboardButtonUrl("🌐 Click Here to Open Link", purchased_file_link)],
                [KeyboardButtonCallback("🔙 Back", b"back_main")]
            ]
            await event.edit(msg, buttons=buttons)
        
        # Notify admin
        try:
            await event.client.send_message(
                ADMIN_ID,
                f"📦 **Product Sold!**\n\n"
                f"👤 User: `{user_id}`\n"
                f"📦 Name: {name}\n"
                f"💰 Price: ₹{price}\n"
                f"📅 Date: {datetime.now().strftime('%d-%m-%Y %H:%M')}"
            )
        except:
            pass
            
    elif purchased and isinstance(purchased, dict) and purchased.get('error'):
        add_balance(user_id, price)
        await event.answer(f"❌ {purchased['error']}", alert=True)
    else:
        add_balance(user_id, price)
        await event.answer("❌ Purchase failed! Balance refunded.", alert=True)


def register_category(client):
    client.add_event_handler(category_handler, events.CallbackQuery(data=lambda d: d.startswith(b"cat_")))
    client.add_event_handler(category_buy_handler, events.CallbackQuery(data=lambda d: d.startswith(b"catbuy_")))