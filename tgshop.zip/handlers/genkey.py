from telethon import events
from telethon.tl.types import KeyboardButtonCallback
from database import get_all_keys, get_balance, deduct_balance, add_order, remove_key_from_db
from config import ADMIN_ID
from datetime import datetime

async def genkey_handler(event):
    user_id = event.sender_id
    keys = get_all_keys()
    
    if not keys:
        msg = "❌ Abhi koi key available nahi hai!\nJald hi aayengi."
        buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
        await event.edit(msg, buttons=buttons)
        return
    
    msg = "SELECT YOUR KEY AND BUY NOW 👇\n"
    
    buttons = []
    for i, key_data in enumerate(keys):
        price = key_data.get('price', 0)
        hours = key_data.get('hours', 0)
        
        button_text = f"🔑 Key #{i+1}  |  ⏱️ {hours}h  |  💰 ₹{price}"
        buttons.append([KeyboardButtonCallback(button_text, f"genbuy_{i}".encode())])
    
    buttons.append([KeyboardButtonCallback("🔙 Back", b"back_main")])
    await event.edit(msg, buttons=buttons)


async def genbuy_handler(event):
    user_id = event.sender_id
    data = event.data.decode()
    index = int(data.split('_')[1])
    
    keys = get_all_keys()
    if index >= len(keys):
        await event.answer("❌ Key available nahi hai!", alert=True)
        return
    
    key_data = keys[index]
    key = key_data.get('key')
    price = key_data.get('price')
    hours = key_data.get('hours')
    
    balance = get_balance(user_id)
    if balance < price:
        await event.answer(f"❌ Balance kam hai! Need ₹{price}, You have ₹{balance}", alert=True)
        return
    
    if deduct_balance(user_id, price):
        removed_key = remove_key_from_db(index)
        if removed_key:
            add_order(user_id, f"Game Key ({hours}h)", price, "Completed", key, hours)
            
            msg = f"""✅ **Key Purchased Successfully!**

🔑 **Your Key:** `{key}`
⏱️ **Validity:** {hours} Hours
💰 **Price:** ₹{price}

━━━━━━━━━━━━━━━━━━━━━
📌 **Instructions:**
1. Copy the key above
2. Use it within {hours} hours
3. Enjoy! 🎮

📞 Support: Click Back then Support"""
            
            buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
            await event.edit(msg, buttons=buttons)
            
            try:
                await event.client.send_message(
                    ADMIN_ID,
                    f"🔑 **Key Sold!**\n\n"
                    f"👤 User: `{user_id}`\n"
                    f"🔑 Key: `{key}`\n"
                    f"⏱️ Hours: {hours}h\n"
                    f"💰 Price: ₹{price}\n"
                    f"📅 Date: {datetime.now().strftime('%d-%m-%Y %H:%M')}"
                )
            except:
                pass
        else:
            await event.answer("❌ Key purchase failed! Try again.", alert=True)
    else:
        await event.answer("❌ Balance insufficient!", alert=True)

def register_genkey(client):
    client.add_event_handler(genkey_handler, events.CallbackQuery(data=b"gen_key"))
    client.add_event_handler(genbuy_handler, events.CallbackQuery(data=lambda d: d.startswith(b"genbuy_")))