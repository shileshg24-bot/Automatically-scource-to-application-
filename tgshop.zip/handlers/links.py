from telethon import events
from telethon.tl.types import KeyboardButtonCallback, KeyboardButtonUrl
from database import load_data

async def paid_store_handler(event):
    data = load_data()
    link = data['settings'].get('paid_store_link', 'https://t.me/your_channel')
    
    buttons = [
        [KeyboardButtonUrl("🛍️ Open Store", link)],
        [KeyboardButtonCallback("🔙 Back", b"back_main")]
    ]
    await event.edit("🛍️ Click to open store:", buttons=buttons)


async def selling_proof_handler(event):
    data = load_data()
    link = data['settings'].get('selling_proof_link', 'https://t.me/your_proof_channel')
    
    buttons = [
        [KeyboardButtonUrl("📸 View Proof", link)],
        [KeyboardButtonCallback("🔙 Back", b"back_main")]
    ]
    await event.edit("📸 Click to view proofs:", buttons=buttons)

def register_links(client):
    client.add_event_handler(paid_store_handler, events.CallbackQuery(data=b"paid_store"))
    client.add_event_handler(selling_proof_handler, events.CallbackQuery(data=b"selling_proof"))