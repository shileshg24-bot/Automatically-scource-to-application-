from telethon.tl.types import KeyboardButtonCallback
from database import get_all_categories

def get_main_menu():
    """Generate main menu with 3 buttons per row"""
    categories = get_all_categories()
    
    menu = [
        [KeyboardButtonCallback("💰 Add Balance", b"add_balance"), 
         KeyboardButtonCallback("📦 My Orders", b"my_orders"), 
         KeyboardButtonCallback("📜 Buy History", b"buy_history")],
        
        [KeyboardButtonCallback("👤 My Profile", b"my_profile"), 
         KeyboardButtonCallback("❓ How To Use", b"how_to_use"), 
         KeyboardButtonCallback("🆘 Support", b"support")],
        
        [KeyboardButtonCallback("📸 Selling Proof", b"selling_proof"), 
         KeyboardButtonCallback("🔑 GEN KEY", b"gen_key"), 
         KeyboardButtonCallback("🛍️ Paid Store", b"paid_store")],
    ]
    
    # Add custom category buttons
    row = []
    for i, cat in enumerate(categories):
        name = cat.get('name', 'Unknown')
        icon = cat.get('icon', '📦')
        row.append(KeyboardButtonCallback(f"{icon} {name}", f"cat_{i}".encode()))
        if len(row) == 3:
            menu.append(row)
            row = []
    if row:
        menu.append(row)
    
    return menu


def get_admin_menu():
    """Admin menu with 3 buttons per row"""
    return [
        [KeyboardButtonCallback("📊 Stats", b"admin_stats"), 
         KeyboardButtonCallback("💰 Wallet Manage", b"admin_wallet"), 
         KeyboardButtonCallback("⏳ Pending", b"admin_pending")],
        
        [KeyboardButtonCallback("🔑 Add Key", b"admin_add_key"), 
         KeyboardButtonCallback("📦 View Keys", b"admin_view_keys"), 
         KeyboardButtonCallback("📂 Add Category", b"admin_add_category")],
        
        [KeyboardButtonCallback("📂 View Categories", b"admin_view_categories"), 
         KeyboardButtonCallback("📦 All Orders", b"admin_orders"), 
         KeyboardButtonCallback("📜 All History", b"admin_history")],
        
        [KeyboardButtonCallback("🔗 Set Store Link", b"admin_store_link"), 
         KeyboardButtonCallback("🔗 Set Proof Link", b"admin_proof_link"), 
         KeyboardButtonCallback("🔗 Set Support Link", b"admin_support_link")],
        
        [KeyboardButtonCallback("💵 Set Min/Max", b"admin_minmax"), 
         KeyboardButtonCallback("📢 Broadcast", b"admin_broadcast")],
        
        [KeyboardButtonCallback("🔙 Back", b"back_main")],
    ]