from telethon import events
from telethon.tl.types import KeyboardButtonCallback
from database import get_user, get_history, get_balance

async def profile_handler(event):
    user_id = str(event.sender_id)
    user_data = get_user(user_id)
    balance = get_balance(user_id)
    name = user_data.get('name', 'User')
    joined = user_data.get('joined', 'N/A')
    
    msg = f"""👤 **My Profile**

🆔 ID: `{user_id}`
👤 Name: {name}
💰 Balance: ₹{balance}
📅 Joined: {joined}"""
    
    buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
    await event.edit(msg, buttons=buttons)


async def orders_handler(event):
    user_id = str(event.sender_id)
    history = get_history(user_id)
    pending = [o for o in history if o.get('status') == 'Pending']
    
    if not pending:
        msg = "📦 **My Orders**\n\n✅ Koi pending order nahi hai!"
    else:
        msg = "📦 **My Orders (Pending)**\n\n"
        for i, order in enumerate(pending, 1):
            msg += f"""🆔 Order #{i}
📦 Product: {order.get('product', 'N/A')}
💰 Amount: ₹{order.get('amount', 0)}
📅 Date: {order.get('date', 'N/A')}
━━━━━━━━━━━━━━━━\n"""
    
    buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
    await event.edit(msg, buttons=buttons)


async def history_handler(event):
    user_id = str(event.sender_id)
    history = get_history(user_id)
    
    if not history:
        msg = "📜 **Buy History**\n\n❌ Koi purchase history nahi hai!"
        buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
        await event.edit(msg, buttons=buttons)
        return
    
    msg = "📜 **Buy History**\n\n"
    for i, order in enumerate(history[-10:], 1):
        msg += f"""🆔 Order #{i}
📦 Product: {order.get('product', 'N/A')}
💰 Amount: ₹{order.get('amount', 0)}
📅 Date: {order.get('date', 'N/A')}
✅ Status: {order.get('status', 'Pending')}
━━━━━━━━━━━━━━━━\n"""
    
    buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
    await event.edit(msg, buttons=buttons)


async def howto_handler(event):
    msg = """❓ **How To Use**

1️⃣ Add Balance – UPI se payment karein
2️⃣ Shop – Products dekhein
3️⃣ Buy – Product purchase karein
4️⃣ My Orders – Order status check karein
5️⃣ Buy History – Purani purchases dekhein

📞 Support: Click Back then Support"""
    
    buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
    await event.edit(msg, buttons=buttons)

def register_profile(client):
    client.add_event_handler(profile_handler, events.CallbackQuery(data=b"my_profile"))
    client.add_event_handler(orders_handler, events.CallbackQuery(data=b"my_orders"))
    client.add_event_handler(history_handler, events.CallbackQuery(data=b"buy_history"))
    client.add_event_handler(howto_handler, events.CallbackQuery(data=b"how_to_use"))