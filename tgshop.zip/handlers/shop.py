from telethon import events
from telethon.tl.types import KeyboardButtonCallback
from database import get_all_products, get_balance, deduct_balance, add_order, buy_product
from config import ADMIN_ID
from datetime import datetime

async def shop_handler(event):
    """Shop - Show all products from all categories"""
    user_id = event.sender_id
    products = get_all_products()
    
    if not products:
        msg = "🛒 **Shop**\n\n❌ Abhi koi product available nahi hai!\nJald hi aayengi."
        buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
        await event.edit(msg, buttons=buttons)
        return
    
    msg = "🛒 **SHOP**\n━━━━━━━━━━━━━━━━━━━━━\n\n"
    msg += "SELECT YOUR PRODUCT AND BUY NOW 👇\n"
    
    buttons = []
    for i, product in enumerate(products):
        name = product.get('name', 'N/A')
        price = product.get('price', 0)
        icon = product.get('icon', '📦')
        stock = product.get('stock', 'Unlimited')
        category = product.get('category', 'Unknown')
        
        button_text = f"{icon} {name}  |  💰 ₹{price}  |  📦 {stock}"
        buttons.append([KeyboardButtonCallback(button_text, f"shopbuy_{i}".encode())])
    
    buttons.append([KeyboardButtonCallback("🔙 Back", b"back_main")])
    await event.edit(msg, buttons=buttons)


async def shop_buy_handler(event):
    """Handle product purchase from shop"""
    user_id = event.sender_id
    data = event.data.decode()
    index = int(data.split('_')[1])
    
    products = get_all_products()
    if index >= len(products):
        await event.answer("❌ Product available nahi hai!", alert=True)
        return
    
    product = products[index]
    name = product.get('name', 'N/A')
    price = product.get('price', 0)
    file_link = product.get('file_link', '#')
    file_type = product.get('file_type', 'file')
    stock = product.get('stock', 'Unlimited')
    
    # Check stock
    if stock != "Unlimited":
        try:
            if int(stock) <= 0:
                await event.answer("❌ Out of stock!", alert=True)
                return
        except:
            pass
    
    # Check balance
    balance = get_balance(user_id)
    if balance < price:
        await event.answer(f"❌ Balance kam hai! Need ₹{price}, You have ₹{balance}", alert=True)
        return
    
    # Buy product
    purchased = buy_product(user_id, index)
    
    if purchased and not isinstance(purchased, dict):
        if deduct_balance(user_id, price):
            add_order(user_id, f"Product: {name}", price, "Completed", file_link=file_link)
            
            msg = f"""✅ **Product Purchased Successfully!**

📦 **Name:** {name}
💰 **Price:** ₹{price}
📁 **Type:** {file_type.upper()}

━━━━━━━━━━━━━━━━━━━━━
🔗 **Download Link:**
`{file_link}`

📌 **Instructions:**
1. Click on download link
2. Download and install
3. Enjoy! 🎮

📞 Support: Click Back then Support"""
            
            buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
            await event.edit(msg, buttons=buttons)
            
            try:
                await event.client.send_message(
                    ADMIN_ID,
                    f"📦 **Product Sold!**\n\n"
                    f"👤 User: `{user_id}`\n"
                    f"📦 Name: {name}\n"
                    f"💰 Price: ₹{price}\n"
                    f"📅 Date: {datetime.now().strftime('%d-%m-%Y %H:%M')}"
                )
            except:
                pass
        else:
            await event.answer("❌ Insufficient balance!", alert=True)
    elif isinstance(purchased, dict) and purchased.get('error'):
        await event.answer(f"❌ {purchased['error']}", alert=True)
    else:
        await event.answer("❌ Purchase failed! Try again.", alert=True)


def register_shop(client):
    client.add_event_handler(shop_handler, events.CallbackQuery(data=b"shop"))
    client.add_event_handler(shop_buy_handler, events.CallbackQuery(data=lambda d: d.startswith(b"shopbuy_")))