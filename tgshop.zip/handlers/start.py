from telethon import events
from telethon.tl.types import KeyboardButtonCallback
from config import ADMIN_ID
from database import add_user, get_balance, load_data
from handlers.menu import get_main_menu

async def start_handler(event):
    try:
        user_id = event.sender_id
        user_id_str = str(user_id)
        
        data = load_data()
        
        if user_id_str not in data['users']:
            name = event.sender.first_name or "User"
            add_user(user_id, name)
            data = load_data()
        
        user_name = data['users'][user_id_str].get('name', 'User')
        balance = data['users'][user_id_str].get('balance', 0)
        
        msg = f"""🏪 — BNDEVLOPER — 🏪

🎉 Hello, {user_name}

📈 ━━ STORE HIGHLIGHTS ━━ 📈

┃ 🔑 Premium Game Keys
┃ 🌐 Instant Delivery 24/7
┃ 🛡 100% Secure Payment
┃ 💰 Best Prices Guaranteed
┃ 📱 Professional Support

━━━━━━━━━━━━━━━━━━━━━
👤 User ID: `{user_id}`
💰 Wallet Balance: ₹{balance}
━━━━━━━━━━━━━━━━━━━━━

Tap any button below to begin."""
        
        buttons = get_main_menu()
        if user_id == ADMIN_ID:
            buttons.append([KeyboardButtonCallback("🔐 Admin Panel", b"admin_panel")])
        
        await event.reply(msg, buttons=buttons)
    except Exception as e:
        print(f"❌ Error in start_handler: {e}")
        await event.reply("⚠️ Kuch technical issue hai! Admin se contact karein.")

def register_start(client):
    client.add_event_handler(start_handler, events.NewMessage(pattern='/start'))