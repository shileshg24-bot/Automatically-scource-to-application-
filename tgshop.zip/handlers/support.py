from telethon import events
from telethon.tl.types import KeyboardButtonCallback, KeyboardButtonUrl
from database import load_data

async def support_handler(event):
    try:
        data = load_data()
        support_link = data['settings'].get('support_link', 'https://t.me/your_support')
        
        msg = f"""💬 **SUPPORT CENTER** 💬

🛡 Need Any Help?

➡️ Purchase Support
➡️ Payment Issues
➡️ Key Problems
➡️ Instant Assistance
━━━━━━━━━━━━━━━━━━━━━
➡️ Balance nahi aaya
➡️ Key nahi mila
➡️ Purchase problem

⏱ Active Time: 6 AM - 1 PM
➡️ Response: 15-30 Minutes
━━━━━━━━━━━━━━━━━━━━━
🌐 Fast Reply • Trusted Support 🛡"""
        
        buttons = [
            [KeyboardButtonUrl("📞 Click Here", support_link)],
            [KeyboardButtonCallback("🔙 Back", b"back_main")]
        ]
        await event.edit(msg, buttons=buttons)
    except Exception as e:
        print(f"❌ Support Error: {e}")
        msg = f"""💬 **SUPPORT CENTER** 💬

🛡 Need Any Help?

📞 Contact Admin
━━━━━━━━━━━━━━━━━━━━━
🌐 Fast Reply • Trusted Support 🛡"""
        buttons = [[KeyboardButtonCallback("🔙 Back", b"back_main")]]
        await event.edit(msg, buttons=buttons)

def register_support(client):
    client.add_event_handler(support_handler, events.CallbackQuery(data=b"support"))