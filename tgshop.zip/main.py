from telethon import TelegramClient, events
from config import API_ID, API_HASH, BOT_TOKEN
from database import init_db
from handlers.start import register_start
from handlers.balance import register_balance
from handlers.shop import register_shop
from handlers.genkey import register_genkey
from handlers.links import register_links
from handlers.profile import register_profile
from handlers.support import register_support
from handlers.admin import register_admin
from handlers.category import register_category

# ---------- INIT DATABASE ----------
init_db()

# ---------- BOT START ----------
client = TelegramClient('bot', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# ---------- REGISTER ALL HANDLERS ----------
register_start(client)
register_balance(client)
register_shop(client)
register_genkey(client)
register_links(client)
register_profile(client)
register_support(client)
register_admin(client)
register_category(client)  # 🔥 NEW: Category handler

# ---------- BACK TO MAIN ----------
@client.on(events.CallbackQuery(data=b"back_main"))
async def back_main(event):
    from handlers.start import start_handler
    await start_handler(event)

# ---------- RUN ----------
print("🤖 BN DEV Bot Running...")
print("📁 Multi-file structure loaded successfully!")
client.run_until_disconnected()