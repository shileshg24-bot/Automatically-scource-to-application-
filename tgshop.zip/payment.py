import hashlib
import requests
import json
import time
import random
from datetime import datetime
from config import PAYMENT_CONFIG
import qrcode
from io import BytesIO
from PIL import Image
import re
from urllib.parse import urlparse, parse_qs

# ============================================
# PAYMENT FUNCTIONS
# ============================================

def generate_signature(params, key):
    """Generate MD5 signature for LGPayment"""
    sorted_params = sorted(params.items())
    stringA = '&'.join([f"{k}={v}" for k, v in sorted_params if v])
    stringA += f"&key={key}"
    print(f"🔑 Sign String: {stringA}")
    return hashlib.md5(stringA.encode()).hexdigest().upper()


def create_payment_order(user_id, amount):
    """Create payment order with LGPayment"""
    date = datetime.now().strftime("%Y%m%d")
    timestamp = int(time.time())
    random_num = random.randint(100000, 999900)
    order_sn = f"{date}{timestamp}{random_num}"
    
    money = int(float(amount) * 100)
    
    params = {
        "app_id": PAYMENT_CONFIG["app_id"],
        "trade_type": PAYMENT_CONFIG["trade_type"],
        "order_sn": order_sn,
        "money": str(money),
        "notify_url": PAYMENT_CONFIG["notify_url"],
        "ip": "139.180.137.164",
        "remark": str(user_id)
    }
    
    params = {k: v for k, v in params.items() if v}
    params["sign"] = generate_signature(params, PAYMENT_CONFIG["key"])
    
    print(f"📤 Sending to LGPayment: {params}")
    
    try:
        response = requests.post(
            PAYMENT_CONFIG["api_url"] + "/order/create",
            data=params,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30
        )
        print(f"📥 Response Status: {response.status_code}")
        print(f"📥 Response Body: {response.text}")
        
        result = response.json()
        
        if result.get("status") == 1:
            data = result.get("data", {})
            pay_url = data.get("pay_url", "")
            
            print(f"🔗 Pay URL: {pay_url}")
            
            # 🔥 Get REAL payment page from redirect URL
            real_payment_data = get_real_payment_page(pay_url)
            
            return {
                "success": True,
                "order_id": order_sn,
                "payment_url": pay_url,
                "real_payment_url": real_payment_data.get("real_url", pay_url),
                "qr_code": real_payment_data.get("qr_code", ""),
                "upi_id": real_payment_data.get("upi_id", "bnpay@upi"),
                "amount": amount,
                "full_response": result
            }
        else:
            return {
                "success": False,
                "error": result.get("msg", "Payment creation failed"),
                "code": result.get("status"),
                "full_response": result
            }
    except Exception as e:
        print(f"❌ Exception: {e}")
        return {
            "success": False,
            "error": str(e)
        }


def get_real_payment_page(pay_url):
    """Follow redirect and extract QR/UPI from final page"""
    try:
        print(f"🔄 Fetching: {pay_url}")
        
        # Follow redirects
        response = requests.get(pay_url, allow_redirects=True, timeout=30)
        final_url = response.url
        html_content = response.text
        
        print(f"✅ Final URL: {final_url}")
        
        # Extract UPI ID from HTML
        upi_patterns = [
            r'([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+)',  # email format UPI
            r'([0-9]{10,12}@[A-Za-z0-9.-]+)',       # phone@upi
            r'upi://pay\?pa=([^&]+)',               # UPI URL
            r'payee[_-]?account["\']?\s*[:=]\s*["\']([^"\']+)',  # payee account
            r'UPI[:\s]+([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+)',
            r'([A-Z0-9]{10,15}@[a-z]+)'             # JKBMERC00758799@jkb
        ]
        
        upi_id = None
        for pattern in upi_patterns:
            match = re.search(pattern, html_content, re.IGNORECASE)
            if match:
                upi_id = match.group(1)
                print(f"✅ Found UPI: {upi_id}")
                break
        
        if not upi_id:
            upi_id = "bnpay@upi"
            print("⚠️ UPI not found, using default")
        
        # Extract QR code URL
        qr_patterns = [
            r'<img[^>]+src=["\']([^"\']*qr[^"\']*)["\']',
            r'<img[^>]+src=["\']([^"\']*qrcode[^"\']*)["\']',
            r'qr_code["\']?\s*[:=]\s*["\']([^"\']+)["\']',
            r'data-qr=["\']([^"\']+)["\']',
            r'<img[^>]+src=["\']([^"\']*\.(png|jpg|jpeg|gif)[^"\']*)["\']'
        ]
        
        qr_url = None
        for pattern in qr_patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            if matches:
                for match in matches:
                    if isinstance(match, tuple):
                        match = match[0]
                    if match and ('qr' in match.lower() or 'qrcode' in match.lower() or 
                                 'upi' in match.lower() or 'pay' in match.lower()):
                        # Handle relative URLs
                        if match.startswith('/'):
                            parsed = urlparse(final_url)
                            qr_url = f"{parsed.scheme}://{parsed.netloc}{match}"
                        elif match.startswith('http'):
                            qr_url = match
                        else:
                            qr_url = match
                        print(f"✅ Found QR: {qr_url}")
                        break
                if qr_url:
                    break
        
        # Try to get QR from API or generate from UPI
        if not qr_url:
            print("⚠️ QR not found in HTML, will generate from UPI")
        
        return {
            "real_url": final_url,
            "upi_id": upi_id,
            "qr_code": qr_url,
            "html": html_content[:500]  # For debugging
        }
        
    except Exception as e:
        print(f"❌ Error fetching payment page: {e}")
        return {
            "real_url": pay_url,
            "upi_id": "bnpay@upi",
            "qr_code": "",
            "html": ""
        }


def check_payment_status(order_sn):
    """Check payment status from LGPayment"""
    params = {
        "app_id": PAYMENT_CONFIG["app_id"],
        "order_sn": order_sn
    }
    params["sign"] = generate_signature(params, PAYMENT_CONFIG["key"])
    
    try:
        response = requests.post(
            PAYMENT_CONFIG["api_url"] + "/order/check",
            data=params,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30
        )
        result = response.json()
        
        if result.get("status") == 1:
            data = result.get("data", {})
            return {
                "success": True,
                "status": data.get("status", "unpaid"),
                "amount": float(data.get("money", 0)) / 100,
                "order_id": order_sn
            }
        else:
            return {
                "success": False,
                "error": result.get("msg", "Check failed")
            }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def verify_callback(data, signature):
    """Verify payment callback signature"""
    data_copy = data.copy()
    data_copy.pop("sign", None)
    filtered_data = {k: v for k, v in data_copy.items() if v}
    generated_sign = generate_signature(filtered_data, PAYMENT_CONFIG["key"])
    print(f"🔑 Generated: {generated_sign}")
    print(f"🔑 Received: {signature}")
    return generated_sign == signature


def generate_qr_code_from_url(qr_url, base_url=""):
    """Download QR from URL or generate from UPI"""
    try:
        if not qr_url:
            return None
            
        # Handle relative URLs
        if qr_url.startswith('/') and base_url:
            qr_url = base_url.rstrip('/') + qr_url
            
        print(f"📥 Downloading QR: {qr_url}")
        response = requests.get(qr_url, timeout=15)
        if response.status_code == 200:
            content_type = response.headers.get('content-type', '')
            if 'image' in content_type:
                img_bytes = BytesIO(response.content)
                img_bytes.name = "payment_qr.png"
                print(f"✅ QR downloaded successfully")
                return img_bytes
        print(f"❌ QR download failed")
        return None
    except Exception as e:
        print(f"❌ QR download error: {e}")
        return None


def generate_local_qr(upi_id, amount, order_id):
    """Generate local QR as fallback"""
    try:
        qr_data = f"upi://pay?pa={upi_id}&pn=PAYMENT&am={amount}&cu=INR"
        
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        img_bytes = BytesIO()
        img.save(img_bytes, format='PNG', quality=95)
        img_bytes.seek(0)
        img_bytes.name = f"QR_{order_id}.png"
        
        print(f"✅ Local QR generated for {upi_id}")
        return img_bytes
        
    except Exception as e:
        print(f"❌ Local QR failed: {e}")
        return None