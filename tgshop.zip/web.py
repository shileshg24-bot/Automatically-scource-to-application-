import os
import uuid
import requests
import json
from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime
from database import (
    load_data, save_data, 
    get_all_keys, add_key_to_db, remove_key_from_db, get_keys_count,
    get_all_categories, add_category, remove_category, get_category_products,
    add_product_to_category, remove_product_from_category,
    get_all_users, get_balance, add_balance, deduct_balance,
    get_all_orders, get_stats, get_user, add_payment, update_payment_status,
    add_order, get_manual_payment, update_manual_payment, 
    get_pending_payments, add_pending_payment, approve_payment
)
from config import PAYMENT_CONFIG, BOT_TOKEN, ADMIN_ID

app = Flask(__name__)
CORS(app)

# File upload config
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {
    'apk', 'zip', 'rar', '7z', 
    'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 
    'mp4', 'mp3', 'mp2', 'wav', 'flac',
    'html', 'htm', 'json', 'xml', 'css', 'js',
    'exe', 'msi', 'deb', 'rpm',
    'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'
}
MAX_CONTENT_LENGTH = 500 * 1024 * 1024

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ============================================
# SEND TELEGRAM MESSAGE
# ============================================

def send_telegram_message(user_id, message):
    """Send message via Telegram Bot"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": user_id,
        "text": message,
        "parse_mode": "Markdown"
    }
    try:
        response = requests.post(url, json=payload, timeout=10)
        return response.json()
    except Exception as e:
        print(f"❌ Telegram send error: {e}")
        return None

# ============================================
# HOME
# ============================================

@app.route('/')
def index():
    return render_template('admin.html')

# ============================================
# FILE DOWNLOAD
# ============================================

@app.route('/api/download/<filename>')
def download_file(filename):
    try:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        if os.path.exists(filepath):
            return send_from_directory(
                app.config['UPLOAD_FOLDER'], 
                filename, 
                as_attachment=True,
                download_name=filename
            )
        else:
            return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# FILE UPLOAD
# ============================================

@app.route('/api/upload_product_file', methods=['POST'])
def api_upload_product_file():
    try:
        category_index = int(request.form.get('category_index'))
        name = request.form.get('name')
        price = int(request.form.get('price'))
        file_type = request.form.get('file_type')
        stock = request.form.get('stock', 'Unlimited')
        
        if stock.upper() == 'U':
            stock = 'Unlimited'
        
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'unknown'
            return jsonify({'error': f'File type ".{ext}" not allowed!'}), 400
        
        original_name = secure_filename(file.filename)
        unique_id = str(uuid.uuid4())[:8]
        filename = f"{unique_id}_{original_name}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        file_link = f"/api/download/{filename}"
        
        icons = {"apk": "📱", "zip": "📦", "mod": "🔧", "file": "📄", "html": "🌐", "pdf": "📕"}
        icon = icons.get(file_type.lower(), "📦")
        
        if add_product_to_category(category_index, name, price, file_link, file_type, stock, icon):
            return jsonify({'success': True, 'message': f'Product "{name}" added! File: {filename}'})
        return jsonify({'error': 'Category not found'}), 404
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================
# MANUAL PAYMENT - ADMIN SETTINGS
# ============================================

@app.route('/api/manual_payment', methods=['GET', 'POST'])
def api_manual_payment():
    if request.method == 'GET':
        settings = get_manual_payment()
        return jsonify(settings)
    
    if request.method == 'POST':
        upi_id = request.form.get('upi_id')
        instructions = request.form.get('instructions')
        qr_file = request.files.get('qr_image')
        
        qr_image = ''
        
        if qr_file and qr_file.filename:
            filename = secure_filename(qr_file.filename)
            unique_id = str(uuid.uuid4())[:8]
            qr_filename = f"qr_{unique_id}_{filename}"
            qr_path = os.path.join('uploads', qr_filename)
            qr_file.save(qr_path)
            qr_image = qr_path
        
        update_manual_payment(upi_id, qr_image, instructions)
        return jsonify({'success': True, 'message': 'Manual payment settings updated!'})

# ============================================
# PENDING PAYMENTS
# ============================================

@app.route('/api/pending_payments')
def api_pending_payments():
    payments = get_pending_payments()
    return jsonify(payments)

@app.route('/api/approve_payment', methods=['POST'])
def api_approve_payment():
    data = request.json
    order_id = data.get('order_id')
    user_id = data.get('user_id')
    amount = data.get('amount')
    
    if not all([order_id, user_id, amount]):
        return jsonify({'error': 'Missing fields'}), 400
    
    try:
        amount = int(amount)
    except:
        return jsonify({'error': 'Amount must be a number'}), 400
    
    # Add balance
    if add_balance(user_id, amount):
        add_order(user_id, f"Balance Add (QR Payment)", amount, "Completed")
        approve_payment(order_id)
        
        # Send Telegram message to user
        msg = f"""✅ **Payment Approved!** 💰

━━━━━━━━━━━━━━━━━━━━━
💵 **Amount:** ₹{amount}
🆔 **Order ID:** `{order_id}`
📅 **Date:** {datetime.now().strftime('%d-%m-%Y %H:%M')}
━━━━━━━━━━━━━━━━━━━━━

💰 **New Balance:** ₹{get_balance(user_id)}

📌 Your balance has been added successfully! 🎉"""
        
        send_telegram_message(user_id, msg)
        
        return jsonify({'success': True, 'message': f'₹{amount} added to user {user_id}!'})
    
    return jsonify({'error': 'Failed to add balance'}), 400

@app.route('/api/reject_payment', methods=['POST'])
def api_reject_payment():
    data = request.json
    order_id = data.get('order_id')
    user_id = data.get('user_id')
    reason = data.get('reason', 'Payment rejected by admin')
    
    if not order_id:
        return jsonify({'error': 'Missing order_id'}), 400
    
    # Update payment status
    data = load_data()
    for payment in data.get('pending_payments', []):
        if payment['order_id'] == order_id:
            payment['status'] = 'rejected'
            save_data(data)
            break
    
    # Send rejection message to user
    msg = f"""❌ **Payment Rejected!** ❌

━━━━━━━━━━━━━━━━━━━━━
🆔 **Order ID:** `{order_id}`

📌 **Reason:** {reason}

━━━━━━━━━━━━━━━━━━━━━
📞 Please contact support for more details.

🆘 Support: Click Back then Support"""
    
    send_telegram_message(user_id, msg)
    
    return jsonify({'success': True, 'message': 'Payment rejected!'})

# ============================================
# STATS
# ============================================

@app.route('/api/stats')
def api_stats():
    stats = get_stats()
    stats['total_categories'] = len(get_all_categories())
    stats['pending_payments'] = len(get_pending_payments())
    return jsonify(stats)

# ============================================
# CATEGORIES
# ============================================

@app.route('/api/categories')
def api_categories():
    return jsonify(get_all_categories())

@app.route('/api/add_category', methods=['POST'])
def api_add_category():
    data = request.json
    name = data.get('name')
    icon = data.get('icon', '📦')
    
    if not name:
        return jsonify({'error': 'Name is required'}), 400
    
    if add_category(name, icon):
        return jsonify({'success': True, 'message': f'Category "{name}" added!'})
    return jsonify({'error': 'Category already exists'}), 400

@app.route('/api/delete_category/<int:index>', methods=['DELETE'])
def api_delete_category(index):
    removed = remove_category(index)
    if removed:
        return jsonify({'success': True, 'message': f'Category "{removed["name"]}" deleted!'})
    return jsonify({'error': 'Category not found'}), 404

@app.route('/api/add_product_to_category', methods=['POST'])
def api_add_product_to_category():
    data = request.json
    category_index = data.get('category_index')
    name = data.get('name')
    price = data.get('price')
    file_link = data.get('file_link')
    file_type = data.get('file_type')
    stock = data.get('stock', 'Unlimited')
    
    if not all([category_index is not None, name, price, file_link, file_type]):
        return jsonify({'error': 'Missing fields'}), 400
    
    try:
        price = int(price)
    except:
        return jsonify({'error': 'Price must be a number'}), 400
    
    if stock.upper() == 'U':
        stock = 'Unlimited'
    
    icons = {"apk": "📱", "zip": "📦", "mod": "🔧", "file": "📄", "html": "🌐", "pdf": "📕"}
    icon = icons.get(file_type.lower(), "📦")
    
    if add_product_to_category(category_index, name, price, file_link, file_type, stock, icon):
        return jsonify({'success': True, 'message': f'Product "{name}" added to category!'})
    return jsonify({'error': 'Category not found'}), 404

@app.route('/api/delete_product_from_category/<int:cat_index>/<int:prod_index>', methods=['DELETE'])
def api_delete_product_from_category(cat_index, prod_index):
    removed = remove_product_from_category(cat_index, prod_index)
    if removed:
        return jsonify({'success': True, 'message': f'Product "{removed["name"]}" deleted!'})
    return jsonify({'error': 'Product not found'}), 404

# ============================================
# KEYS
# ============================================

@app.route('/api/keys')
def api_keys():
    return jsonify(get_all_keys())

@app.route('/api/add_key', methods=['POST'])
def api_add_key():
    data = request.json
    key = data.get('key')
    price = data.get('price')
    hours = data.get('hours')
    
    if not key or not price or not hours:
        return jsonify({'error': 'Missing fields'}), 400
    
    try:
        price = int(price)
        hours = int(hours)
    except:
        return jsonify({'error': 'Price and Hours must be numbers'}), 400
    
    add_key_to_db(key, price, hours)
    return jsonify({'success': True, 'message': 'Key added!'})

@app.route('/api/delete_key/<int:index>', methods=['DELETE'])
def api_delete_key(index):
    removed = remove_key_from_db(index)
    if removed:
        return jsonify({'success': True, 'message': 'Key deleted!'})
    return jsonify({'error': 'Key not found'}), 404

# ============================================
# USERS
# ============================================

@app.route('/api/users')
def api_users():
    data = load_data()
    users = []
    for uid, user_data in data['users'].items():
        users.append({
            'id': uid,
            'name': user_data.get('name', 'Unknown'),
            'balance': user_data.get('balance', 0),
            'joined': user_data.get('joined', 'N/A'),
            'orders': len(data['buy_history'].get(uid, []))
        })
    return jsonify(users)

@app.route('/api/add_balance', methods=['POST'])
def api_add_balance():
    data = request.json
    user_id = data.get('user_id')
    amount = data.get('amount')
    
    if not user_id or not amount:
        return jsonify({'error': 'Missing fields'}), 400
    
    try:
        amount = int(amount)
    except:
        return jsonify({'error': 'Amount must be a number'}), 400
    
    if add_balance(user_id, amount):
        return jsonify({'success': True, 'message': f'₹{amount} added to user {user_id}!'})
    return jsonify({'error': 'User not found'}), 404

@app.route('/api/deduct_balance', methods=['POST'])
def api_deduct_balance():
    data = request.json
    user_id = data.get('user_id')
    amount = data.get('amount')
    
    if not user_id or not amount:
        return jsonify({'error': 'Missing fields'}), 400
    
    try:
        amount = int(amount)
    except:
        return jsonify({'error': 'Amount must be a number'}), 400
    
    if deduct_balance(user_id, amount):
        return jsonify({'success': True, 'message': f'₹{amount} deducted from user {user_id}!'})
    return jsonify({'error': 'User not found'}), 404

# ============================================
# ORDERS
# ============================================

@app.route('/api/orders')
def api_orders():
    return jsonify(get_all_orders())

# ============================================
# SETTINGS
# ============================================

@app.route('/api/settings', methods=['GET', 'POST'])
def api_settings():
    data = load_data()
    if request.method == 'GET':
        return jsonify(data['settings'])
    if request.method == 'POST':
        settings = request.json
        for key, value in settings.items():
            data['settings'][key] = value
        save_data(data)
        return jsonify({'success': True, 'message': 'Settings updated!'})

# ============================================
# RUN
# ============================================

if __name__ == '__main__':
    print("🌐 Web Admin Panel Starting...")
    print("🔗 Open: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)