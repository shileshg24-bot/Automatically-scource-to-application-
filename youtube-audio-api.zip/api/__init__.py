# api/__init__.py
"""API Gateway package"""