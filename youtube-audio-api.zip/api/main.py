# api/main.py
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
import asyncio
from typing import Optional

from api.routes.search import search_router
from api.routes.play import play_router
from api.routes.health import health_router
from api.middleware.auth import verify_api_key
from api.middleware.ratelimit import rate_limiter
from config.settings import settings
from utils.logger import logger

app = FastAPI(
    title="YouTube Audio API",
    description="High-performance YouTube audio extraction API",
    version="2.0.0"
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting middleware
@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    client_ip = request.client.host
    api_key = request.headers.get("api-key")
    
    # Rate limit by API key or IP
    identifier = api_key or client_ip
    
    # Check rate limit
    count = cache.increment_rate_limit(identifier)
    limit = settings.RATE_LIMIT_PER_USER if api_key else settings.RATE_LIMIT_PER_IP
    
    if count > limit:
        return JSONResponse(
            status_code=429,
            content={"error": "Rate limit exceeded. Try again later."}
        )
    
    response = await call_next(request)
    response.headers["X-RateLimit-Limit"] = str(limit)
    response.headers["X-RateLimit-Remaining"] = str(max(0, limit - count))
    return response

# Routes
app.include_router(search_router, prefix="/api/v1", tags=["Search"])
app.include_router(play_router, prefix="/api/v1", tags=["Play"])
app.include_router(health_router, prefix="/api/v1", tags=["Health"])

@app.get("/")
async def root():
    return {
        "service": "YouTube Audio API",
        "status": "operational",
        "version": "2.0.0",
        "endpoints": [
            "/api/v1/search?query=...",
            "/api/v1/play?videoid=...",
            "/api/v1/health"
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        workers=4,
        loop="uvloop"
    )