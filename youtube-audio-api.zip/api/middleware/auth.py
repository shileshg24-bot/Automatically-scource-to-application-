# api/middleware/auth.py
from fastapi import HTTPException, Security
from fastapi.security import APIKeyHeader
from config.settings import settings
from utils.logger import logger

api_key_header = APIKeyHeader(name="api-key", auto_error=False)

async def verify_api_key(api_key: str = Security(api_key_header)):
    """Verify API key"""
    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="Missing API key. Please provide api-key header."
        )
    
    if api_key != settings.API_KEY:
        logger.warning(f"Invalid API key attempt: {api_key[:10]}...")
        raise HTTPException(
            status_code=401,
            detail="Invalid API key."
        )
    
    return api_key