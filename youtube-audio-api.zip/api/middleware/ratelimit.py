# api/middleware/ratelimit.py
from cache.redis_client import cache
from config.settings import settings

def check_rate_limit(identifier: str) -> tuple[bool, int]:
    """Check rate limit for identifier"""
    count = cache.increment_rate_limit(identifier)
    limit = settings.RATE_LIMIT_PER_USER
    
    if count > limit:
        return False, limit - count + 1
    
    return True, limit - count