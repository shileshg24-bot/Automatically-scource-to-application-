# api/models/__init__.py
"""Models package"""
from .schemas import (
    SongResponse,
    SearchResponse,
    ErrorResponse,
    HealthResponse
)