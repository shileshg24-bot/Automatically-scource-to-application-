# api/models/schemas.py
from pydantic import BaseModel
from typing import Optional, List, Any

class SongData(BaseModel):
    """Individual song data model"""
    video_id: str
    title: str
    duration: int
    duration_text: str
    channel: str
    views: str
    thumbnail: str
    audio_url: Optional[str] = None
    audio_file: Optional[str] = None
    video_url: str

class SearchResponse(BaseModel):
    """Search API response model"""
    status: str
    source: str
    latency_ms: float
    data: Optional[SongData] = None

class ErrorResponse(BaseModel):
    """Error response model"""
    status: str
    message: str
    detail: Optional[str] = None

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    timestamp: float
    uptime: float
    memory: dict
    cpu: float
    storage: dict
    redis: str

class QueueResponse(BaseModel):
    """Queue response model"""
    status: str
    message: str
    task_id: Optional[str] = None