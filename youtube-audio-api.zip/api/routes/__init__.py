# api/routes/__init__.py
"""Routes package"""
from .search import search_router
from .play import play_router
from .health import health_router