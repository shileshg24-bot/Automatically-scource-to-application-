# api/routes/health.py
from fastapi import APIRouter
import time
import psutil
import os

from cache.redis_client import cache
from config.settings import settings

health_router = APIRouter()

@health_router.get("/health")
async def health_check():
    """Health check endpoint"""
    status = {
        "status": "healthy",
        "timestamp": time.time(),
        "uptime": time.time() - os.environ.get("START_TIME", 0),
        "memory": {
            "total": psutil.virtual_memory().total / (1024**3),
            "available": psutil.virtual_memory().available / (1024**3),
            "percent": psutil.virtual_memory().percent,
        },
        "cpu": psutil.cpu_percent(interval=0.1),
        "storage": {
            "total": psutil.disk_usage(settings.STORAGE_DIR).total / (1024**3),
            "used": psutil.disk_usage(settings.STORAGE_DIR).used / (1024**3),
            "free": psutil.disk_usage(settings.STORAGE_DIR).free / (1024**3),
            "percent": psutil.disk_usage(settings.STORAGE_DIR).percent,
        }
    }
    
    # Check Redis connection
    try:
        if cache.client:
            cache.client.ping()
            status["redis"] = "connected"
        else:
            status["redis"] = "disconnected"
    except:
        status["redis"] = "disconnected"
    
    return status