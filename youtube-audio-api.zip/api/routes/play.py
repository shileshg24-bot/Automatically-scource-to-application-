# api/routes/play.py
from fastapi import APIRouter, Query, HTTPException, Depends
from fastapi.responses import FileResponse, JSONResponse
import os

from api.middleware.auth import verify_api_key
from cache.redis_client import cache
from config.settings import settings
from utils.logger import logger

play_router = APIRouter()

@play_router.get("/play")
async def play_audio(
    video_id: str = Query(..., min_length=3),
    api_key: str = Depends(verify_api_key)
):
    """Stream audio file"""
    try:
        # Check if audio file exists
        audio_file = f"{settings.STORAGE_DIR}/{video_id}.{settings.YTDL_AUDIO_FORMAT}"
        
        if os.path.exists(audio_file):
            return FileResponse(
                audio_file,
                media_type="audio/mpeg",
                filename=f"{video_id}.mp3"
            )
        
        # Check cache for audio URL
        cached = cache.get_by_video_id(video_id)
        if cached and cached.get("audio_url"):
            return JSONResponse(
                status_code=200,
                content={
                    "status": "success",
                    "source": "cache",
                    "audio_url": cached["audio_url"],
                    "title": cached.get("title", "Unknown")
                }
            )
        
        raise HTTPException(
            status_code=404,
            detail="Audio not found. Please search first."
        )
        
    except Exception as e:
        logger.error(f"Play error: {e}")
        raise HTTPException(status_code=500, detail=str(e))