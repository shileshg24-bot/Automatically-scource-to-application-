# api/routes/search.py
from fastapi import APIRouter, Query, HTTPException, Depends, Request
from fastapi.responses import JSONResponse
import asyncio
import time

from api.middleware.auth import verify_api_key
from cache.redis_client import cache
from worker.tasks import extract_audio_task
from config.settings import settings
from utils.logger import logger

search_router = APIRouter()

@search_router.get("/search")
async def search_song(
    request: Request,
    query: str = Query(..., min_length=1, max_length=200),
    api_key: str = Depends(verify_api_key)
):
    """Search and extract audio from YouTube"""
    start_time = time.time()
    
    try:
        # Step 1: Check cache
        cached = cache.get_song(query)
        if cached:
            response_time = (time.time() - start_time) * 1000
            return JSONResponse(
                status_code=200,
                content={
                    "status": "success",
                    "source": "cache",
                    "latency_ms": round(response_time, 2),
                    "data": cached
                }
            )
        
        # Step 2: Check by video ID if cached from previous search
        # This is for direct video ID queries
        
        # Step 3: Queue task for extraction
        task = extract_audio_task.delay(query)
        
        # Wait for result with timeout
        try:
            result = task.get(timeout=30)
        except Exception as e:
            logger.error(f"Task timeout or error: {e}")
            return JSONResponse(
                status_code=202,
                content={
                    "status": "processing",
                    "message": "Song is being processed. Try again in a moment.",
                    "task_id": task.id
                }
            )
        
        if result.get("source") == "cache":
            data = result.get("data")
        else:
            data = result.get("data")
        
        response_time = (time.time() - start_time) * 1000
        
        return JSONResponse(
            status_code=200,
            content={
                "status": "success",
                "source": result.get("source", "new"),
                "latency_ms": round(response_time, 2),
                "data": data
            }
        )
        
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))