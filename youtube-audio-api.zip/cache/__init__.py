# cache/__init__.py
"""Cache package"""
from .redis_client import RedisCache, cache