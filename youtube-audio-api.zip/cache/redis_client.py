# cache/redis_client.py
import redis
import json
import hashlib
from typing import Optional, Dict, Any
from config.settings import settings
from utils.logger import logger

class RedisCache:
    def __init__(self):
        try:
            self.client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=settings.REDIS_DB,
                password=settings.REDIS_PASSWORD,
                decode_responses=True,
                socket_keepalive=True,
                socket_timeout=5,
            )
            self.client.ping()
            logger.info("Redis connected successfully")
        except Exception as e:
            logger.error(f"Redis connection failed: {e}")
            self.client = None
    
    def generate_key(self, query: str) -> str:
        """Generate cache key from query"""
        query_hash = hashlib.md5(query.lower().strip().encode()).hexdigest()
        return f"song:{query_hash}"
    
    def get_song(self, query: str) -> Optional[Dict[str, Any]]:
        """Get song from cache"""
        if not self.client:
            return None
        
        try:
            key = self.generate_key(query)
            data = self.client.get(key)
            if data:
                return json.loads(data)
            return None
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None
    
    def set_song(self, query: str, song_data: Dict[str, Any]) -> bool:
        """Save song to cache"""
        if not self.client:
            return False
        
        try:
            key = self.generate_key(query)
            self.client.setex(
                key,
                settings.CACHE_TTL,
                json.dumps(song_data)
            )
            return True
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    def get_by_video_id(self, video_id: str) -> Optional[Dict[str, Any]]:
        """Get song by video ID"""
        if not self.client:
            return None
        
        try:
            key = f"video:{video_id}"
            data = self.client.get(key)
            if data:
                return json.loads(data)
            return None
        except Exception as e:
            logger.error(f"Cache get by video ID error: {e}")
            return None
    
    def set_by_video_id(self, video_id: str, song_data: Dict[str, Any]) -> bool:
        """Save song by video ID"""
        if not self.client:
            return False
        
        try:
            key = f"video:{video_id}"
            self.client.setex(
                key,
                86400,  # 24 hours
                json.dumps(song_data)
            )
            return True
        except Exception as e:
            logger.error(f"Cache set by video ID error: {e}")
            return False
    
    def increment_rate_limit(self, key: str, ttl: int = 60) -> int:
        """Increment rate limit counter"""
        if not self.client:
            return 0
        
        try:
            count = self.client.incr(f"ratelimit:{key}")
            if count == 1:
                self.client.expire(f"ratelimit:{key}", ttl)
            return count
        except Exception as e:
            logger.error(f"Rate limit error: {e}")
            return 0
    
    def clear(self):
        """Clear all cache"""
        if self.client:
            self.client.flushdb()
            logger.info("Cache cleared")

cache = RedisCache()