# config/settings.py
import os
from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # API Settings
    API_KEY: str = "BLOODYNIGHTMODMENU"
    API_PORT: int = 8000
    API_HOST: str = "0.0.0.0"
    
    # Redis Settings
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: Optional[str] = None
    
    # Cache Settings
    CACHE_TTL: int = 3600  # 1 hour
    CACHE_MAX_SIZE: int = 100000  # Max songs in cache
    
    # Storage Settings
    STORAGE_DIR: str = "storage"
    STORAGE_CLEANUP_INTERVAL: int = 1800  # 30 minutes
    
    # Worker Settings
    WORKER_COUNT: int = 5
    WORKER_CONCURRENCY: int = 10
    QUEUE_NAME: str = "audio_extraction"
    
    # Rate Limiting
    RATE_LIMIT_PER_USER: int = 100  # requests per minute
    RATE_LIMIT_PER_IP: int = 200
    
    # yt-dlp Settings
    YTDL_FORMAT: str = "bestaudio/best"
    YTDL_AUDIO_FORMAT: str = "mp3"
    YTDL_AUDIO_QUALITY: str = "192"
    YTDL_TIMEOUT: int = 300
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()