# storage/__init__.py
"""Storage package"""
from .local_storage import LocalStorage, storage