# storage/local_storage.py
import os
import shutil
import asyncio
from datetime import datetime, timedelta
from typing import Optional
from config.settings import settings
from utils.logger import logger

class LocalStorage:
    def __init__(self):
        self.storage_dir = settings.STORAGE_DIR
        os.makedirs(self.storage_dir, exist_ok=True)
        logger.info(f"Storage directory initialized: {self.storage_dir}")
        
        # Start cleanup task
        asyncio.create_task(self._cleanup_loop())
    
    def save_audio(self, video_id: str, source_path: str) -> Optional[str]:
        """Save audio file to storage"""
        try:
            dest_path = f"{self.storage_dir}/{video_id}.mp3"
            
            # Copy file
            shutil.copy2(source_path, dest_path)
            logger.info(f"Audio saved: {dest_path}")
            
            return dest_path
        except Exception as e:
            logger.error(f"Save audio error: {e}")
            return None
    
    def get_audio_path(self, video_id: str) -> Optional[str]:
        """Get audio file path"""
        path = f"{self.storage_dir}/{video_id}.mp3"
        if os.path.exists(path):
            return path
        return None
    
    def delete_audio(self, video_id: str) -> bool:
        """Delete audio file"""
        try:
            path = f"{self.storage_dir}/{video_id}.mp3"
            if os.path.exists(path):
                os.remove(path)
                logger.info(f"Audio deleted: {path}")
                return True
            return False
        except Exception as e:
            logger.error(f"Delete audio error: {e}")
            return False
    
    async def _cleanup_loop(self):
        """Background cleanup task"""
        while True:
            try:
                await asyncio.sleep(settings.STORAGE_CLEANUP_INTERVAL)
                self.cleanup_old_files()
            except Exception as e:
                logger.error(f"Cleanup loop error: {e}")
    
    def cleanup_old_files(self, max_age_minutes: int = 30):
        """Delete files older than max_age_minutes"""
        try:
            cutoff = datetime.now() - timedelta(minutes=max_age_minutes)
            deleted_count = 0
            
            for filename in os.listdir(self.storage_dir):
                file_path = os.path.join(self.storage_dir, filename)
                if os.path.isfile(file_path):
                    mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
                    if mtime < cutoff:
                        os.remove(file_path)
                        deleted_count += 1
            
            if deleted_count > 0:
                logger.info(f"Cleaned up {deleted_count} old files")
                
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
    
    def get_storage_info(self) -> dict:
        """Get storage usage info"""
        try:
            usage = shutil.disk_usage(self.storage_dir)
            return {
                "total_gb": round(usage.total / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "free_gb": round(usage.free / (1024**3), 2),
                "percent_used": round((usage.used / usage.total) * 100, 2)
            }
        except Exception as e:
            logger.error(f"Storage info error: {e}")
            return {}

# Singleton instance
storage = LocalStorage()