# utils/helpers.py
import re
import time
from datetime import datetime
from typing import Optional, Dict, Any

def format_duration(seconds: int) -> str:
    """Format duration in seconds to MM:SS or HH:MM:SS"""
    if seconds < 0:
        return "0:00"
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    remaining_seconds = seconds % 60
    
    if hours > 0:
        return f"{hours}:{minutes:02d}:{remaining_seconds:02d}"
    return f"{minutes}:{remaining_seconds:02d}"

def extract_video_id(url: str) -> Optional[str]:
    """Extract YouTube video ID from URL"""
    patterns = [
        r'(?:youtube\.com\/watch\?v=)([\w-]+)',
        r'(?:youtu\.be\/)([\w-]+)',
        r'(?:youtube\.com\/embed\/)([\w-]+)',
        r'(?:youtube\.com\/v\/)([\w-]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None

def validate_url(url: str) -> bool:
    """Validate if URL is a YouTube URL"""
    patterns = [
        r'(?:www\.)?youtube\.com',
        r'(?:www\.)?youtu\.be',
    ]
    return any(re.search(pattern, url) for pattern in patterns)

def format_response(data: Dict[str, Any], source: str = "cache") -> Dict[str, Any]:
    """Format API response"""
    return {
        "status": "success",
        "source": source,
        "timestamp": get_timestamp(),
        "data": data
    }

def get_timestamp() -> str:
    """Get current timestamp in ISO format"""
    return datetime.now().isoformat()

def sanitize_query(query: str) -> str:
    """Sanitize search query"""
    # Remove special characters
    query = re.sub(r'[^\w\s-]', '', query)
    # Limit length
    query = query[:200]
    return query.strip()