# worker/__init__.py
"""Worker package"""
from .audio_extractor import AudioExtractor
from .tasks import celery_app, extract_audio_task