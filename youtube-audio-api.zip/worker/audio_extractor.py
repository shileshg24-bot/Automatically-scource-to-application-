# worker/audio_extractor.py
import yt_dlp
import os
import asyncio
import aiohttp
from typing import Dict, Any, Optional
from config.settings import settings
from utils.logger import logger

class AudioExtractor:
    def __init__(self):
        self.ydl_opts = {
            'format': settings.YTDL_FORMAT,
            'quiet': True,
            'no_warnings': True,
            'extract_audio': True,
            'audio_format': settings.YTDL_AUDIO_FORMAT,
            'audio_quality': settings.YTDL_AUDIO_QUALITY,
            'outtmpl': f'{settings.STORAGE_DIR}/%(id)s.%(ext)s',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': settings.YTDL_AUDIO_FORMAT,
                'preferredquality': settings.YTDL_AUDIO_QUALITY,
            }],
            'noplaylist': True,
            'geo_bypass': True,
            'extract_flat': False,
        }
        
        os.makedirs(settings.STORAGE_DIR, exist_ok=True)
    
    async def search_and_extract(self, query: str) -> Dict[str, Any]:
        """Search YouTube and extract audio"""
        try:
            # Run yt-dlp in executor
            loop = asyncio.get_event_loop()
            info = await loop.run_in_executor(
                None,
                self._search_and_extract_sync,
                query
            )
            return info
        except Exception as e:
            logger.error(f"Extraction error: {e}")
            raise
    
    def _search_and_extract_sync(self, query: str) -> Dict[str, Any]:
        """Synchronous extraction (runs in thread pool)"""
        try:
            with yt_dlp.YoutubeDL(self.ydl_opts) as ydl:
                # Search YouTube
                info = ydl.extract_info(f"ytsearch1:{query}", download=True)
                
                if not info or not info.get('entries'):
                    return {"error": "No results found"}
                
                entry = info['entries'][0]
                video_id = entry.get('id')
                
                # Get audio stream URL
                audio_url = self._get_audio_url(entry)
                
                # Check if file exists
                audio_file = f"{settings.STORAGE_DIR}/{video_id}.{settings.YTDL_AUDIO_FORMAT}"
                
                return {
                    "status": "success",
                    "video_id": video_id,
                    "title": entry.get('title', 'Unknown'),
                    "duration": entry.get('duration', 0),
                    "duration_text": self._format_duration(entry.get('duration', 0)),
                    "channel": entry.get('uploader', 'Unknown'),
                    "views": f"{entry.get('view_count', 0):,}",
                    "thumbnail": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg",
                    "audio_url": audio_url,
                    "audio_file": audio_file if os.path.exists(audio_file) else None,
                    "video_url": f"https://youtube.com/watch?v={video_id}"
                }
                
        except Exception as e:
            logger.error(f"Extraction error: {e}")
            return {"error": str(e)}
    
    def _get_audio_url(self, entry: Dict) -> Optional[str]:
        """Extract audio stream URL from entry"""
        try:
            # Get audio-only formats
            audio_formats = [
                f for f in entry.get('formats', [])
                if f.get('acodec') != 'none' and f.get('vcodec') == 'none'
            ]
            
            if audio_formats:
                # Get best quality audio
                best_format = max(audio_formats, key=lambda f: f.get('tbr', 0))
                return best_format.get('url')
            
            # Fallback: get any format with audio
            for f in entry.get('formats', []):
                if f.get('acodec') != 'none':
                    return f.get('url')
            
            return None
        except Exception as e:
            logger.error(f"Audio URL extraction error: {e}")
            return None
    
    def _format_duration(self, seconds: int) -> str:
        """Format duration to MM:SS"""
        minutes = seconds // 60
        remaining_seconds = seconds % 60
        return f"{minutes}:{remaining_seconds:02d}"

audio_extractor = AudioExtractor()