# worker/consumer.py
import asyncio
import signal
import sys
from celery import Celery
from config.settings import settings
from worker.tasks import celery_app, extract_audio_task
from utils.logger import logger

class WorkerConsumer:
    def __init__(self):
        self.app = celery_app
        self.running = True
        
    def start(self):
        """Start worker"""
        logger.info(f"Starting worker with concurrency: {settings.WORKER_CONCURRENCY}")
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)
        
        # Start celery worker
        argv = [
            'worker',
            '--loglevel=info',
            f'--concurrency={settings.WORKER_CONCURRENCY}',
            '--max-tasks-per-child=100',
            '--time-limit=300',
            '--soft-time-limit=240',
        ]
        
        self.app.worker_main(argv)
    
    def shutdown(self, signum, frame):
        """Graceful shutdown"""
        logger.info("Shutting down worker...")
        self.running = False
        sys.exit(0)

if __name__ == "__main__":
    worker = WorkerConsumer()
    worker.start()