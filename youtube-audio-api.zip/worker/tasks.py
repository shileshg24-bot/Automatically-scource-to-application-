# worker/tasks.py
from celery import Celery
from worker.audio_extractor import audio_extractor
from cache.redis_client import cache
from config.settings import settings
from utils.logger import logger

# Celery app
celery_app = Celery(
    'tasks',
    broker=f'redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}/1',
    backend=f'redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}/2'
)

celery_app.conf.update(
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_time_limit=300,
    task_soft_time_limit=240,
    worker_prefetch_multiplier=1,
    worker_concurrency=settings.WORKER_CONCURRENCY,
)

@celery_app.task(bind=True, max_retries=3)
def extract_audio_task(self, query: str):
    """Celery task to extract audio"""
    try:
        # Check cache first
        cached = cache.get_song(query)
        if cached:
            return {"source": "cache", "data": cached}
        
        # Extract audio
        result = audio_extractor.search_and_extract(query)
        
        if result.get('status') == 'success' and 'error' not in result:
            # Save to cache
            cache.set_song(query, result)
            if result.get('video_id'):
                cache.set_by_video_id(result['video_id'], result)
            return {"source": "new", "data": result}
        else:
            raise Exception(result.get('error', 'Extraction failed'))
            
    except Exception as e:
        logger.error(f"Task failed: {e}")
        raise self.retry(exc=e, countdown=5)